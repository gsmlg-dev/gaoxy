"""Capture four unchanged positive cases in a disposable diagnostic layer."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

output = Path('/diagnosis')
output.mkdir()
helper = Path('/work/apps/gaoxy_proxy/test/test_helper.exs')
original = helper.read_bytes()
assert original == b'ExUnit.start()\n'
command = ['mix', 'test', 'apps/gaoxy_proxy/test/managed_h2_group_endpoint_test.exs:21', '--seed', '0', '--max-cases', '1']
env = dict(os.environ, MIX_ENV='test', HTTP_FETCH_PEER_PYTHON='/work/.audit/h2peer/bin/python', GAOXY_QUIC_PYTHON='/work/.audit/h2peer/bin/python', PYTHONDONTWRITEBYTECODE='1')
report = {'status': 'FAIL', 'kind': 'DIAGNOSTIC_ONLY_NOT_RELEASE_ACCEPTANCE', 'source_identity': json.loads(Path('/tools/source-identity.json').read_text())['source_sha'], 'command': command, 'timeout_seconds': 300, 'helper_original_sha256': hashlib.sha256(original).hexdigest()}
tick = time.monotonic()
try:
    helper.write_bytes(original + b'Code.require_file("/diagnostic/instrument.exs")\n')
    result = subprocess.run(command, cwd='/work', env=env, capture_output=True, timeout=300)
    (output/'stdout.log').write_bytes(result.stdout)
    (output/'stderr.log').write_bytes(result.stderr)
    report['exit_code'] = result.returncode
    report['summaries'] = re.findall(r'(\d+) tests?, (\d+) failures?([^\n]*)', (result.stdout + result.stderr).decode(errors='replace'))
    report['status'] = 'CAPTURED_TEST_FAILURE' if result.returncode else 'CAPTURED_TEST_PASS'
except subprocess.TimeoutExpired as error:
    (output/'stdout.log').write_bytes(error.stdout or b'')
    (output/'stderr.log').write_bytes(error.stderr or b'')
    report['status'] = 'CAPTURED_TIMEOUT'
    report['error'] = repr(error)
except BaseException as error:
    report['error'] = repr(error)
    raise
finally:
    helper.write_bytes(original)
    assert helper.read_bytes() == original
    report['helper_restored'] = True
    report['elapsed_seconds'] = time.monotonic()-tick
    (output/'result.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='source_identity'}), flush=True)
