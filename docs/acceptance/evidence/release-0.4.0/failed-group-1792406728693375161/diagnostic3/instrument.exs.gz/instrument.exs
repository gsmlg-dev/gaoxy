# Loaded only by a temporary Code.require_file in the disposable builder test_helper.
# Tracing observes own accounting calls and never replaces their arguments or results.
defmodule Gaoxy.Release.GroupPumpDiagnostic3 do
  @accounting Gaoxy.Proxy.ManagedH2GroupAccounting
  @mfa {@accounting, :validate, 2}

  def install do
    Code.ensure_loaded!(@accounting)
    tracer = spawn_link(fn -> collect(%{}, %{}) end)
    1 = :erlang.trace_pattern(@mfa, [{[:pump, :_], [], [{:return_trace}]}], [:local])
    :erlang.trace(:all, true, [:call, :set_on_spawn, {:tracer, tracer}])
    ExUnit.after_suite(fn _results -> stop(tracer) end)
    IO.puts("GROUP_DIAGNOSTIC3_INSTALLED own_accounting_validate_pump_only")
    :ok
  end

  defp stop(tracer) do
    :erlang.trace(:all, false, [:call, :set_on_spawn])
    :erlang.trace_pattern(@mfa, false, [:local])
    delivered = :erlang.trace_delivered(:all)

    receive do
      {:trace_delivered, :all, ^delivered} -> :ok
    after
      5_000 -> raise "group diagnostic trace delivery did not finish"
    end

    send(tracer, {:finish, self()})

    receive do
      {:group_diagnostic3_finished, ^tracer} -> :ok
    after
      5_000 -> raise "group diagnostic collector did not finish"
    end
  end

  defp collect(pending, summaries) do
    receive do
      {:trace, pid, :call, {@accounting, :validate, [:pump, pump]}} ->
        exchange = Map.fetch!(pump, :exchange)
        limits = Map.fetch!(exchange, :limits)

        summary = %{
          downstream: Map.fetch!(Map.fetch!(exchange, :request), :version),
          limits_count: map_size(limits),
          limits_key_types:
            limits
            |> Enum.sort_by(fn {key, _value} -> key end)
            |> Enum.take(32)
            |> Enum.map(fn {key, value} -> {key, value_type(value)} end)
        }

        collect(Map.put(pending, pid, summary), summaries)

      {:trace, pid, :return_from, {@accounting, :validate, 2}, result} ->
        {summary, pending} = Map.pop(pending, pid)

        if summary == nil do
          collect(pending, summaries)
        else
          summary = Map.put(summary, :result, validation_result(result))

          unless Map.has_key?(summaries, summary) do
            IO.inspect({:group_diagnostic3_pump, summary}, pretty: false, limit: :infinity)
          end

          collect(pending, Map.update(summaries, summary, 1, &(&1 + 1)))
        end

      {:finish, caller} ->
        IO.inspect(
          {:group_diagnostic3_summary,
           %{observations: Map.to_list(summaries), unmatched_calls: map_size(pending)}},
          pretty: false,
          limit: :infinity
        )

        send(caller, {:group_diagnostic3_finished, self()})

      _other ->
        collect(pending, summaries)
    end
  end

  defp value_type(value) when is_boolean(value), do: :boolean
  defp value_type(value) when is_integer(value), do: :integer
  defp value_type(value) when is_map(value), do: :map
  defp value_type(_value), do: :other
  defp validation_result(:ok), do: :ok
  defp validation_result({:error, reason}) when is_atom(reason), do: {:error, reason}
  defp validation_result(other), do: {:unexpected_result_type, value_type(other)}
end

:ok = Gaoxy.Release.GroupPumpDiagnostic3.install()
