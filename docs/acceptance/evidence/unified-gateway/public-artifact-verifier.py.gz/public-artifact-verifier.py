import hashlib,io,json,os,subprocess,tarfile,urllib.request
from pathlib import Path
root=Path.cwd()
version='0.8.0'
expected=os.environ['GAOXY_EXPECTED_RELEASE_SHA']
dest=root/'.audit/unified-public-dist'
dest.mkdir(exist_ok=True)
def command(args,**kw):
 return subprocess.check_output(args,text=True,**kw)
release=json.loads(command(['gh','release','view','v'+version,'--repo','gsmlg-dev/gaoxy','--json','tagName,targetCommitish,publishedAt,url,assets']))
assert release['tagName']=='v'+version
assert len(release['assets'])==7,release['assets']
tag=command(['git','ls-remote','origin','refs/tags/v'+version]).split()[0]
assert tag==expected,(tag,expected)
subprocess.run(['gh','release','download','v'+version,'--repo','gsmlg-dev/gaoxy','--dir',str(dest),'--clobber'],check=True)
checks={}
for line in (dest/'SHA256SUMS').read_text().splitlines():
 digest,name=line.split(maxsplit=1)
 name=name.lstrip('*')
 assert Path(name).name==name,name
 assert hashlib.sha256((dest/name).read_bytes()).hexdigest()==digest,name
 checks[name]=digest
assert len(checks)==6,checks
receipt={'status':'PASS','version':version,'source':tag,'release':release,'checksums':checks,'packages':[]}
names=['gaoxy_websock_adapter','gaoxy','gaoxy_http','gaoxy_http3','gaoxy_proxy']
for name in names:
 filename=f'{name}-{version}.tar'
 with urllib.request.urlopen(f'https://repo.hex.pm/tarballs/{filename}',timeout=30) as response:
  public=response.read()
 assert public==(dest/filename).read_bytes(),name
 with urllib.request.urlopen(f'https://hex.pm/api/packages/{name}/releases/{version}',timeout=30) as response:
  api=json.load(response)
 assert api['version']==version,api
 assert api['checksum']==checks[filename],(name,api['checksum'],checks[filename])
 (dest/(name+'-hex.json')).write_text(json.dumps(api,indent=2)+'\n')
 with tarfile.open(dest/filename) as outer:
  metadata=outer.extractfile('metadata.config').read()
  with tarfile.open(fileobj=io.BytesIO(outer.extractfile('contents.tar.gz').read()),mode='r:gz') as archive:
   files={member.name:archive.extractfile(member).read() for member in archive.getmembers() if member.isfile()}
 staged=root/'.audit/unified-hex-0.8.0-final'/name
 wanted={str(p.relative_to(staged)) for p in staged.rglob('*') if p.is_file() and p.suffix!='.tar'}
 assert set(files)==wanted,(name,set(files)^wanted)
 for path,data in files.items():
  assert data==(staged/path).read_bytes(),(name,path)
 assert f'{{<<"version">>,<<"{version}">>}}.'.encode() in metadata,name
 assert f'{{<<"name">>,<<"{name}">>}}.'.encode() in metadata,name
 receipt['packages'].append({'name':name,'sha256':checks[filename],'hex_checksum':api['checksum'],'file_count':len(files),'runtime_payload_count':sum(path.startswith(('lib/','priv/')) for path in files),'exact_staged_files':True,'github_hex_bytes_equal':True})
(dest/'verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'status':'PASS','source':tag,'assets':len(release['assets']),'checksum_entries':len(checks),'packages':len(names),'runtime_payloads':sum(x['runtime_payload_count'] for x in receipt['packages'])}),flush=True)
