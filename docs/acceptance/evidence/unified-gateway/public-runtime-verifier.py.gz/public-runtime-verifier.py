#!/usr/bin/env python3
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import tarfile
import time

root=Path.cwd()
dist=root/'.audit/unified-public-dist'
target=root/'.audit/unified-public-runtime'
assert not target.exists(), target
target.mkdir()
archive=dist/'gaoxy-0.8.0-linux-x86_64.tar.gz'
verification=json.loads((dist/'verification.json').read_text())
assert verification['status']=='PASS'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==verification['checksums'][archive.name]
with tarfile.open(archive) as contents:
    contents.extractall(target, filter='data')
release=target/'bin/gaoxy'
assert release.is_file()
env=dict(os.environ,ELIXIR_ERL_OPTIONS='+S 4:4',ERL_FLAGS='+S 4:4')
receipt={'status':'FAIL','source':verification['source'],'version':'0.8.0',
         'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
         'release':str(release),'checks':[],'environment':{key:env.get(key,'') for key in ['LD_LIBRARY_PATH','NIX_LD_LIBRARY_PATH','ERL_FLAGS']}}
commands=[
    ('core', ['python3','-c',
      "import importlib.util;from pathlib import Path;spec=importlib.util.spec_from_file_location('release_smoke','scripts/release-smoke.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);module.release=Path("+repr(str(release))+");module.main()"],3),
    ('gateway',[str(root/'.audit/h2peer/bin/python'),'scripts/gateway-release-smoke.py','--release',str(release)],7),
    ('h3',[str(root/'.audit/h2peer/bin/python'),'scripts/h3-release-smoke.py','--release',str(release),'--evidence',str(target/'h3-evidence')],3)
]
try:
    for name,command,count in commands:
        start=time.monotonic()
        with (target/(name+'.log')).open('w') as log:
            outcome=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=150)
        receipt['checks'].append({'name':name,'exit':outcome.returncode,'expected_checks':count,
                                 'seconds':round(time.monotonic()-start,3),'command':command})
        assert outcome.returncode==0,(name,outcome.returncode)
        output=(target/(name+'.log')).read_text()
        if name=='core':
            assert 'PASS portable release TCP/TLS/UDP' in output and '; 3 transports' in output
        elif name=='gateway':
            assert 'PASS standalone gateway release readiness' in output and '; 7 exchanges' in output
        else:
            detail=json.loads((target/'h3-evidence/result.json').read_text())
            assert detail['status']=='PASS' and len(detail['checks'])==3
            assert all(check['status']=='PASS' for check in detail['checks'])
        receipt['checks'][-1].update(status='PASS',verified_checks=count)
    receipt['status']='PASS'
finally:
    (target/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
