defmodule PublicHexIsolationTest do
  use ExUnit.Case, async: true
  test "published applications retain exact versions and optional boundaries" do
    resolved = Mix.Dep.load_and_cache()
    for dependency <- resolved, do: assert(dependency.scm == Hex.SCM)
    for app <- [:gaoxy], do: assert(to_string(Application.spec(app, :vsn)) == "0.8.0")
    for app <- [:gaoxy_server, :gaoxy_http3] do
      refute Enum.any?(resolved, &(&1.app == app))
      assert {:error, :bad_name} = :code.lib_dir(app)
    end
    refute Code.ensure_loaded?(Gaoxy.Server.Application)
  end
end
