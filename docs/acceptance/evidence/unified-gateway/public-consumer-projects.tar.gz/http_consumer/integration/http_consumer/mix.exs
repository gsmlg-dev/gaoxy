defmodule PublicHttpConsumer.MixProject do
  use Mix.Project
  def project, do: [app: :http_consumer, version: "0.1.0", elixir: "~> 1.18", deps: [{:gaoxy, "== 0.8.0", override: true}, {:gaoxy_http, "== 0.8.0", override: true}, {:websock_adapter, "== 0.8.0", hex: :gaoxy_websock_adapter, override: true}]]
  def application, do: [extra_applications: [:logger]]
end
