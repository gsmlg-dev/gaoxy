# Independent public delivery evidence review

Task `ARB-PUBLIC-DELIVERY-REVIEW`: **DONE — PUBLIC_DELIVERY_EVIDENCE_ACCEPTED**.
Direct Sol read-only audit. Repository `/home/gao/Workspace/gsmlg-opt/gaoxy`,
branch `main`, publication source `e3afc810481c396c63dff1f6f81230b456511016`,
version `0.14.0`. No blocking delivery-evidence finding.

The independent authentication command
`python3 -B .audit/adaptive-resource-budget/public-delivery-review/verify.py`
finished with exit0 at `2026-10-30T10:14:36.475889+00:00`. It reads existing
evidence, Git blobs and one live public tag query; it does not run tests,
builds, application runtimes or the earlier writing verifiers. Its nine
authentication groups pass. `validation.json` contains the derived results.

## Accepted evidence

- All682 executable/dependency/workflow source inputs match both publication
  Git blobs and the two terminal outer qualification receipts. Documentation
  changes and the untracked archive are parent-owned closeout work.
- Release41035876876 completed successfully on the exact source, with all
  steps successful, including original source validation, the immediately
  pre-upload source guard and public post-publication consumers. Both raw log
  and final metadata match captured hashes. Independently parsed positive
  summaries: canonical121/900, failures0/excluded0/skipped0; source consumers9;
  built-package consumers7; fresh published Hex-only consumers7. Both consumer
  lanes prove production/release isolation. Packaging12, Phoenix special22 and
  unified Endpoint8 retain their separate counts.
- Eight GitHub assets have matching sizes/digests; SHA256SUMS covers exactly
  seven payloads. Six public Hex downloads equal their GitHub package assets
  byte-for-byte and match public Hex checksums, application/version identities,
  non-retirement, dependency requirements and optionality. All151 regular
  `lib/priv` package files independently match committed Git blobs:
  gaoxy35, gaoxy_http45, gaoxy_http3-10, gaoxy_proxy42, gaoxy_test15, adapter4.
  The adapter package is gaoxy_websock_adapter; its application is
  websock_adapter. The required http_core floor and exact sibling versions
  are preserved. Package manifests match the reviewed receipt hashes.
- Actions ZIP digest matches its recorded API artifact digest; all eight ZIP
  payloads equal public assets. Run provenance identifies the exact main
  source and successful release workflow. This is metadata and byte equality
  evidence; **cryptographic build attestation is NOT VERIFIED**.
- The live GitHub tag query resolves v0.14.0 directly to the exact source.
  The downloaded standalone archive and active release/application metadata
  match recorded hashes; all five active own applications are0.14.0.
- Downloaded-runtime raw logs and subordinate H3 result substantiate core3,
  Gateway7 and H3-3, totaling13. Commands target the extracted public archive,
  not local `_build`. All three process groups disappeared naturally and
  commands exited0; H3 release/origin exited0 and ports rebound. Runtime peer
  and source-script hashes match the exact source. The recorded Nix library
  compatibility environment is process-local. The checked archive hash equals
  the public standalone hash.
- The frozen exact-source CI receipt remains unchanged; its writing verifier
  was not rerun. All66 original archive entries decompress byte-for-byte to
  the originals, with matching original/compressed hashes at the recorded
  manifest snapshot. Parent will append this final audit and update closeout.

## Nonblocking artifact limitation

The standalone tarball includes redundant prior-version directories:

```
lib/gaoxy-0.13.0
lib/gaoxy_http-0.13.0
lib/gaoxy_http3-0.13.0
lib/gaoxy_proxy-0.13.0
lib/gaoxy_server-0.13.0
```

These are five own production applications. No gaoxy_test, ExUnit or HPAX
runtime library directory was found. `bin/gaoxy` derives its default release
version from `releases/start_erl.data`, which is `16.4.0.7 0.14.0`, and selects
that release's boot file. Its `.rel` and five active `.app` files specify0.14.0;
both `start.script` and `start.boot` contain all five0.14.0 ebin paths and no
0.13.0 reference. `standalone-selection.json` records exact selector hashes.

This is an archive hygiene limitation: old code remains distributed. Evidence
does not show default startup selecting that old code or test-only dependency
isolation being breached. Ordinary downloaded-runtime13 checks and separate
production-isolation assertions pass. Arbitrary operator overrides or manual
code-path manipulation are not qualified. This audit neither removes the
directories nor requests a source repair or replacement release.

## Documentation and remaining boundaries

Parent's draft acceptance/plan counts and dispositions agree with evidence;
`git diff --check` on all three draft documents exited0. Parent must finish
its already-owned closeout: replace the remaining design-header publication
pending text, disclose the five inactive directories, mark final review
complete, archive this receipt and perform final document review/delivery.
`documentation-review.json` identifies the reviewed draft hashes; it is not
an approval of later unreviewed documentation edits.

Native macOS/Windows memory probes: **NOT RUN**. Specialist pressure,
slow-peer and sustained-load: **NOT RUN**. Production deployment: **NOT RUN**.
No broader runtime/platform or signed provenance claim is made.

Only this audit directory was written by this reviewer. No Git state, source,
parent documents or earlier evidence was changed. No subprocess remains
running. Sol repair rounds for this audit:0; historical CORE Sol2/Astra16
compatibility and production14 are unchanged. No Astra gate or external
decision is needed for this evidence verdict.
