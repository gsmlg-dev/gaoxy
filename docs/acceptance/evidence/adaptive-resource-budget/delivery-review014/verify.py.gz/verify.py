#!/usr/bin/env python3
"""Independent read-only authentication; output only in this audit directory."""
import collections
import datetime
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile
import zipfile

ROOT = Path('/home/gao/Workspace/gsmlg-opt/gaoxy')
BASE = ROOT / '.audit/adaptive-resource-budget'
OUT = BASE / 'public-delivery-review'
SHA = 'e3afc810481c396c63dff1f6f81230b456511016'
VERSION = '0.14.0'
checks = []
def require(condition, message):
    if not condition:
        raise AssertionError(message)
def digest(data):
    return hashlib.sha256(data).hexdigest()
def load(path):
    return json.loads(Path(path).read_text())
def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, timeout=30)
def passed(name, detail):
    checks.append({'check': name, 'status': 'PASS', 'detail': detail})
def read(path):
    return Path(path).read_bytes()

require(git('rev-parse', 'HEAD').decode().strip() == SHA, 'HEAD changed')
require(git('branch', '--show-current').decode().strip() == 'main', 'branch changed')
bridge = load(BASE / 'publication-source-bridge-recovery16.json')
hashes = bridge['source_hashes']
require(len(hashes) == 682, 'source cohort count changed')
for path, checksum in hashes.items():
    require(digest(read(ROOT/path)) == checksum, 'current source differs: '+path)
    require(digest(git('show', SHA+':'+path)) == checksum, 'commit source differs: '+path)
passed('source_identity', {'commit': SHA, 'current_and_committed_inputs': len(hashes)})

outer = {}
for label in ('public-artifacts', 'downloaded-runtime'):
    receipt = load(BASE / f'qualification/{label}-e3afc810.json')
    require(receipt['status']=='PASS' and receipt['exit']==0 and receipt['commands_terminal'] is True,
            'outer qualification not terminal PASS: '+label)
    require(receipt['source']==SHA and receipt['source_hashes']==hashes and receipt['source_changes']==[],
            'outer source mismatch: '+label)
    require(digest(read(ROOT/receipt['log']))==receipt['log_sha256'], 'outer log digest: '+label)
    outer[label]=receipt
passed('outer_qualification_receipts', {'labels': list(outer), 'source_inputs_each':682})

release = BASE/'delivery/release-e3afc810'
capture = load(release/'capture-receipt.json')
require(digest(read(release/'release.log'))==capture['log_sha256'], 'release log digest')
require(digest(read(release/'final-metadata.json'))==capture['metadata_sha256'], 'release metadata digest')
metadata = load(release/'final-metadata.json')
require(metadata['headSha']==SHA and metadata['databaseId']==41035876876
        and metadata['event']=='workflow_dispatch' and metadata['headBranch']=='main'
        and metadata['status']=='completed' and metadata['conclusion']=='success', 'release run identity')
require(len(metadata['jobs'])==1 and all(s['conclusion']=='success' and s['status']=='completed'
        for s in metadata['jobs'][0]['steps']), 'release steps not all success')
steps = collections.defaultdict(list)
for line in (release/'release.log').read_text().splitlines():
    columns = line.split('\t', 2)
    if len(columns)==3:
        steps[columns[1]].append(columns[2].split(' ',1)[-1])
summary_pattern = re.compile(r'^(\d+) tests?, (\d+) failures?(.*)$')
def summaries(step):
    found=[]
    for line in steps[step]:
        m=summary_pattern.fullmatch(line)
        if m:
            require(int(m[1])>0 and int(m[2])==0, 'nonpositive or failed summary: '+step)
            for n, disposition in re.findall(r'(\d+) (excluded|skipped)', m[3]):
                require(int(n)==0, 'excluded/skipped summary: '+step)
            found.append(int(m[1]))
    require(found, 'no actual positive summaries: '+step)
    return found
canonical='Correctness repair and ordinary compatibility on publication source'
counts=summaries(canonical)
require(len(counts)==121 and sum(counts)==900, 'canonical counts differ')
require('REPAIR_PASS 900 executed, 0 failures, 0 excluded, 0 skipped' in steps[canonical], 'canonical final marker')
source_counts=summaries('Isolated core, HTTP, H3 and Gateway consumers on publication source')
require(source_counts==[1,4,2,1,1], 'source consumer counts')
for step, mode in [('Built-package test consumers and production dependency isolation','built-tarballs-local-siblings'),
                   ('Fresh Hex-only test consumers after publication','published-hex-only')]:
    require(summaries(step)==[3,2,2], 'consumer counts: '+step)
    require('CONSUMER_MODE '+mode+' version='+VERSION in steps[step], 'consumer mode: '+step)
    for marker in ['CONSUMER_RELEASE_ISOLATION_PASS cases=1 helper_absent=true exunit_absent=true',
                   'CONSUMER_PASS base','CONSUMER_PASS h3','CONSUMER_PASS http_fetch']:
        require(marker in steps[step], 'consumer marker: '+step+' '+marker)
require(summaries('Phoenix client-certificate, large-message and streaming regressions')==[22], 'Phoenix counts')
require(any(re.fullmatch(r'Ran 12 tests in .*', line) for line in steps['Hex packaging regressions']), 'packaging tests')
endpoint=[json.loads(line) for line in steps['Unified Endpoint H1/H2/H3 clients, WebSocket and reload acceptance']
          if line.startswith('{"status": "PASS", "checks":')]
require(len(endpoint)==1 and all(c['status']=='PASS' for c in endpoint[0]['checks']), 'Endpoint acceptance')
passed('release_workflow', {'run':41035876876, 'all_steps':'success', 'canonical_summaries':121,
       'canonical_tests':900, 'failures':0,'excluded':0,'skipped':0, 'source_consumer_tests':9,
       'built_package_consumer_tests':7,'published_hex_only_consumer_tests':7,
       'production_isolation_each':True,'packaging_tests':12,'phoenix_special_tests':22,
       'unified_endpoint_checks':len(endpoint[0]['checks'])})

ART=BASE/'release-verification/public-artifacts-75nx6cnx'
artifact=load(ART/'receipt.json')
helper=BASE/'release-verification/verify-public-artifacts.py'
require(digest(read(helper))==artifact['verifier_sha256']=='bf699636e821473c2c32ea8f7a73a405b186432202bd70e327e9171e364e414a', 'artifact helper digest')
require(artifact['status']=='PASS' and artifact['source_commit']==artifact['remote_tag_sha']==SHA
        and artifact['version']==VERSION and artifact['tag']=='v'+VERSION, 'public receipt identity')
public=load(ART/'github-release.json')
require(public['tag_name']=='v'+VERSION and public['draft'] is False and public['prerelease'] is False, 'public release state')
assets=artifact['assets']
require(len(assets)==8 and {a['name'] for a in public['assets']}==set(assets), 'public asset set')
for name, info in assets.items():
    data=read(ART/name)
    require(digest(data)==info['sha256'] and len(data)==info['bytes'], 'asset digest/bytes: '+name)
    apiasset=next(a for a in public['assets'] if a['name']==name)
    require(apiasset['id']==info['asset_id'] and apiasset['size']==len(data), 'API asset identity: '+name)
sums={line.split('  ')[1]:line.split('  ')[0] for line in (ART/'SHA256SUMS').read_text().splitlines()}
require(len(sums)==7 and set(sums)==set(assets)-{'SHA256SUMS'}, 'payload set')
require(all(assets[n]['sha256']==h for n,h in sums.items()), 'payload checksums')
packages={ 'gaoxy':'apps/gaoxy','gaoxy_http':'apps/gaoxy_http','gaoxy_http3':'apps/gaoxy_http3',
          'gaoxy_proxy':'apps/gaoxy_proxy','gaoxy_test':'apps/gaoxy_test', 'gaoxy_websock_adapter':'vendor/websock_adapter'}
package_counts={}
for name, root in packages.items():
    info=artifact['packages'][name]
    raw=read(ART/f'{name}-{VERSION}.tar')
    hexmeta=load(ART/f'hex-{name}.json')
    require(raw==read(ART/f'hex-{name}-{VERSION}.tar'), 'Hex and GitHub package bytes: '+name)
    require(digest(raw)==hexmeta['checksum']==info['archive_sha256'], 'Hex checksum: '+name)
    app='websock_adapter' if name=='gaoxy_websock_adapter' else name
    require(hexmeta['version']==VERSION and hexmeta['meta']['app']==app
            and hexmeta['retirement'] is None, 'Hex app/version/retirement: '+name)
    reqs=hexmeta['requirements']
    require(reqs==info['hex_requirements'] and 'hpax' not in json.dumps(reqs).lower(), 'Hex requirements: '+name)
    for sibling in set(reqs)&set(packages):
        require(reqs[sibling]['requirement']=='== '+VERSION, 'sibling version: '+name)
        require(reqs[sibling]['optional']==(name=='gaoxy_test' and sibling=='gaoxy_http3'), 'sibling optionality')
    if name=='gaoxy_websock_adapter':
        require(all(reqs[n]['optional'] for n in ['bandit','plug_cowboy']), 'adapter optional peers')
    if name=='gaoxy_http':
        require(reqs['http_core']['requirement']=='~> 0.21 and >= 0.21.17', 'http_core floor')
    with tarfile.open(fileobj=io.BytesIO(raw)) as tar:
        config=tar.extractfile('metadata.config').read().decode()
        for key,value in [('name',name),('version',VERSION),('app',app)]:
            require(re.findall(r'^\{<<"'+key+r'">>,\s*<<"([^"\n]+)">>\}',config,re.M)==[value], 'package config identity')
        content=tar.extractfile('contents.tar.gz').read()
    with tarfile.open(fileobj=io.BytesIO(content), mode='r:gz') as tar:
        members={m.name:m for m in tar.getmembers()}
        actual={n for n,m in members.items() if n.startswith(('lib/','priv/')) and not m.isdir()}
        source={}
        tree=git('ls-tree','-r','-z',SHA,'--',root+'/lib',root+'/priv')
        for entry in tree.split(b'\0'):
            if not entry:continue
            fields,path=entry.split(b'\t',1); mode,kind,blob=fields.decode().split(); path=path.decode()
            require(kind=='blob' and mode in ['100644','100755'], 'source file kind')
            source[path[len(root)+1:]]=(path,blob)
        require(actual==set(source)==set(info['source_files']), 'package source set: '+name)
        for rel,(path,blob) in source.items():
            data=git('show',SHA+':'+path); noted=info['source_files'][rel]
            require(tar.extractfile(members[rel]).read()==data, 'package source bytes: '+path)
            require(noted=={'source_path':path,'source_commit':SHA,'git_blob_sha':blob,'sha256':digest(data),'bytes':len(data)},'source receipt entry')
        manifest=tar.extractfile('mix.exs').read().decode()
        require(re.findall(r'\bapp:\s*:([a-z_][a-z0-9_]*)',manifest)==[app], 'staged app')
        require(re.findall(r'\bversion:\s*"([^"\n]+)"',manifest)==[VERSION], 'staged version')
        for path, noted in info['manifests'].items():
            data=tar.extractfile(path).read()
            require({'bytes':len(data),'sha256':digest(data)}==noted and b'hpax' not in data.lower(), 'staged manifest hash')
    package_counts[name]=len(source)
    require(len(source)==info['source_file_count'], 'package source count')
    published='Package published to https://hex.pm/packages/'+name+'/'+VERSION+' ('+digest(raw)+')'
    require(published in steps['Publish and verify Hex packages'], 'release published checksum: '+name)
require(sum(package_counts.values())==artifact['package_source_file_count']==151, 'source total')
build=artifact['release_build']; zip_path=ART/'release-actions-artifact.zip'
require(digest(read(zip_path))==build['download_sha256'] and build['artifact_digest']=='sha256:'+build['download_sha256'], 'Actions ZIP digest')
require(build['run_id']==41035876876 and build['head_sha']==SHA and build['head_branch']=='main'
        and build['workflow_path']=='.github/workflows/release.yml' and build['conclusion']=='success'
        and build['event']=='workflow_dispatch' and build['cryptographic_build_attestation_verified'] is False, 'Actions provenance')
with zipfile.ZipFile(zip_path) as z:
    require(len(z.namelist())==8 and set(z.namelist())==set(assets), 'Actions ZIP set')
    for name in assets: require(z.read(name)==read(ART/name), 'Actions/public bytes: '+name)
passed('public_artifacts', {'assets':8,'payload_checksums':7,'hex_packages':6,'source_file_counts':package_counts,
       'source_files_total':sum(package_counts.values()),'actions_zip_payloads_equal':8,
       'cryptographic_build_attestation':'NOT VERIFIED'})

standalone=artifact['standalone']
with tarfile.open(ART/f'gaoxy-{VERSION}-linux-x86_64.tar.gz') as tar:
    members={m.name.removeprefix('./'):m for m in tar.getmembers()}
    def payload(name):return tar.extractfile(members[name]).read()
    require(payload('releases/start_erl.data').decode().split()==['16.4.0.7',VERSION], 'active boot selection')
    rel=payload(standalone['release_metadata_path'])
    require(digest(rel)==standalone['release_metadata_sha256'], 'release metadata digest')
    require(digest(payload(f'releases/{VERSION}/start.boot'))==standalone['start_boot_sha256'], 'active boot digest')
    for app,info in {**standalone['applications'],**standalone['dependencies']}.items():
        data=payload(info['metadata_path'])
        require(digest(data)==info['metadata_sha256'], 'active application metadata digest')
        require(re.findall(r'\{'+app+r',\s*"([^"\n]+)",',rel.decode())==[info['version']], 'active release app version')
        require(re.findall(r'\{vsn,\s*"([^"\n]+)"\}',data.decode())==[info['version']], 'active app version')
    app_metadata={n for n in members if n.startswith('lib/') and n.endswith('.app')}
    require(app_metadata==set(standalone['runtime_application_metadata']) and len(app_metadata)==39, 'runtime metadata cohort')
    for path, info in standalone['runtime_application_metadata'].items():
        data=payload(path)
        require(digest(data)==info['sha256'] and len(data)==info['bytes'] and b'hpax' not in data.lower(), 'runtime metadata hash/HPAX')
    old_dirs=sorted({n.split('/')[1] for n in members if n.startswith('lib/gaoxy') and '-0.13.0/' in n})
    expected_old=['gaoxy-0.13.0','gaoxy_http-0.13.0','gaoxy_http3-0.13.0',
                  'gaoxy_proxy-0.13.0','gaoxy_server-0.13.0']
    require(old_dirs==expected_old, 'inactive directory cohort differs')
    forbidden=[n for n in members if n.startswith('lib/') and re.search(r'gaoxy_test|exunit|hpax',n,re.I)]
    require(not forbidden, 'test-only/HPAX runtime library present')
    launcher=payload('bin/gaoxy')
    require(b'cut -d\' \' -f2 "$RELEASE_ROOT/releases/start_erl.data"' in launcher
            and b'REL_VSN_DIR="$RELEASE_ROOT/releases/$RELEASE_VSN"' in launcher
            and b'--boot "$REL_VSN_DIR/$RELEASE_BOOT_SCRIPT"' in launcher,
            'launcher default selection differs')
    start_script=payload(f'releases/{VERSION}/start.script')
    start_boot=payload(f'releases/{VERSION}/start.boot')
    for name in standalone['applications']:
        path=(name+'-'+VERSION+'/ebin').encode()
        require(path in start_script and path in start_boot, 'own active code path absent')
    require(b'0.13.0' not in start_script and b'0.13.0' not in start_boot, 'old code selected by active boot')
    selector={'status':'PASS_DEFAULT_ACTIVE_BOOT_SELECTION','active_version':VERSION,
              'default_launcher':'bin/gaoxy reads release version from releases/start_erl.data',
              'start_erl_data':'16.4.0.7 0.14.0','active_own_application_versions':dict.fromkeys(standalone['applications'],VERSION),
              'inactive_old_directories':['lib/'+n for n in old_dirs],
              'old_directories_are':'five own production applications, not test helpers',
              'active_script_and_boot_have_all_five_current_ebin_paths':True,
              'active_script_or_boot_references_0_13_0':False,
              'forbidden_lib_path_matches':forbidden,
              'classification':'Nonblocking artifact hygiene limitation; redundant old code remains packaged. Default boot selects current apps; ordinary runtime13 and separate production-isolation evidence pass. No arbitrary operator override or manual code-path manipulation is qualified.',
              'evidence_sha256':{n:digest(payload(n)) for n in ['bin/gaoxy','releases/start_erl.data',f'releases/{VERSION}/gaoxy.rel',f'releases/{VERSION}/start.script',f'releases/{VERSION}/start.boot']}}
    (OUT/'standalone-selection.json').write_text(json.dumps(selector,indent=2)+'\n')
passed('standalone_archive',{'active_version':VERSION,'active_own_apps':5,'runtime_metadata_count':39,
       'old_inactive_directories_present':old_dirs,'hpax':'absent in runtime lib directories and application metadata',
       'gaoxy_test_exunit_runtime_dirs':'absent','active_boot_old_version_reference':False,
       'artifact_hygiene_disclosure':'old five production-app directories remain packaged; default boot uses current versions'})

runtime_dir=BASE/'release-verification/downloaded-runtime-vum23agp'
runtime=load(runtime_dir/'receipt.json')
require(runtime['status']=='PASS' and runtime['source_commit']==SHA and runtime['version']==VERSION
        and runtime['processes_stopped'] is True and runtime['verified_checks']==13, 'runtime terminal state')
require(digest(read(BASE/'release-verification/downloaded-runtime.py'))==runtime['runner_sha256']=='38bfa27744abe97b58affff00505de65a32844dcfe697ec7534b2dd0f8c80ff8', 'runtime helper digest')
require(runtime['artifact_verifier_sha256']==artifact['verifier_sha256'] and runtime['archive_sha256']==sums[f'gaoxy-{VERSION}-linux-x86_64.tar.gz'], 'runtime archive binding')
for path, h in runtime['script_hashes'].items():
    require(digest(read(ROOT/path))==digest(git('show',SHA+':'+path))==h, 'runtime script hash')
require([c['name'] for c in runtime['checks']]==['core','gateway','h3'], 'runtime check cohort')
for check, expected in zip(runtime['checks'],[3,7,3]):
    require(check['status']=='PASS' and check['exit']==0 and check['process_group_gone'] is True
            and check['expected_checks']==check['verified_checks']==expected, 'runtime command state')
    require(runtime['release'] in check['command'], 'command did not select downloaded release')
    require(digest(read(check['log']))==check['log_sha256'], 'runtime log digest')
require('; 3 transports' in (runtime_dir/'core.log').read_text(), 'actual core count')
require('; 7 exchanges' in (runtime_dir/'gateway.log').read_text(), 'actual gateway count')
require(json.loads((runtime_dir/'h3.log').read_text())=={'status':'PASS','checks':3}, 'actual H3 count')
h3=load(runtime_dir/'h3/result.json')
require(h3['status']=='PASS' and len(h3['checks'])==3 and all(c['status']=='PASS' for c in h3['checks']), 'H3 detail')
require(h3['release']==runtime['release'] and h3['child_exits']=={'release':0,'origin':0} and h3['ports_rebound'] is True, 'H3 cleanup')
responses=h3['native_h3_peer']['receipt']['responses']
require(len(responses)==2 and all(r['ended'] for r in responses) and len({r['connection_id'] for r in responses})==1, 'H3 native peer responses')
require([r['data_bytes'] for r in h3['origin_requests']]==[3,0]
        and all(r['request_fin'] and r['fin_count']==1 and r['trailer_blocks']==1 for r in h3['origin_requests']), 'H3 origin payload/trailer proof')
passed('downloaded_runtime', {'core':3,'gateway':7,'h3':3,'total':13,'exit_each':0,
       'natural_process_groups_gone':3,'h3_child_exits':h3['child_exits'],'ports_rebound':True,
       'host_compatibility_scope':runtime['host_environment_scope']})

frozen=BASE/'publication-gates-review/source-ci-receipt.json'
require(digest(read(frozen))=='0147fa1c1aef060e07bebeacb489702e933a2892612cdcc5ef09a62ee8bf9278', 'frozen source CI receipt changed')
passed('frozen_source_ci',{'receipt_sha256':digest(read(frozen)),'mutated':False,'verifier_rerun':False})
manifest_path=ROOT/'docs/acceptance/evidence/adaptive-resource-budget/delivery014/archive-manifest.json'
archive=load(manifest_path)
require(len(archive['archive_entries'])==66, 'archived original count')
for entry in archive['archive_entries']:
    original=read(ROOT/entry['original']); packed=read(ROOT/entry['archive'])
    require(gzip.decompress(packed)==original and digest(original)==entry['sha256']
            and len(original)==entry['bytes'] and digest(packed)==entry['archive_sha256'], 'archive original mismatch')
passed('immutable_archive_snapshot',{'entries':66,'manifest_sha256':digest(read(manifest_path)),
       'status_at_snapshot':archive['status'],'binary_payloads_excluded':True})

tagraw=subprocess.check_output(['gh','api','repos/gsmlg-dev/gaoxy/git/ref/tags/v0.14.0'],cwd=ROOT,timeout=30)
tag=json.loads(tagraw)
require(tag['object']=={'sha':SHA,'type':'commit','url':'https://api.github.com/repos/gsmlg-dev/gaoxy/git/commits/'+SHA}, 'live tag target')
(OUT/'remote-tag.json').write_bytes(tagraw)
passed('live_remote_tag',{'tag':'v'+VERSION,'commit':SHA})
result={'status':'PASS','source':SHA,'version':VERSION,'verified_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'checks':checks,'limitations':{'cryptographic_build_attestation':'NOT VERIFIED',
        'native_macos_windows_memory_probes':'NOT RUN','specialist_pressure_slow_peer_sustained_load':'NOT RUN',
        'production_deployment':'NOT RUN'},'commands_terminal':True,'test_build_runtime_execution_by_this_review':False}
(OUT/'validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
