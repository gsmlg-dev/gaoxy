#!/usr/bin/env python3
"""Serialize final task gates with the existing immutable-receipt runner."""
import argparse
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
RUNNER = ROOT / '.audit/adaptive-resource-budget/run-qualified.py'
PEER = str(ROOT / '.audit/h2peer/bin/python')
PROTOCOL_PEER = str(ROOT / '.audit/adaptive-resource-budget/peer-hpack42/bin/python')
EVIDENCE = ROOT / '.audit/adaptive-resource-budget/qualification'
GROUPS = {
    'static-package': [
        ('inventory', '.', [], ['python3', 'scripts/check-test-inventory.py']),
        ('workflow', '.', [], ['actionlint', '.github/workflows/release.yml']),
        ('format', '.', [], ['mix', 'format', '--check-formatted']),
        ('compile', '.', [], ['mix', 'compile', '--warnings-as-errors']),
        ('staging', '.', [], ['python3', 'scripts/test-stage-hex-packages.py']),
        ('built-consumers', '.', [], ['python3', 'scripts/test-consumers.py']),
        *[(name, '.', [], ['bash', 'scripts/' + script]) for name, script in [
            ('source-core', 'external-consumer.sh'),
            ('source-http', 'http-consumer.sh'),
            ('source-h3', 'h3-consumer.sh'),
            ('source-gateway', 'gateway-consumer.sh'),
            ('source-h3-gateway', 'h3-gateway-consumer.sh')]],
    ],
    'ordinary': [
        ('locked-deps', '.', [], ['mix', 'deps.get', '--check-locked']),
        ('all', '.', ['GAOXY_H2_PYTHON=' + PROTOCOL_PEER, 'GAOXY_QUIC_PYTHON=' + PROTOCOL_PEER], ['python3', 'scripts/check-repairs.py', 'all']),
        ('phoenix-deps', 'examples/phoenix_native', ['PHOENIX_NATIVE_H3=1'],
         ['mix', 'deps.get', '--check-locked']),
        ('phoenix-format', 'examples/phoenix_native', ['PHOENIX_NATIVE_H3=1'],
         ['mix', 'format', '--check-formatted', 'test/resource_budget_test.exs']),
        ('phoenix-tests', 'examples/phoenix_native', ['PHOENIX_NATIVE_H3=1'],
         ['python3', '../../scripts/check-tests.py']),
        ('reverse-proxy', '.', ['GAOXY_PROXY_EVIDENCE=.audit/adaptive-resource-budget/versioned-reverse-proxy'],
         [PEER, 'integration/reverse_proxy/run.py']),
        ('h2-rfc', '.', [], [PROTOCOL_PEER, 'integration/h2_rfc/run.py', '--evidence',
                             '.audit/adaptive-resource-budget/versioned-h2-rfc']),
    ],
    'phoenix': [
        ('phoenix-dev-deps', 'examples/phoenix_native',
         ['MIX_ENV=dev', 'PHOENIX_NATIVE_H2=1', 'PHOENIX_NATIVE_H3=1', 'PHOENIX_NATIVE_RELOAD=1'],
         ['mix', 'deps.get', '--check-locked']),
        ('phoenix-dev-compile', 'examples/phoenix_native',
         ['MIX_ENV=dev', 'PHOENIX_NATIVE_H2=1', 'PHOENIX_NATIVE_H3=1', 'PHOENIX_NATIVE_RELOAD=1'],
         ['mix', 'compile', '--warnings-as-errors']),
        ('phoenix-clients', '.', ['PHOENIX_NATIVE_H2=1',
          'GAOXY_PHOENIX_EVIDENCE=.audit/adaptive-resource-budget/versioned-phoenix-clients'],
         [PEER, 'integration/phoenix_native/gate.py']),
        ('phoenix-unified', '.',
         ['GAOXY_PHOENIX_EVIDENCE=.audit/adaptive-resource-budget/versioned-phoenix-unified'],
         [PEER, 'integration/phoenix_native/unified.py']),
    ],
    'standalone': [
        ('prod-compile', '.', ['MIX_ENV=prod'], ['mix', 'compile', '--warnings-as-errors']),
        ('release-build', '.', ['MIX_ENV=prod'], ['mix', 'release', 'gaoxy', '--overwrite']),
        ('release-core', '.', [], ['python3', 'scripts/release-smoke.py']),
        ('release-gateway', '.', [], [PEER, 'scripts/gateway-release-smoke.py']),
        ('release-h3', '.', [], [PEER, 'scripts/h3-release-smoke.py', '--evidence',
                                 '.audit/adaptive-resource-budget/versioned-release-h3']),
        ('portable-linux', '.', [], ['python3', 'scripts/portable-smoke.py', '--evidence',
                                     '.audit/adaptive-resource-budget/versioned-portable-linux']),
        ('optional-quic-deps', 'integration/quic_consumer', [], ['mix', 'deps.get', '--check-locked']),
        ('optional-quic-compile', 'integration/quic_consumer', [], ['mix', 'compile', '--warnings-as-errors']),
        ('optional-quic-tests', 'integration/quic_consumer', [], ['python3', '../../scripts/check-tests.py']),
    ],
}

parser = argparse.ArgumentParser()
parser.add_argument('group', choices=GROUPS)
parser.add_argument('--prefix', default='versioned014')
args = parser.parse_args()
for suffix, cwd, overrides, command in GROUPS[args.group]:
    label = args.prefix + '-' + suffix
    command = [item.replace('adaptive-resource-budget/versioned-', 'adaptive-resource-budget/' + args.prefix + '-') for item in command]
    overrides = [item.replace('adaptive-resource-budget/versioned-', 'adaptive-resource-budget/' + args.prefix + '-') for item in overrides]
    destination = EVIDENCE / (label + '.json')
    if destination.exists():
        raise SystemExit('Refusing to overwrite existing qualification receipt: ' + str(destination))
    invocation = [sys.executable, str(RUNNER), '--cwd', cwd, '--timeout', '1800']
    for override in overrides:
        invocation.extend(['--env', override])
    invocation.extend([label, '--', *command])
    print('START ' + label, flush=True)
    with (EVIDENCE / (label + '.driver.log')).open('w') as output:
        result = subprocess.run(invocation, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT)
    if destination.exists():
        receipt = json.loads(destination.read_text())
        print(json.dumps({key: receipt.get(key) for key in
                          ['label', 'status', 'exit', 'elapsed_seconds', 'source_changes']}), flush=True)
    else:
        print('MISSING RECEIPT ' + str(destination), flush=True)
    if result.returncode:
        print((EVIDENCE / (label + '.driver.log')).read_text()[-9000:], flush=True)
        raise SystemExit(result.returncode)
print('QUALIFICATION_GROUP_PASS ' + args.group, flush=True)
