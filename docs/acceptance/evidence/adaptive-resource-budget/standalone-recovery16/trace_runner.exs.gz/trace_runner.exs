tracer = spawn(fn ->
  loop = fn loop ->
    receive do
      {:trace_ts, pid, :call, {Gaoxy.Proxy.Gateway.Coordinator, :activate, [_coordinator, _store, _expected, router, deadline]}, timestamp} ->
        expiring = Enum.any?(router.routes, fn route -> match?({Gaoxy.Server.StandaloneRecoveryTest.ExpiredCandidate, _}, route.target) end)
        IO.inspect(%{pid: pid, event: :activate, expiring: expiring, deadline: deadline, at: System.convert_time_unit(timestamp, :native, :millisecond)}, label: "RACE_TRACE")
      {:trace_ts, pid, :call, {Gaoxy.HTTP.Generation.Store, :handle_call, [{:begin_prepare, deadline}, _from, _state]}, timestamp} ->
        IO.inspect(%{pid: pid, event: :prepare_begin, deadline: deadline, at: System.convert_time_unit(timestamp, :native, :millisecond)}, label: "RACE_TRACE")
      {:trace_ts, pid, :call, {Gaoxy.HTTP.Generation.Store, :handle_info, [{:prepare_timeout, _token}, _state]}, timestamp} ->
        IO.inspect(%{pid: pid, event: :prepare_timer, at: System.convert_time_unit(timestamp, :native, :millisecond)}, label: "RACE_TRACE")
      {:trace_ts, pid, :return_from, {module, function, arity}, result, timestamp} ->
        summary = if match?({:error, _}, result), do: result, else: :completed
        IO.inspect(%{pid: pid, event: {module, function, arity}, result: summary, at: System.convert_time_unit(timestamp, :native, :millisecond)}, label: "RACE_TRACE")
      _ -> :ok
    end
    loop.(loop)
  end
  loop.(loop)
end)
for module <- [Gaoxy.Proxy.Gateway.Coordinator, Gaoxy.HTTP.Generation, Gaoxy.HTTP.Generation.Store], do: Code.ensure_loaded!(module)
for {module,function,arity} <- [{Gaoxy.Proxy.Gateway.Coordinator,:activate,5},{Gaoxy.HTTP.Generation,:prepare,3}] do
  :erlang.trace_pattern({module,function,arity}, [{:_,[],[{:return_trace}]}], [:local])
end
:erlang.trace_pattern({Gaoxy.HTTP.Generation.Store,:handle_call,3}, [{[{:begin_prepare,:_},:_,:_],[],[]}], [:local])
:erlang.trace_pattern({Gaoxy.HTTP.Generation.Store,:handle_info,2}, [{[{:prepare_timeout,:_},:_],[],[]}], [:local])
:erlang.trace(:new_processes,true,[:call,:monotonic_timestamp,{:tracer,tracer}])
Mix.Task.run("test", ["apps/gaoxy_server/test/standalone_recovery_test.exs", "--seed", "0", "--max-cases", "1"])
