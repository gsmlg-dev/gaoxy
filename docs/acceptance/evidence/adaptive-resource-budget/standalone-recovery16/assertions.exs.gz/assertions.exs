base = ".audit/adaptive-resource-budget/core/time-quota/standalone-recovery16"
file = "apps/gaoxy_server/test/standalone_recovery_test.exs"
parse = fn path -> path |> File.read!() |> Code.string_to_quoted!() end
normalize = fn ast ->
  Macro.prewalk(ast, fn
    {form, metadata, arguments} when is_list(metadata) -> {form, [], arguments}
    other -> other
  end)
end
collect = fn ast, predicate ->
  {_, entries} = Macro.prewalk(ast, [], fn node, entries ->
    {node, if(predicate.(node), do: [normalize.(node) | entries], else: entries)}
  end)
  Enum.reverse(entries)
end
old = parse.(Path.join([base, "before", file]))
new = parse.(file)
assertion? = fn
  {name, _, _} when name in [:assert, :refute, :assert_receive, :refute_receive] -> true
  _ -> false
end
old_assertions = collect.(old, assertion?)
new_assertions = collect.(new, assertion?)
true = old_assertions == new_assertions
lifecycle? = fn
  {{:., _, [{:__aliases__, _, [:Lifecycle]}, name]}, _, _} when name in [:deadline, :remaining] -> true
  {{:., _, [:sys, name]}, _, _} when name in [:get_state, :suspend, :resume] -> true
  _ -> false
end
true = collect.(old, lifecycle?) == collect.(new, lifecycle?)
initializer? = fn
  {:defmodule, _, [{:__aliases__, _, [:ExpiredCandidate]}, _]} -> true
  _ -> false
end
true = collect.(old, initializer?) == collect.(new, initializer?)
report = %{status: "PASS", identical_assertions: length(old_assertions), identical_lifecycle_and_sys_calls: length(collect.(old, lifecycle?)), initializer_unchanged: true}
File.write!(Path.join(base, "assertions-check.json"), JSON.encode!(report) <> "\n")
IO.inspect(report, label: "ASSERTION_PRESERVATION_PASS")
