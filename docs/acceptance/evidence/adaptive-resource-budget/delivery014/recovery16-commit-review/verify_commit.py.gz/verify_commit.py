#!/usr/bin/env python3
"""Authenticate recovery16 commit, source bridge and new archives only."""
from pathlib import Path
import datetime
import gzip
import hashlib
import json
import re
import subprocess

ROOT = Path('/home/gao/Workspace/gsmlg-opt/gaoxy')
OUT = Path(__file__).resolve().parent
NEW = 'e3afc810481c396c63dff1f6f81230b456511016'
PRIOR = 'e57fb086f5aa2093767832699907f3430f8334a6'
ORIGINAL = '4f39c9e49f6e7c2147bfaa3a8ca4ae7290506d28'
TEST = 'apps/gaoxy_server/test/standalone_recovery_test.exs'
ARCH = ROOT / 'docs/acceptance/evidence/adaptive-resource-budget'
def sha(x): return hashlib.sha256(x).hexdigest()
def load(p): return json.loads(p.read_text())
def git(*args): return subprocess.check_output(['git', *args], cwd=ROOT)
def archived(p): return json.loads(gzip.decompress((ARCH / p).read_bytes()))
assert git('rev-parse', 'HEAD').decode().strip() == NEW
assert git('rev-parse', 'HEAD^').decode().strip() == PRIOR
assert git('branch', '--show-current').decode().strip() == 'main'
bridge_path = ROOT / '.audit/adaptive-resource-budget/publication-source-bridge-recovery16.json'
bridge = load(bridge_path)
prior_bridge = load(ROOT / '.audit/adaptive-resource-budget/publication-source-bridge-fixture15.json')
original = load(ROOT / '.audit/adaptive-resource-budget/core/time-quota/hosted-network15/before-hashes.json')
current = bridge['source_hashes']
assert bridge['status'] == 'PASS_SOURCE_BRIDGE'
assert bridge['publication_sha'] == NEW and bridge['prior_candidate_sha'] == PRIOR
assert bridge['original_candidate_sha'] == ORIGINAL
assert bridge['commit_and_worktree_exact'] and len(current) == bridge['source_inputs'] == 682
assert sorted(p for p in current if current[p] != prior_bridge['source_hashes'][p]) == bridge['changed_from_prior'] == [TEST]
original_drift = sorted(p for p in current if current[p] != original[p])
assert original_drift == bridge['changed_from_original'] and len(original_drift) == 5
assert bridge['unchanged_from_prior'] == 681 and bridge['unchanged_from_original'] == 677
assert bridge['production_dependency_workflow_version_changes'] == []
for p, h in current.items():
    assert sha(git('show', f'{NEW}:{p}')) == h and sha((ROOT / p).read_bytes()) == h, p
    assert sha(git('show', f'{PRIOR}:{p}')) == prior_bridge['source_hashes'][p], p
    assert sha(git('show', f'{ORIGINAL}:{p}')) == original[p], p
delta = git('diff', '--src-prefix=i/', '--dst-prefix=w/', PRIOR, NEW, '--', TEST)
assert delta == (ROOT / '.audit/adaptive-resource-budget/core/time-quota/standalone-recovery16/task.patch').read_bytes()

archives = []
manifests = []
for name, count in (('hosted-e57-before-recovery16', 28), ('standalone-recovery16', 34), ('standalone-recovery16-review', 8)):
    path = ARCH / name / 'archive-manifest.json'
    m = load(path)
    assert len(m['archive_entries']) == count
    assert git('show', f'{NEW}:{path.relative_to(ROOT)}') == path.read_bytes()
    manifests.append(str(path.relative_to(ROOT)))
    for e in m['archive_entries']:
        file = ROOT / e['archive']
        raw = file.read_bytes()
        assert sha(raw) == e['archive_sha256']
        assert raw == git('show', f'{NEW}:{e["archive"]}')
        plain = gzip.decompress(raw)
        assert len(plain) == e['bytes'] and sha(plain) == e['sha256']
        assert plain == (ROOT / e['original']).read_bytes()
        archives.append(e)
assert len(archives) == 70 and len({e['archive'] for e in archives}) == 70
expected = set([TEST, 'docs/acceptance/adaptive-resource-budget.md', 'docs/plans/adaptive-resource-budget.md'] +
               manifests + [e['archive'] for e in archives])
actual = set(git('diff', '--name-only', PRIOR, NEW).decode().splitlines())
assert actual == expected and len(actual) == 76

parent_path = ROOT / bridge['parent_post_review_receipt']
parent = load(parent_path)
assert parent['source'] == PRIOR and parent['source_hashes'] == current
assert parent['status'] == 'PASS' and parent['exit'] == 0 and parent['commands_terminal']
assert parent['source_changes'] == []
parent_log = ROOT / parent['log']
assert sha(parent_log.read_bytes()) == parent['log_sha256']
assert re.findall(r'(?m)^\s*(\d+) tests?, (\d+) failures?', parent_log.read_text()) == [('2', '0')]
assert bridge['parent_post_review_counts'] == '2/0'
review_path = ROOT / '.audit/adaptive-resource-budget/standalone-recovery16-review/receipt.json'
review = load(review_path)
assert sha(review_path.read_bytes()) == bridge['review_receipt_sha256']
for k in ('report', 'validation'):
    assert sha((ROOT / review[k]['path']).read_bytes()) == review[k]['sha256']
assert review['all_original_assertions'] == 37 and review['all_original_lifecycle_sys_calls'] == 24
assert review['deadlines_cleanup_recovery_unchanged'] and review['findings'] == []

e57 = archived('hosted-e57-before-recovery16/delivery/source-ci-e57fb086-failure/run.json.gz')
assert e57['headSha'] == PRIOR and e57['conclusion'] == 'failure'
jobs = {j['name']:j['conclusion'] for j in e57['jobs']}
assert jobs == {'isolated-network': 'success', 'component': 'success', 'protocol': 'failure', 'release-clients': 'skipped'}
e4 = archived('network-fixture15/delivery/41029385382.json.gz')
assert e4['headSha'] == ORIGINAL and e4['conclusion'] == 'failure'
docs = {}
for p in ('docs/acceptance/adaptive-resource-budget.md', 'docs/plans/adaptive-resource-budget.md'):
    text = (ROOT / p).read_text()
    assert git('show', f'{NEW}:{p}') == text.encode()
    assert 'pending' in text.lower() or 'remain open' in text
    assert 'publication' in text and '16' in text
    docs[p] = sha(text.encode())
text = (ROOT / 'docs/acceptance/adaptive-resource-budget.md').read_text()
for s in ('41032538320', '2 cases / 1 failure', 'This remains a failed candidate',
          'After that review the parent freshly reran the original command, passing2/0',
          'New exact-source CI and guarded delivery remain required', 'failure is preserved as FAIL'):
    assert s in text, s
result = {'status':'PASS', 'verified_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'commit':NEW, 'parent':PRIOR, 'original':ORIGINAL, 'branch':'main',
          'source_inputs':682, 'unchanged_from_prior':681, 'changed_from_prior':[TEST],
          'unchanged_from_original':677, 'changed_from_original':original_drift,
          'all_production_dependencies_workflows_versions_unchanged':True,
          'source_bridge_sha256':sha(bridge_path.read_bytes()), 'committed_paths':76,
          'archives':{'total_originals':70,'hosted_e57':28,'worker':34,'review':8,'all_byte_hashes_commit_and_originals_match':True},
          'parent_postreview':{'receipt_sha256':sha(parent_path.read_bytes()),'log_sha256':parent['log_sha256'],'tests':2,'failures':0,'source_map_matches_new_commit':True},
          'review_receipt_sha256':sha(review_path.read_bytes()), 'preserved_hosted_failures':[e4['databaseId'],e57['databaseId']],
          'status_document_hashes':docs, 'old_35gate_audit_repeated':False,
          'new_ci':'PENDING_NOT_QUERIED_BY_REVIEWER','publication':'PENDING_NOT_QUERIED_BY_REVIEWER',
          'reviewer_tests_build_runtime_network_privilege_run':False,'reviewer_commands_terminal':True}
(OUT/'validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
