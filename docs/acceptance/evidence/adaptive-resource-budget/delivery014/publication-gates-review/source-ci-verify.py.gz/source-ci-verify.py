#!/usr/bin/env python3
"""Read-only authentication of captured fresh source-CI and dispatch evidence."""
from pathlib import Path
import datetime
import gzip
import hashlib
import json
import re
import subprocess

ROOT=Path('/home/gao/Workspace/gsmlg-opt/gaoxy')
BASE=ROOT/'.audit/adaptive-resource-budget/delivery'
OUT=Path(__file__).resolve().parent
SHA='e3afc810481c396c63dff1f6f81230b456511016'
IDS={41034773881:'Static checks and build',41034773788:'Unit tests',41034773764:'Integration and end-to-end tests',41034773758:'Package and consumer qualification',41034773863:'Portable HTTP smoke'}
def digest(data):return hashlib.sha256(data).hexdigest()
def load(path):return json.loads(path.read_text())
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
hashes={}
def capture(path):
    hashes[str(path.relative_to(ROOT))]=digest(path.read_bytes())
    return path

assert git('rev-parse','HEAD').decode().strip()==SHA
summary=load(capture(BASE/'source-ci-e3afc810/summary.json'))
assert summary['source_sha']==SHA and summary['status']=='PASS'
assert {r['databaseId'] for r in summary['runs']}==set(IDS)
runs={}
for rid,name in IDS.items():
    r=load(capture(BASE/f'source-ci-e3afc810/{rid}.json'))
    assert r['databaseId']==rid and r['headSha']==SHA and r['workflowName']==name
    assert r['status']=='completed' and r['conclusion']=='success'
    assert r['event']=='push' and r['headBranch']=='main'
    matches=[x for x in summary['runs'] if x['databaseId']==rid]
    assert len(matches)==1
    for field in ('headSha','workflowName','status','conclusion'):assert matches[0][field]==r[field]
    for job in r['jobs']:
        if job['name']=='release-clients':assert job['conclusion']=='skipped'
        else:
            assert job['conclusion']=='success'
            assert all(s['conclusion']=='success' for s in job['steps'])
    runs[rid]=r
history_path=capture(BASE/'source-ci-e3afc810/status-history.jsonl')
history=[json.loads(line) for line in history_path.read_text().splitlines() if line.strip()]
assert len(history)==5
for checkpoint in history:
    assert {r['databaseId'] for r in checkpoint['runs']}==set(IDS)
    assert all(r['headSha']==SHA for r in checkpoint['runs'])
assert all(r['status']=='completed' and r['conclusion']=='success' for r in history[-1]['runs'])

logs_receipt=load(capture(BASE/'source-ci-e3afc810-completed-logs/receipt.json'))
assert logs_receipt['source_sha']==SHA and logs_receipt['status']=='PASS_ALL_FIVE_SOURCE_WORKFLOWS'
assert logs_receipt['commands_exit']==0 and len(logs_receipt['logs'])==5
groups={}
for item in logs_receipt['logs']:
    path=capture(ROOT/item['path'])
    assert path.stat().st_size==item['bytes'] and digest(path.read_bytes())==item['sha256']
    rid=int(path.stem);assert rid in IDS
    for line in path.read_text().splitlines():
        columns=line.split('\t',2)
        if len(columns)!=3:continue
        job,step,payload=columns
        payload=payload.split(' ',1)[1] if ' ' in payload else payload
        groups.setdefault((rid,job,step),[]).append(payload)
    stderr=capture(path.with_suffix('.stderr'));assert stderr.read_bytes()==b''

canonical={}
all_commands=[]
for rid,job,step,total,files in [
 (41034773788,'unit','Isolated unit contracts (exact counts, no service requests)',390,54),
 (41034773764,'component','Component collaboration (exact counts)',323,28),
 (41034773764,'protocol','Ordinary network and protocol regressions (exact counts)',187,39)]:
    lines=groups[(rid,job,step)]
    counts=[]
    for line in lines:
        match=re.fullmatch(r'\s*(\d+) tests?, (\d+) failures?(.*)',line)
        if match:
            n,f,tail=match.groups();assert int(n)>0 and int(f)==0
            assert not re.search(r'[1-9]\d* (excluded|skipped)',tail)
            counts.append(int(n))
    commands=[x for x in lines if x.startswith('REPAIR_COMMAND ')]
    assert len(commands)==len(counts)==files and sum(counts)==total
    assert lines.count(f'REPAIR_PASS {total} executed, 0 failures, 0 excluded, 0 skipped')==1
    all_commands.extend(commands)
    canonical[job]={'tests':total,'files':files,'positive_summaries':len(counts),'failures':0,'excluded':0,'skipped':0}
assert len(all_commands)==len(set(all_commands))==121

network=[]
for (rid,job,step),lines in groups.items():
    if rid!=41034773764 or job!='isolated-network':continue
    for line in lines:
        if not line.startswith('{"result":'):continue
        r=json.loads(line);assert r['result']=='PASS'
        assert len([x for x in lines if x.startswith('PASS ')])==r['count']
        if 'backend' in r:assert r['peer_capability_notices']==[] and len(r['gates'])==r['count']
        else:assert r['transports']==5 and r['independent_peers']==2
        network.append({'step':step,'count':r['count'],'suite':r['suite'],'backend':r.get('backend')})
assert [x['count'] for x in network]==[13,21,13,20,11,11] and sum(x['count'] for x in network)==89
counts=load(capture(BASE/'source-e3-canonical-counts.json'))
assert counts['source_sha']==SHA and counts['total']==900
assert counts['canonical']=={k:v['tests'] for k,v in canonical.items()}
assert counts['failures']==counts['excluded']==counts['skipped']==0
assert counts['network_gate_counts']==[x['count'] for x in network] and counts['network_gates']==89
for path,h in counts['logs'].items():assert digest((ROOT/path).read_bytes())==h

portable=[]
for (rid,job,step),lines in groups.items():
    if rid!=41034773863:continue
    for line in lines:
        if line.startswith('GAOXY_PORTABLE_PASS '):
            r=json.loads(line.removeprefix('GAOXY_PORTABLE_PASS '))
            assert r['status']=='PASS' and r['source']==SHA and r['requests']==1
            assert r['stopped'] is True and r['exit']==0 and r['mode']=='candidate-source-boot'
            portable.append(r)
assert len(portable)==2 and any(x['platform'].startswith('macOS') for x in portable) and any(x['platform'].startswith('Linux') for x in portable)
smoke=git('show',f'{SHA}:integration/portable_smoke/smoke.exs').decode()
assert 'path: "/health"' in smoke and '{:ok, {{_, 200, _}, _, "ok"}}' in smoke and 'Gaoxy.stop(runtime, 3_000)' in smoke

def summaries(lines):return [(int(n),int(f)) for line in lines for n,f in re.findall(r'^\s*(\d+) tests?, (\d+) failures?',line)]
package=groups[(41034773758,'package','Isolated built-package consumers and production isolation')]
assert summaries(package)==[(3,0),(2,0),(2,0)]
for marker in ('CONSUMER_PASS base','CONSUMER_PASS h3','CONSUMER_PASS http_fetch','CONSUMER_RELEASE_ISOLATION_PASS cases=1 helper_absent=true exunit_absent=true'):assert marker in package
assert summaries(groups[(41034773758,'package','Source core and Gateway consumers')])==[(1,0),(1,0),(1,0)]
assert summaries(groups[(41034773758,'optional-quic','Locked optional consumer and independent validating aioquic peer')])==[(4,0)]
staging=groups[(41034773758,'package','Hex staging and package regressions')]
assert any(line.startswith('Ran 12 tests in ') for line in staging) and 'OK' in staging
assert any('PASS portable release TCP/TLS/UDP startup' in line and '3 transports' in line for line in groups[(41034773758,'package','Source-built standalone release smoke')])
assert summaries(groups[(41034773764,'component','Phoenix component regressions (nonempty)')])==[(27,0)]
native=[json.loads(line) for line in groups[(41034773764,'protocol','Native Phoenix HTTP, TLS and WebSocket clients')] if line.startswith('{"status":')]
assert len(native)==1 and native[0]['status']=='PASS' and native[0]['executed_checks']==10 and native[0]['source_restored']
unified=[json.loads(line) for line in groups[(41034773764,'protocol','Unified H1/H2/H3 clients, WebSocket and reload')] if line.startswith('{"status":')]
assert len(unified)==1 and unified[0]['status']=='PASS' and len(unified[0]['checks'])==8
assert all(c['status']=='PASS' for c in unified[0]['checks']) and unified[0]['source_restored']
rfc=[json.loads(line) for line in groups[(41034773764,'protocol','Independent selected H2 RFC cases')] if line.startswith('{"name":')]
assert len(rfc)==40 and all(x['status']=='PASS' for x in rfc)
reverse=groups[(41034773764,'protocol','Independent streaming reverse-proxy example')]
start=reverse.index('{');rev=json.loads('\n'.join(reverse[start:]))
assert len(rev['results'])==6 and all(x['status']=='PASS' for x in rev['results'])

bridge_path=capture(ROOT/'.audit/adaptive-resource-budget/publication-source-bridge-recovery16.json')
bridge=load(bridge_path);assert bridge['publication_sha']==SHA and len(bridge['source_hashes'])==682
commit_review=load(ROOT/'.audit/adaptive-resource-budget/recovery16-commit-review/receipt.json')
assert digest(bridge_path.read_bytes())==commit_review['source_bridge_sha256']
preflight=load(capture(BASE/'release-preflight-e3afc810.json'))
assert preflight['publication_sha']==preflight['remote_main_sha']==SHA and preflight['version']=='0.14.0'
assert preflight['status']=='PASS_READY_FOR_AUTHORIZED_DISPATCH' and preflight['source_inputs']==682
assert {r['databaseId'] for r in preflight['source_workflows']}==set(IDS)
assert all(r['headSha']==SHA and r['status']=='completed' and r['conclusion']=='success' for r in preflight['source_workflows'])
assert preflight['review_receipt_sha256']==digest((ROOT/'.audit/adaptive-resource-budget/recovery16-commit-review/receipt.json').read_bytes())
assert len(preflight['version_checks'])==8 and all(x['status']==404 for x in preflight['version_checks'])
assert preflight['existing_release_runs_on_sha']==[]
dispatch=load(capture(BASE/'release-dispatch-e3afc810.json'))
assert dispatch['publication_sha']==SHA and dispatch['status']=='DISPATCH_SUBMITTED' and dispatch['exit']==0
assert dispatch['command']==['gh','workflow','run','release.yml','--repo','gsmlg-dev/gaoxy','--ref','main','-f','version=0.14.0','-f','git_ref=main','-f',f'expected_sha={SHA}']
assert dispatch['stdout'].strip()=='https://github.com/gsmlg-dev/gaoxy/actions/runs/41035876876'
assert dispatch['stderr']==''
workflow=git('show',f'{SHA}:.github/workflows/e2e.yml').decode()
assert "github.event_name == 'workflow_dispatch'" in workflow and "inputs.version != ''" in workflow
historical=[]
for name,source,rid in [
 ('network-fixture15/delivery/41029385382.json.gz','4f39c9e49f6e7c2147bfaa3a8ca4ae7290506d28',41029385382),
 ('hosted-e57-before-recovery16/delivery/source-ci-e57fb086-failure/run.json.gz','e57fb086f5aa2093767832699907f3430f8334a6',41032538320)]:
    p=capture(ROOT/'docs/acceptance/evidence/adaptive-resource-budget'/name)
    r=json.loads(gzip.decompress(p.read_bytes()))
    assert r['databaseId']==rid and r['headSha']==source and r['conclusion']=='failure'
    historical.append({'run':rid,'source':source,'conclusion':'failure'})
result={'status':'PASS_SOURCE_CI_GATES','verified_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'source':SHA,'source_runs':{str(rid):{'workflow':r['workflowName'],'status':r['status'],'conclusion':r['conclusion'],'jobs':{j['name']:j['conclusion'] for j in r['jobs']}} for rid,r in runs.items()},
 'status_history_checkpoints':len(history),'canonical':canonical,'canonical_total':900,'positive_summaries':121,
 'network_gates':network,'network_total':89,'portable':portable,
 'package':{'staging_tests':12,'built_consumer_tests':7,'release_isolation':True,'source_consumer_tests':3,'optional_quic_tests':4,'source_built_release_transports':3},
 'additional':{'phoenix_component':27,'phoenix_clients':10,'unified_clients':8,'h2_rfc':40,'reverse_proxy':6},
 'manual_release_clients':'SKIPPED_BY_EXISTING_MANUAL_NONEMPTY_VERSION_GATE',
 'historical_failed_candidates':historical,
 'preflight':'CAPTURED_UNUSED_VERSION_AND_EXACT_SHA_READY','release_dispatch':{'run':41035876876,'status':'SUBMITTED_ONLY'},
 'public_release_artifact_runtime_acceptance':'NOT_COMPLETE_NOT_REVIEWED','whole_goal_delivered':False,
 'historical_capture_note':'Canonical-counts package PENDING_AT_CAPTURE and publication NOT_RUN precede final source summary/dispatch; preserved unchanged.',
 'artifact_hashes':hashes,'reviewer_tests_build_runtime_privilege_network_git_mutation':False,'reviewer_commands_terminal':True}
(OUT/'source-ci-validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('artifact_hashes','source_runs','network_gates','portable')},indent=2))
