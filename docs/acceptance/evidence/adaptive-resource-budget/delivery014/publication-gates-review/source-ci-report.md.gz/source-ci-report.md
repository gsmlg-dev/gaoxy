# Fresh source CI publication-gates evidence review

Task `ARB-PUBLICATION-SOURCE-CI-REVIEW`: **DONE**.
Verdict **EXACT_SOURCE_CI_GATES_ACCEPTED**; no material finding remains.
This direct independent Sol review accepts captured source-CI/preflight/dispatch
evidence only. Public release, artifacts and downloaded-runtime acceptance are
**NOT COMPLETE / NOT REVIEWED** here; the whole goal remains open.

Repository `/home/gao/Workspace/gsmlg-opt/gaoxy`, current branch `main`, source
`e3afc810481c396c63dff1f6f81230b456511016`. All five terminal workflow records,
five downloaded complete logs and their capture receipt were authenticated by
exact source, status, log byte length and SHA256. Five status-history checkpoints
retain the transition from in-progress to all-success; the final summary matches
the run records. Existing source-bridge SHA256 matches the independent accepted
commit review. The old35-gate/source review was not repeated.

| Exact-source workflow | Run | Result |
| --- | --- | --- |
| Static checks and build | 41034773881 | PASS |
| Unit tests | 41034773788 | PASS |
| Integration and end-to-end tests | 41034773764 | PASS |
| Package and consumer qualification | 41034773758 | PASS |
| Portable HTTP smoke | 41034773863 | PASS |

Every executed job and its steps succeed. E2E release-clients remains skipped
under its existing workflow_dispatch/nonempty-version condition; that separate
manual published-client gate is not claimed executed.

## Actual counts from complete logs

The reviewer independently parsed only each canonical command's own job/step,
matching every positive ExUnit summary to a unique REPAIR_COMMAND and requiring
its exact terminal zero-failure/exclusion/skip marker. Additional fixture/client/
consumer results were kept separate from the canonical900.

| Canonical suite | Commands and positive summaries | Executed cases | Failures / excluded / skipped |
| --- | ---: | ---: | --- |
| Unit | 54 | 390 | 0 / 0 / 0 |
| Component | 28 | 323 | 0 / 0 / 0 |
| Protocol | 39 | 187 | 0 / 0 / 0 |
| Total | 121 | 900 | 0 / 0 / 0 |

The six isolated-network summaries and actual PASS lines give13/21/13/20/11/11,
total89, all executed. This includes the retained socket IPv6 unsupported-send
negative assertion, not certification of supported socket IPv6 scoped sending.
Production-release and custom-handler suites each use five transports, two
independent peers and endpoint reuse after shutdown.

Further actual executed source evidence is Phoenix component27, independent
Phoenix clients10, unified H1/H2/H3/channel/reload8, H2 RFC40, and reverse-proxy6.
Their PASS/exit/source-restoration records are authenticated.

Package results are staging12, built-package consumers3+2+2=7, production release
isolation with helper and ExUnit absent, source core/Gateway consumers1+1+1=3,
and locked optional QUIC consumer4. The source-built standalone release smoke
passes its TCP/TLS/UDP3-transport traffic, drain/exit/reuse contract. Hosted
source-consumer3 is reported as executed, without substituting the historical
local9-case result.

Linux (Elixir1.18.5/OTP28.5) and macOS Intel (Elixir1.20.1/OTP29.0.2) each report
one candidate-source boot, exactly one request and successful stop at exacte3.
The frozen smoke makes GET /health require200 and bodyok before its monitored
normal stop and PASS marker. This is narrow portable HTTP evidence, not native
memory-probe or complete platform/product qualification.

## Preflight, dispatch and preserved history

The captured preflight at09:46:16Z names exacte3 for publication and remote main,
the accepted review-receipt hash,682 inputs, all five completed-success source
runs, version0.14.0, eight unused-version responses (six Hex releases plus tag
and GitHub release, each404), and no existing release run on the source at that
capture. These are authenticated recorded read-backs, not fresh network queries
by this reviewer.

The single recorded dispatch at09:46:33Z succeeds with version0.14.0,
git_ref/main and the full expected_sha guard, returning release run41035876876.
It proves submission only. The release's current verification/publication job
results, tag, six public packages, assets/checksums and downloaded runtime are
outside this verdict. No release completion is inferred from dispatch success
or the parent's in-progress report.

The earlier canonical-count receipt's packagePENDING_AT_CAPTURE and publication
NOT_RUN precede the final source summary/dispatch and retain their historical
meaning. They were not rewritten. Original hosted41029385382 at4f39 and
41032538320 ate57 remain authenticated FAIL records, separate from this new
exact-e3 sourcePASS.

## Reviewer verification and terminal handoff

Fresh command
`python3 .audit/adaptive-resource-budget/publication-gates-review/source-ci-verify.py`
returned exit0 at2026-10-30T09:57:23.685957Z. It authenticates captured files and
parses their actual output; no tests/build/runtime/network/privileged command
or Git mutation ran. An initial reviewer parser expected the reverse-proxy
object keychecks; its actual keyresults was inspected and the audit comparator
corrected before the full successful validation. This audit-only correction
changed no worker evidence, test, assertion or product repair counter.

Only this assigned audit directory was written. Prior writing verifiers were
not rerun. Reviewer product repairs0; one audit parser correction; no Astra
escalation. Cumulative implementation counters remain unchanged. All reviewer
commands are terminal and source-CI receipt/report writes stop at this handoff.
These receipts are frozen; any later public evidence audit must use separate
artifacts. Parent retains all release/public acceptance work and the existing
deployment/specialist/native-memory boundaries. No decision is needed for this
bounded source-CI acceptance.
