:telemetry.attach_many("hosted-network15-diagnosis", [[:gaoxy, :admission_rejected], [:gaoxy, :handler_error]], fn event, measurements, metadata, _ ->
  IO.inspect(%{event: event, measurements: measurements, service: metadata[:service], reason: metadata[:reason]}, label: "DIAG_TELEMETRY")
end, nil)
tracer = spawn(fn ->
  loop = fn loop, calls ->
    receive do
      {:trace, pid, :call, {Gaoxy.Admission, :handle_call, [request, _from, state]}} ->
        loop.(loop, Map.put(calls, pid, %{request: request, mode: state.mode, bytes: state.bytes, limits: state.limits, service: state.scope[:service], budget_pending: state.budget && state.budget.pending != nil}))
      {:trace, pid, :return_from, {Gaoxy.Admission, :handle_call, 3}, {:reply, {:error, reason}, _}} ->
        IO.inspect(Map.put(Map.fetch!(calls, pid), :rejection, reason), label: "DIAG_ADMISSION", limit: :infinity)
        loop.(loop, calls)
      {:trace, _pid, :call, {Gaoxy.DatagramBridge, :handle_data, [{peer, port, bytes}, _state]}} ->
        IO.inspect(%{peer: peer, port: port, bytes: byte_size(bytes)}, label: "DIAG_DATAGRAM")
        loop.(loop, calls)
      _ -> loop.(loop, calls)
    end
  end
  loop.(loop, %{})
end)
Code.ensure_loaded!(Gaoxy.Admission)
Code.ensure_loaded!(Gaoxy.DatagramBridge)
:erlang.trace_pattern({Gaoxy.Admission, :handle_call, 3}, [{:_, [], [{:return_trace}]}], [:local])
:erlang.trace_pattern({Gaoxy.DatagramBridge, :handle_data, 2}, true, [:local])
:erlang.trace(:new_processes, true, [:call, {:tracer, tracer}])
detection = Gaoxy.ResourceBudget.SystemMemory.detect()
IO.inspect(detection, label: "DIAG_CAPACITY", limit: :infinity)
safety = Gaoxy.ResourceBudget.Safety.detect(detection, read_file: fn path ->
  result = File.read(path)
  if path != "/proc/meminfo", do: IO.inspect({path, result}, label: "DIAG_SAFETY_READ")
  result
end)
IO.inspect(safety, label: "DIAG_SAFETY_RESULT", limit: :infinity)
IO.inspect(File.read("/proc/self/cgroup"), label: "DIAG_CGROUP_MEMBERSHIP")
{:ok, mountinfo} = File.read("/proc/self/mountinfo")
IO.inspect(Enum.filter(String.split(mountinfo, "\n"), &(String.contains?(&1, "cgroup") or String.contains?(&1, " /sys "))), label: "DIAG_NAMESPACE_MOUNTS", limit: :infinity)
IO.inspect(File.ls("/sys/fs/cgroup"), label: "DIAG_CONTROLLER_DIRECTORY")
{:ok, status} = File.read("/proc/self/status")
IO.inspect(Enum.filter(String.split(status, "\n"), &(String.starts_with?(&1, "Uid:") or String.starts_with?(&1, "Gid:"))), label: "DIAG_CHILD_IDENTITY")
IO.inspect(File.read_link("/proc/self/ns/net"), label: "DIAG_CHILD_NETWORK_NAMESPACE")
IO.inspect(:inet.getifaddrs() |> elem(1) |> Enum.map(&elem(&1, 0)), label: "DIAG_CHILD_INTERFACES")
