import importlib.util,pathlib,sys
root=pathlib.Path(__file__).resolve().parents[5]
source=root/'integration/network/fixture.py'
spec=importlib.util.spec_from_file_location('original_network_fixture',source)
fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
original=fixture.Child.__init__
def traced(self,owner,namespace,command,wire=False):
    if wire:
        command=command.copy();where=command.index('integration/network/server.exs');command[where:where]=['-r',str(pathlib.Path(__file__).with_name('trace.exs'))]
    return original(self,owner,namespace,command,wire=wire)
fixture.Child.__init__=traced
def verbose_read(self):
    for line in self.process.stdout:
        if self.wire:
            print("SERVER " + line.rstrip("\n"), flush=True)
        self.lines.put(line.rstrip("\n"))
    self.lines.put(None)
fixture.Child._read=verbose_read
import os,shutil,subprocess
print("DIAG_PARENT_NETNS",os.readlink('/proc/self/ns/net'),"UID",os.getuid(),"GID",os.getgid(),flush=True)
original_popen=subprocess.Popen
def netns_only(argv,*args,**kwargs):
    if isinstance(argv,list) and 'ip' in argv:
        at=argv.index('ip')
        if argv[at:at+3]==['ip','netns','exec']:
            name=argv[at+3]
            argv=argv[:at]+[shutil.which('nsenter'),f'--net=/run/netns/{name}','--']+argv[at+4:]
    return original_popen(argv,*args,**kwargs)
subprocess.Popen=netns_only
sys.exit(fixture.main())
