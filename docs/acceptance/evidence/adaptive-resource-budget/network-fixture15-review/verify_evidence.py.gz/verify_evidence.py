#!/usr/bin/env python3
"""Read-only source and receipt authentication; no test/runtime imports."""
import ast
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/home/gao/Workspace/gsmlg-opt/gaoxy')
BASE = ROOT / '.audit/adaptive-resource-budget/core/time-quota/hosted-network15'
OUT = Path(__file__).resolve().parent
HEAD = '4f39c9e49f6e7c2147bfaa3a8ca4ae7290506d28'
OWNED = {'integration/network/' + n for n in ('fixture.py', 'release_gate.py', 'example_gate.py', 'README.md')}
def digest(data):
    return hashlib.sha256(data).hexdigest()
def load(path):
    return json.loads(path.read_text())
def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

assert git('rev-parse', 'HEAD').decode().strip() == HEAD
assert git('branch', '--show-current').decode().strip() == 'main'
assert set(git('diff', 'HEAD', '--name-only').decode().splitlines()) == OWNED
before = load(BASE / 'before-hashes.json')
prior = load(ROOT / '.audit/adaptive-resource-budget/final-integrated14-review/validation.json')
assert before == prior['source_hashes']
assert len(before) == 682
current = {p: digest((ROOT / p).read_bytes()) for p in before}
assert {p for p in before if before[p] != current[p]} == OWNED
assert {p: current[p] for p in OWNED} == load(BASE / 'after-owned-hashes.json')
for p in before:
    assert digest(git('show', f'{HEAD}:{p}')) == before[p], p
for p in OWNED:
    assert (BASE / 'before' / p).read_bytes() == git('show', f'{HEAD}:{p}'), p
assert git('diff', '--src-prefix=i/', '--dst-prefix=w/', 'HEAD', '--', *sorted(OWNED)) == (BASE / 'task.patch').read_bytes()

assertion_counts = {}
for p in sorted(OWNED - {'integration/network/README.md'}):
    old = ast.parse((BASE / 'before' / p).read_text())
    new = ast.parse((ROOT / p).read_text())
    old_asserts = [ast.dump(n) for n in ast.walk(old) if isinstance(n, ast.Assert)]
    new_asserts = [ast.dump(n) for n in ast.walk(new) if isinstance(n, ast.Assert)]
    assert old_asserts == new_asserts, p
    assertion_counts[p] = len(new_asserts)
    if p.endswith('fixture.py'):
        for name in ('peer_worker', 'run_gates', 'Fixture'):
            previous = next(n for n in old.body if getattr(n, 'name', None) == name)
            present = next(n for n in new.body if getattr(n, 'name', None) == name)
            assert ast.dump(previous) == ast.dump(present), name
    previous = (BASE / 'before' / p).read_text()
    present = (ROOT / p).read_text().replace('"ip", "nsenter", "setpriv"', '"ip", "setpriv"')
    if p.endswith('fixture.py'):
        added = '''        # Enter only the fixture network namespace. `ip netns exec` also replaces
        # /sys, hiding the cgroup mount needed for authoritative memory safety.
        enter = [shutil.which("nsenter"), f"--net=/run/netns/{namespace}", "--"]
        argv = fixture.privileged + enter + drop + environment + command'''
        original = '''        argv = fixture.privileged + ["ip", "netns", "exec", namespace] + drop + environment + command'''
        assert added in present
        present = present.replace(added, original)
    assert present == previous, p

expected = {'round15-inet-ipv4': (13, 'inet'), 'round15-inet-ipv6': (21, 'inet'),
            'round15-socket-ipv4': (13, 'socket'), 'round15-socket-ipv6': (20, 'socket'),
            'round15-five-release': (11, None), 'round15-five-example': (11, None)}
receipts = {}
failed = []
for path in sorted(BASE.glob('*.json')):
    r = load(path)
    if 'label' not in r:
        continue
    assert r['source'] == HEAD, path
    assert r['source_changes'] == [] and r['commands_terminal'] is True, path
    assert r['source_hashes'] in (before, current), path
    log = ROOT / r['log']
    assert digest(log.read_bytes()) == r['log_sha256'], path
    receipts[r['label']] = {k: r[k] for k in ('status', 'exit', 'command', 'started_at', 'elapsed_seconds', 'log', 'log_sha256')}
    receipts[r['label']]['receipt_sha256'] = digest(path.read_bytes())
    if r['exit']:
        failed.append(r['label'])
    if r['label'].startswith('round15-'):
        assert r['source_hashes'] == current and r['status'] == 'PASS' and r['exit'] == 0, path
    if r['label'] in expected:
        count, backend = expected[r['label']]
        lines = log.read_text().splitlines()
        summaries = [json.loads(line) for line in lines if line.startswith('{"result":')]
        assert len(summaries) == 1
        s = summaries[0]
        assert s['result'] == 'PASS' and s['count'] == count
        assert len([line for line in lines if line.startswith('PASS ')]) == count
        if backend:
            assert s['backend'] == backend and len(s['gates']) == count and s['peer_capability_notices'] == []
            assert 'WIRE RUNTIME' not in '\n'.join(lines) or backend in '\n'.join(lines)
        else:
            assert s['transports'] == 5 and s['independent_peers'] == 2
        receipts[r['label']]['summary'] = s
assert set(failed) == {'original-ipv4', 'traced-ipv4', 'safety-traced-ipv4', 'namespace-traced-ipv4'}
assert all(k in receipts for k in expected)
assert all(k in receipts for k in ('round15-prod-compile', 'round15-release-build', 'round15-inventory', 'round15-diff-check'))
assert 'INVENTORY_PASS unit=390, component=323, protocol=187 active_files=121 retained_files=143' in (BASE / 'round15-inventory.log').read_text()
diagnostic = (BASE / 'nsenter-audit-ipv4.log').read_text()
for marker in ('DIAG_PARENT_NETNS net:[4026531833] UID 1000 GID 100',
               'DIAG_CHILD_NETWORK_NAMESPACE: {:ok, "net:[4026533324]"}',
               'DIAG_CHILD_INTERFACES: [~c"lo", ~c"eth0", ~c"eth1"]',
               'DIAG_SAFETY_RESULT: {:ok,', 'cgroup2 cgroup2 rw',
               'Uid:\\t1000\\t1000\\t1000\\t1000', 'Gid:\\t100\\t100\\t100\\t100'):
    assert marker in diagnostic, marker
assert 'reasons: [:cgroup_mount_unavailable]' in (BASE / 'namespace-traced-ipv4.log').read_text()
assert 'DIAG_SAFETY_RESULT: {:error, :safety_sample_unavailable}' in (BASE / 'namespace-traced-ipv4.log').read_text()
handoff = load(BASE / 'handoff.json')
assert handoff['commands_terminal'] and handoff['active_sessions'] == [] and handoff['owned_namespaces_remaining'] == []
assert handoff['received_sol_repairs'] == 2 and handoff['cumulative_astra_repair_attempts'] == 15
assert handoff['production_repair_counter_unchanged'] == 14
assert handoff['task_patch_sha256'] == digest((BASE / 'task.patch').read_bytes())
assert handoff['owned_hashes'] == {p: current[p] for p in OWNED}
subprocess.run(['git', 'diff', '--check'], cwd=ROOT, check=True)
result = {'status': 'PASS', 'verified_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'baseline': HEAD, 'source_inputs': len(current), 'current_source_hashes': current,
          'source_drift_from_accepted_final014': sorted(OWNED), 'unchanged_input_count': len(current)-len(OWNED),
          'unchanged_assertions': assertion_counts, 'all_original_assertions_deadlines_topology_cleanup_preserved': True,
          'receipts': receipts, 'preserved_failed_receipts': failed,
          'original_runtime_gate_total': sum(v[0] for v in expected.values()),
          'handoff_sha256': digest((BASE / 'handoff.json').read_bytes()),
          'reviewer_tests_build_runtime_network_run': False, 'reviewer_commands_terminal': True}
(OUT / 'validation.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('current_source_hashes', 'receipts')}, indent=2))
