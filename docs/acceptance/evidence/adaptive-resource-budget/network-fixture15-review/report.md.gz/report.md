# Recovery15 independent fixture review

Verdict: **FIXTURE_SOURCE_ACCEPTED_READY_FOR_EXACT_SHA_HOSTED_REQUALIFICATION**.
Task `ARB-NETWORK-FIXTURE15-REVIEW` is DONE within its direct, read-only Sol
specification/code/evidence review assignment. No actionable finding remains.
This verdict does not complete hosted qualification or publication.

Repository `/home/gao/Workspace/gsmlg-opt/gaoxy`, branch `main`, baseline and
reviewed HEAD `4f39c9e49f6e7c2147bfaa3a8ca4ae7290506d28`. The four fixture
changes already existed when this reviewer resumed; no source was changed by
the reviewer. Only this audit directory was written.

## Cause and correction

The preserved hosted run `41029385382` and unchanged local `original-ipv4`
reproduction fail at the first required two-second WIRE RX deadline. Diagnostic
traces show the 57-byte packet reaching DatagramBridge while Admission rejects
`:safety_sample_unavailable`. Under `ip netns exec`, `/proc/self/cgroup` still
reports membership, but the child's replacement `/sys` has no cgroup2 mount.
SystemMemory returns `:cgroup_mount_unavailable`. Ordinary execution sees the
real cgroup2 hierarchy and Safety succeeds. This evidence establishes fixture
mount behavior, with no production Safety defect or dependency blocker.

The shared Child launcher now uses `nsenter --net=/run/netns/<owned-name> --`
before the unchanged setpriv UID/GID/init-groups and environment sequence.
Only a network namespace is requested; neither mount nor cgroup namespace is
entered. The existing fixture still creates private bridges/veth endpoints,
stops its children, and removes only its own UUID-prefixed namespaces. Each of
the three entrypoints checks `nsenter`; the README explains the behavior.
Existing Docker tooling installs util-linux. No product fallback, injected
Safety result, dependency change, or weakened assertion was added.

The diagnostic audit log records invoking UID1000/GID100 and child real,
effective, saved and filesystem UID1000/GID100; parent network namespace
`4026531833` differs from child `4026533324`; the child sees only lo/eth0/eth1.
The actual controller files are read successfully and Safety returns `{:ok, …}`.
The ordinary and repaired child expose the same original cgroup2 mount entry.
Mount/cgroup namespace inode equality was not separately measured; retaining
those namespaces is established by the narrowly specified nsenter command and
the observed controller mount, rather than an additional runtime claim.

## Exact source and assertion review

Fresh reviewer authentication verified all 682 frozen final014 input hashes
against HEAD4f39. Exactly four inputs differ in the current source:

- `integration/network/fixture.py`: network-only entry and prerequisite.
- `integration/network/release_gate.py`: prerequisite only.
- `integration/network/example_gate.py`: prerequisite only.
- `integration/network/README.md`: prerequisite and mount explanation.

The remaining 678 inputs are byte-identical, including all application code,
Safety/Admission, app tests, count manifest, dependencies/locks, workflows,
version manifests and package code. Before snapshots match HEAD exactly, the
saved task patch matches the reviewed diff, and every original runtime receipt
uses the current 682-input map with no source changes during execution.

AST comparison preserves all 18 fixture assertions, 11 release assertions and
6 example assertions. Fixture, peer_worker and run_gates bodies are identical.
Exact source normalization of the three executable files proves the complete
delta is the launcher/prerequisite replacement. Consequently deadlines,
positive and negative packet gates, topology and cleanup are unchanged.

## Authenticated execution evidence

The reviewer read original receipts and raw logs, checked SHA256 identities,
source maps, terminal status, exit codes, positive counts and PASS markers.
These are worker-executed checks, not reviewer-rerun runtime tests.

| Original command/suite | Executed gates | Result |
| --- | ---: | --- |
| fixture.py, inet IPv4 | 13 | PASS, exit0 |
| fixture.py --ipv6, inet IPv4/IPv6 | 21 | PASS, exit0 |
| fixture.py, socket IPv4 | 13 | PASS, exit0 |
| fixture.py --ipv6, socket IPv4/IPv6 | 20 | PASS, exit0 |
| release_gate.py, source-built production release | 11 | PASS, exit0 |
| example_gate.py, shipped custom-handler example | 11 | PASS, exit0 |
| Total | 89 | All original gates executed |

The socket IPv6 suite includes its original explicit unsupported scoped-send
negative assertion. It does not certify a supported IPv6 socket send. No peer
capability notices or unavailable outcomes occur in the four fixture summaries.
The original retained scope exclusion for blocked uncertain sends stays intact.
Release and example each execute five transports against two independent peers
and successfully rebind all five server endpoints after shutdown.

Dev compile, strict prod compile, source-built `mix release --overwrite`,
inventory (`390/323/187`, 121 active and 143 retained files), and diff-check
receipts also pass with authenticated logs. All 17 command receipts were
authenticated: 13 PASS and the four intentionally preserved original/diagnostic
FAIL records. The diagnostic audit-only substitution passed 13 gates and is
additional evidence, not a replacement for the six original runs above.

Fresh reviewer command:
`python3 .audit/adaptive-resource-budget/network-fixture15-review/verify_evidence.py`
returned exit0 on the initial review and freshly again at 2026-10-30T09:17:16.110122+00:00. The first audit script attempt stopped at
a Git mnemonic prefix mismatch (`c/` versus saved `i/`); explicit diff prefixes
fixed that reviewer comparator. No source or worker evidence was changed.

## Handoff and limits

The authenticated worker handoff reports all commands terminal, no active
sessions or owned namespaces remaining, and source/build lane released to the
parent. This reviewer started no build, test, peer, listener, privileged or
network process; its own commands are terminal. Runtime cleanup state was
reviewed from the handoff, not re-probed with a runtime command.

Cumulative CORE counters remain Sol2/Astra15 compatibility recovery, with the
production repair counter14 unchanged. Reviewer product-repair attempts0;
one audit comparator correction is recorded separately. No Astra escalation
is requested. The active fixed deadline remains 2026-10-31T02:09:44Z.

Parent-owned pending work: commit the reviewed source, push/read back its exact
SHA, require all five source workflows on that new SHA, then follow existing
guarded release and public artifact/runtime acceptance. The old hosted failure
remains FAIL, earlier local final014 PASS remains valid for unchanged source,
and publication remains NOT RUN in this review. Native macOS/Windows memory
qualification, specialist pressure/slow-peer/load and production deployment
remain outside this assignment. No product decision is needed for this repair.

## Receipt refresh

The parent reran the writing verifier at 09:16:36Z, updating validation.json
without changing source. The reviewer preserved the original receipt bytes as
previous-receipt.json, reran the full evidence authentication at 2026-10-30T09:17:16.110122+00:00
(exit0), and refreshed receipt.json to bind the resulting validation/report
bytes. This administrative refresh changes no source, finding, runtime evidence,
repair counter or acceptance boundary. All reviewer commands remain terminal.
