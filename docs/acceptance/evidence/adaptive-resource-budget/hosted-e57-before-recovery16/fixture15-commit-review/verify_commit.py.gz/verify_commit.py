#!/usr/bin/env python3
"""Authenticate the commit bridge and preserved artifacts without running tests."""
from pathlib import Path
import datetime
import gzip
import hashlib
import json
import re
import subprocess

ROOT = Path('/home/gao/Workspace/gsmlg-opt/gaoxy')
OUT = Path(__file__).resolve().parent
NEW = 'e57fb086f5aa2093767832699907f3430f8334a6'
OLD = '4f39c9e49f6e7c2147bfaa3a8ca4ae7290506d28'
ARCHIVES = ROOT / 'docs/acceptance/evidence/adaptive-resource-budget'
def sha(data): return hashlib.sha256(data).hexdigest()
def load(path): return json.loads(path.read_text())
def git(*args): return subprocess.check_output(['git', *args], cwd=ROOT)
assert git('rev-parse', 'HEAD').decode().strip() == NEW
assert git('rev-parse', 'HEAD^').decode().strip() == OLD
assert git('branch', '--show-current').decode().strip() == 'main'
assert not git('status', '--porcelain').strip()

bridge_path = ROOT / '.audit/adaptive-resource-budget/publication-source-bridge-fixture15.json'
bridge = load(bridge_path)
review_path = ROOT / '.audit/adaptive-resource-budget/network-fixture15-review/receipt.json'
review = load(review_path)
validation = load(ROOT / review['validation']['path'])
frozen = load(ROOT / '.audit/adaptive-resource-budget/final-integrated14-review/validation.json')['source_hashes']
current = bridge['source_hashes']
assert bridge['status'] == 'PASS_SOURCE_BRIDGE' and bridge['publication_sha'] == NEW
assert bridge['prior_candidate_sha'] == OLD and bridge['branch'] == 'main'
assert bridge['worktree_clean'] and bridge['commit_and_worktree_exact']
assert len(current) == len(frozen) == bridge['source_inputs'] == 682
changed = sorted(p for p in frozen if current[p] != frozen[p])
assert changed == bridge['changed_inputs'] == review['changed_inputs']
assert bridge['unchanged_input_count'] == 678
assert current == validation['current_source_hashes']
assert bridge['fixture_review_receipt_sha256'] == sha(review_path.read_bytes())
for field in ('validation', 'report', 'previous_receipt'):
    assert sha((ROOT / review[field]['path']).read_bytes()) == review[field]['sha256']
for path, digest in current.items():
    assert sha(git('show', f'{NEW}:{path}')) == digest, path
    assert sha((ROOT / path).read_bytes()) == digest, path
    assert sha(git('show', f'{OLD}:{path}')) == frozen[path], path
delta = git('diff', '--src-prefix=i/', '--dst-prefix=w/', OLD, NEW, '--', *changed)
assert delta == (ROOT / '.audit/adaptive-resource-budget/core/time-quota/hosted-network15/task.patch').read_bytes()

archives = []
for name, count in (('network-fixture15', 59), ('network-fixture15-review', 5)):
    manifest_path = ARCHIVES / name / 'archive-manifest.json'
    manifest = load(manifest_path)
    assert manifest['baseline'] == OLD
    assert manifest['status'] == 'FIXTURE15_ACCEPTED_HOSTED_AND_PUBLICATION_PENDING'
    assert len(manifest['archive_entries']) == count
    assert git('show', f'{NEW}:{manifest_path.relative_to(ROOT)}') == manifest_path.read_bytes()
    for entry in manifest['archive_entries']:
        path = ROOT / entry['archive']
        raw = path.read_bytes()
        assert sha(raw) == entry['archive_sha256'], path
        assert raw == git('show', f'{NEW}:{entry["archive"]}'), path
        original = gzip.decompress(raw)
        assert len(original) == entry['bytes'] and sha(original) == entry['sha256'], path
        assert original == (ROOT / entry['original']).read_bytes(), path
        archives.append(entry)
assert len(archives) == 64
assert len({e['archive'] for e in archives}) == 64
changed_paths = git('diff', '--name-only', OLD, NEW).decode().splitlines()
expected = set(changed + ['docs/acceptance/adaptive-resource-budget.md', 'docs/plans/adaptive-resource-budget.md'] +
               [e['archive'] for e in archives] +
               [f'docs/acceptance/evidence/adaptive-resource-budget/{name}/archive-manifest.json' for name in ('network-fixture15', 'network-fixture15-review')])
assert set(changed_paths) == expected and len(changed_paths) == 72

qual = ROOT / '.audit/adaptive-resource-budget/qualification'
receipts = []
for path in sorted(qual.glob('final014-*.json')):
    r = load(path)
    assert r['status'] == 'PASS' and r['exit'] == 0 and r['commands_terminal'] is True
    assert r['source_changes'] == [] and r['source_hashes'] == frozen
    assert sha((ROOT / r['log']).read_bytes()) == r['log_sha256']
    receipts.append({'label': r['label'], 'receipt_sha256': sha(path.read_bytes()), 'log_sha256': r['log_sha256']})
assert len(receipts) == 35
all_receipt = load(ROOT / bridge['qualification_receipt'])
canonical_log = (ROOT / all_receipt['log']).read_text()
assert 'REPAIR_PASS 900 executed, 0 failures, 0 excluded, 0 skipped' in canonical_log
summaries = re.findall(r'(?m)^\s*(\d+) tests?, (\d+) failures?[^\n]*$', canonical_log)
assert len(summaries) == 121 and sum(int(n) for n, _ in summaries) == 900
assert all(int(f) == 0 for _, f in summaries)
old_review = load(ROOT / '.audit/adaptive-resource-budget/final-integrated14-review/receipt.json')
assert old_review['actual_pass_receipts'] == 35 and old_review['canonical']['tests'] == 900
assert old_review['source_acceptance_complete'] is True and old_review['whole_goal_delivered'] is False

hosted_path = ARCHIVES / 'network-fixture15/delivery/41029385382.json.gz'
hosted = json.loads(gzip.decompress(hosted_path.read_bytes()))
assert hosted['headSha'] == OLD and hosted['conclusion'] == 'failure'
jobs = {j['name']: j for j in hosted['jobs']}
assert jobs['component']['conclusion'] == jobs['protocol']['conclusion'] == 'success'
assert jobs['isolated-network']['conclusion'] == 'failure'
assert jobs['release-clients']['conclusion'] == 'skipped'
failed_steps = [s['name'] for s in jobs['isolated-network']['steps'] if s['conclusion'] == 'failure']
assert failed_steps == ['Isolated IPv4 ingress, memberships, restart and egress']
status_docs = {}
for name in ('docs/acceptance/adaptive-resource-budget.md', 'docs/plans/adaptive-resource-budget.md'):
    text = (ROOT / name).read_text()
    assert git('show', f'{NEW}:{name}') == text.encode()
    assert '89' in text and '900' in text and 'pending' in text.lower()
    status_docs[name] = sha(text.encode())
acceptance = (ROOT / 'docs/acceptance/adaptive-resource-budget.md').read_text()
for text in ('41029385382', 'failure is preserved as FAIL', '89 passing gates', 'all five hosted workflows on that exact SHA', 'publication and public-artifact/'):
    assert text in acceptance, text
result = {'status': 'PASS', 'verified_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'commit': NEW, 'parent': OLD, 'branch': 'main', 'worktree_clean': True,
          'source_bridge_sha256': sha(bridge_path.read_bytes()), 'source_inputs': 682,
          'unchanged_inputs': 678, 'changed_inputs': changed, 'commit_paths': 72,
          'archives': {'entries': len(archives), 'fixture': 59, 'review': 5,
                       'committed_gzip_original_bytes_hashes_all_match': True},
          'prior_final014': {'receipts': 35, 'canonical_tests': 900, 'positive_summaries': 121,
                            'failures': 0, 'excluded': 0, 'skipped': 0, 'receipts_authenticated': receipts},
          'original_network_runtime_gates': 89, 'fixture_review_receipt_sha256': sha(review_path.read_bytes()),
          'old_hosted_failure_retained': {'run': hosted['databaseId'], 'sha': OLD, 'conclusion': 'failure', 'failed_steps': failed_steps},
          'status_document_hashes': status_docs, 'new_hosted_ci': 'PENDING_NOT_QUERIED_BY_REVIEWER',
          'publication': 'PENDING_NOT_QUERIED_BY_REVIEWER', 'tests_build_runtime_network_run': False,
          'reviewer_commands_terminal': True}
(OUT / 'validation.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('prior_final014',)}, indent=2))
