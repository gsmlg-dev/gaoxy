"""Read-only source/evidence checks; writes only this review directory."""
from pathlib import Path
import datetime
import gzip
import hashlib
import json
import re

ROOT = Path('/home/gao/Workspace/gsmlg-opt/gaoxy')
OWN = ROOT / '.audit/adaptive-resource-budget/final-integrated14-review'
BASE = ROOT / '.audit/adaptive-resource-budget/qualification'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


prior = json.loads((ROOT / '.audit/adaptive-resource-budget/extended-final-review/receipt.json').read_text())
frozen = prior['frozen_source_hashes']
expected = {p.name.replace('ext24h014-', '') for p in BASE.glob('ext24h014-*.json')}
actual = {p.name.replace('final014-', '') for p in BASE.glob('final014-*.json')}
assert len(expected) == 35 and actual == expected, (expected - actual, actual - expected)
assert len(frozen) == 682
current_drift = [p for p, h in frozen.items() if not (ROOT / p).is_file() or digest(ROOT / p) != h]
assert not current_drift, current_drift
receipts = []
for path in sorted(BASE.glob('final014-*.json')):
    d = json.loads(path.read_text())
    assert d['status'] == 'PASS' and d['exit'] == 0, path
    assert d['commands_terminal'] is True and d['source_changes'] == [], path
    assert d['source_hashes'] == frozen, path
    log = ROOT / d['log']
    assert digest(log) == d['log_sha256'], path
    receipts.append({
        'path': str(path.relative_to(ROOT)), 'sha256': digest(path),
        'command': d['command'], 'cwd': d['cwd'], 'environment': d['environment'],
        'started_at': d['started_at'], 'elapsed_seconds': d['elapsed_seconds'],
        'status': d['status'], 'exit': d['exit'], 'commands_terminal': True,
        'source_changes': [], 'log': d['log'], 'log_sha256': d['log_sha256'],
        'evidence_lines': d['evidence_lines'],
    })

canonical = json.loads((BASE / 'final014-all.json').read_text())
text = (ROOT / canonical['log']).read_text()
reports = [tuple(int(x or 0) for x in match) for match in re.findall(
    r'(?m)^(\d+) tests?, (\d+) failures?(?:, (\d+) excluded)?(?:, (\d+) skipped)?$', text)]
commands = re.findall(r'(?m)^REPAIR_COMMAND ', text)
totals = [sum(x[i] for x in reports) for i in range(4)]
assert len(reports) == len(commands) == 121 and all(x[0] > 0 for x in reports)
assert totals == [900, 0, 0, 0], totals
assert 'REPAIR_PASS 900 executed, 0 failures, 0 excluded, 0 skipped' in text
inventory = (BASE / 'final014-inventory.log').read_text()
assert 'unit=390, component=323, protocol=187 active_files=121 retained_files=143' in inventory
assert '4 tests, 0 failures' in (BASE / 'final014-optional-quic-tests.log').read_text()

archive = ROOT / 'docs/acceptance/evidence/adaptive-resource-budget/final014/archive-manifest.json'
manifest = json.loads(archive.read_text())
assert len(manifest['archive_entries']) == 81
for entry in manifest['archive_entries']:
    packed = ROOT / entry['archive']
    unpacked = gzip.decompress(packed.read_bytes())
    assert digest(packed) == entry['archive_sha256'], packed
    assert hashlib.sha256(unpacked).hexdigest() == entry['sha256'], packed
    assert len(unpacked) == entry['bytes'], packed
    original = ROOT / entry['original']
    if original.exists():
        assert original.read_bytes() == unpacked, original

docs = [
    'AGENTS.md', 'README.md', 'docs/resource-budget.md', 'docs/releases/0.14.0.md',
    'docs/designs/adaptive-resource-budget.md', 'docs/plans/adaptive-resource-budget.md',
    'docs/acceptance/adaptive-resource-budget.md', 'docs/phoenix.md',
    'docs/http-proxy.md', 'docs/websocket-proxy.md',
]
result = {
    'verified_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'PASS_SOURCE_EVIDENCE', 'required_receipts': 35,
    'pass_receipts': len(receipts), 'fail_receipts': 0,
    'source_input_count': len(frozen), 'source_hashes': frozen,
    'current_source_drift': current_drift,
    'source_map_sha256': hashlib.sha256(json.dumps(frozen, sort_keys=True).encode()).hexdigest(),
    'canonical': {'commands': len(commands), 'positive_summaries': len(reports),
                  'tests': totals[0], 'failures': totals[1], 'excluded': totals[2], 'skipped': totals[3]},
    'receipts': receipts, 'archive_manifest': str(archive.relative_to(ROOT)),
    'archive_manifest_sha256': digest(archive), 'verified_archive_entries': 81,
    'document_snapshot_hashes': {p: digest(ROOT / p) for p in docs},
    'commands_terminal': True,
}
(OWN / 'validation.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ['status', 'required_receipts', 'pass_receipts',
      'fail_receipts', 'source_input_count', 'current_source_drift', 'canonical',
      'verified_archive_entries', 'commands_terminal']}, indent=2))
