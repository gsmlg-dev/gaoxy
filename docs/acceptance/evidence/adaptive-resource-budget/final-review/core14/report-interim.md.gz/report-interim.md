# ARB-FINAL-ACCEPTANCE: CORE13 interim independent review

Verdict: **NARROW RECEIVE-WINDOW CHANGE REVIEWED; OVERALL ACCEPTANCE OPEN**.
The original optional consumer still fails 4/1, now at its later listener-close
assertion. This report does not accept CORE13 as a complete compatibility repair
or authorize publication. The next lifecycle repair requires its own frozen
delta, passing unchanged consumer, independent review and fresh integrated gates.

Direct Sol read-only assignment. Repository `/home/gao/Workspace/gsmlg-opt/gaoxy`,
existing `main`, HEAD `bc8a5ef5199293ada3b432c2e2741070d3b2d115` plus preserved
task integration. Original objective baseline
`a6a35438c0a153cd53c87c6a55c19a70a11fb75a`. Coordinator owns docs/Git; Astra
owns recovery and shared build lane. Reviewer owns only this new audit directory.
No source/test/public-doc/manifest/Git/dependency mutation, test/build execution,
network peer, listener or runtime was performed by the reviewer. All reviewer
commands completed. Reviewer repair counters: Sol0/Astra0. Received CORE counters
remain Sol2/Astra13; the later lifecycle repair is not reset to another task.
Extended deadline: 2026-10-31T02:09:44Z. No new permissions or design decisions.

## Inspected delta and correctness

Compared the CORE13 candidate directly with `core/time-quota/optional-quic13/before/`.
The only three changes among its 682 fingerprinted inputs are:

- `apps/gaoxy/lib/gaoxy/service.ex`: raw QUIC advertises connection and stream
  receive credit `min(native_capacity, max_packet, 16384)`. The exact H3 handler
  retains its previous full native-capacity receive profile.
- `apps/gaoxy/test/quic_context_test.exs`: two additive profile tests and the
  controlled handler's `handle_event/2`; existing three cases remain intact.
- `scripts/check-repairs.py`: that component file's expected count grows 3 to 5.

The source change matches the existing public facade read quantum in
`Gaoxy.QUIC.read/3`. The pinned dependency's `Quic.Streams.replenish_credit/3`
increases connection and per-stream credit by consumed bytes, so this limits
outstanding peer delivery rather than the total transferable byte count.
`max_buffer`, `max_ready_bytes`, writer byte/queue ceilings, stream quotas,
stream-record/range guards, operation-result cache policy, application-state
accounting, cleanup ownership and callback/drain deadlines are unchanged.
`QUICBridge` and `QUICCleanup` exactly match the before copies. No cap increase,
cache bypass, weakened stream safety or lost terminal proof was introduced.

The new tests check explicit cap262144/packet4096, omitted native16MiB with
window16384, small explicit cap1024, and explicit/default H3 profiles. They also
check unchanged buffer/writer capacities, explicit/omitted provenance, unchanged
operation-limit defaults, and H3 infinite idle profile. These real-host setup
tests remain correctly component-classified, outside the no-socket unit suite.

Public-documentation observation was resolved by the coordinator:
`docs/resource-budget.md:75` now describes the raw derived receive window,
replenishment and independent native/writer/cache/H3 limits without implying an
increase of the service hard cap. Current acceptance opening accurately separates
the successful large exchange from the failed later shutdown gate.

## Evidence verified, without reviewer reruns

All paths below are relative to `.audit/adaptive-resource-budget/`.
`receipt-interim.json` records hashes. Existing command counts are evidence
observed by this reviewer, not commands rerun by the reviewer.

| Receipt / scope | Actual result | Disposition |
| --- | --- | --- |
| `qualification/ext24h014-*` (35 receipts) | 34PASS/1FAIL; all terminal, raw-log hashes match; stable682 inputs at execution | Repair12 checkpoint only; three current source inputs now differ. |
| `qualification/ext24h014-all` | 898/0, zero exclusions/skips,121 active files;390unit/321component/187protocol | Preserved prior integrated PASS, not exact CORE13 qualification. |
| Other ext24h014 gates | Staging12, built consumers7 and isolation, five source-consumer commands, Python36, Phoenix27/client10/unified8, H2RFC40, reverse proxy6, original release core3/Gateway7/H3-3 and Linux portable1 PASS | All remain their actual repair12 source checkpoint. |
| `optional-quic13/profile-red-valid` | 5tests/1failure, exit2, terminal; raw profile assertion fails before change | Relevant RED; earlier separate invalid fixture RED remains preserved. |
| `optional-quic13/profile-green` | 5tests/0failures, exit0, terminal, stable source | Scoped advertised-profile GREEN. |
| `optional-quic13/consumer-green` | 4tests/1failure, exit2, terminal, stable source | Mandatory gate still FAIL. |

The before-change diagnostic reports native ready232566 + cached results26860
=259426 bytes; callback3054 + guardian1012 brings projected ownership263492
above the unchanged262144 cap. This supports the advertised-window repair's
cause without blaming the dependency for valid hard-cap enforcement.

The current unchanged consumer progresses through stream flow-control/FIN
344064bytes, independent-connection isolation86016bytes, directional controls,
peer-reset/stop sibling survival and negative handshake checks. It observes
retained highwater101507 <=262144 and removal9ms <=2000. The later listener peer
then times out at the original `peer.py:118` ten-second `wait_closed()` deadline.
The original4/0 requirement remains unmet. Earlier native `invalid_operation` /
`not_established` log lines alone do not establish the shutdown root cause.
All six fingerprinted optional-consumer files, including peer and assertions,
remain byte-identical to the ext24h014 source. Neither cap nor deadlines changed.

Archive checks: all79 gzip entries in the new extended-window archive match
compressed SHA, decompressed SHA/length and original bytes. All535 newly added
staged evidence files match their worktree bytes. The evidence-only
`.gitattributes` rule `* -text` preserves raw CRLF bytes. Historical archive
whitespace failures remain historical; no archive rewrite is requested.

## Twelve Definition-of-Done dispositions

RETAINED means supported by prior reviewed implementation and its actual
repair12 evidence. Every row remains subject to exact final-source qualification.

| Row | Required outcome | Current disposition |
| --- | --- | --- |
| D1 | Reliable effective capacity, soft50% | RETAINED deterministic/Linux evidence; real macOS/Windows NOT RUN. |
| D2 | Unknown-capacity256MiB fallback | RETAINED exact268435456/536870912 assertions. |
| D3 | Shared VM pool without instance/listener multiplication | RETAINED OWNER races and actual mixed ListenerSet/Phoenix evidence. |
| D4 | Exactly100% normal | RETAINED exact boundary/committed-state cases. |
| D5 | Above100% through200% admits with warning rate limit | RETAINED projected admission/shared warning evidence. |
| D6 | Above200% atomic new-work refusal | RETAINED OWNER and H1/H2/H3 scoped wire refusals. |
| D7 | Strict protocol/OOM safety | RETAINED ordinary controlled/network evidence; CORE13 weakens no guard; no physical pressure proof claimed. |
| D8 | Dynamic connection/request memory | RETAINED H1/H2/H3 integration; CORE13's original large QUIC exchange now scoped PASS. |
| D9 | Release only after real completion | OPEN current full optional listener-close assertion; do not infer remote closure from9ms local removal. Prior HTTP churn/terminal-pair evidence remains valid at its source checkpoint. |
| D10 | Phoenix H1/H2/H3 concurrency | RETAINED actual27/client10/unified8 checkpoint; fresh final-source repeat pending. |
| D11 | Explicit compatibility / documented migration | OPEN original optional consumer4/1; raw receive-window migration paragraph reviewed as accurate. |
| D12 | Truthful telemetry/tests/docs/release metadata | PARTIAL: metadata0.14.0 aligns and current failure reporting is accurate; final source, docs/Git, guarded publication and public read-back remain parent-owned OPEN. |

## Twenty verification dispositions

| Row | Requirement | Current disposition |
| --- | --- | --- |
| V1 | Supported-platform detection | RETAINED deterministic/Linux; native macOS/Windows NOT RUN. |
| V2 | Fallback | RETAINED exact policy/detection evidence. |
| V3 |50% calculation | RETAINED policy and actual Phoenix snapshots. |
| V4 |100% boundary | RETAINED exact100/+1 tests. |
| V5 | Admission100..200% | RETAINED projected concurrent OWNER evidence. |
| V6 | Refusal above200% | RETAINED exact200+1 and protocol-local refusals. |
| V7 | Release/recovery | RETAINED HTTP/OWNER release/shrink/re-admission; raw optional full lifecycle OPEN. |
| V8 | Independent H1 connections | RETAINED held-workers/keepalive/publiczero cases. |
| V9 | Independent H2 connections | RETAINED default concurrency and actual TLS-H2 Phoenix cases. |
| V10 | Concurrent H2 streams | RETAINED overlapping body/sibling/HPACK cases. |
| V11 | H3 concurrency | RETAINED canonical H3/actual mixed Phoenix; exact branch unchanged. |
| V12 | Phoenix LiveView/WebSocket | RETAINED actual component/client/unified and native stream evidence. |
| V13 | SSE/streaming | RETAINED canonical/Phoenix; CORE13 adds scoped large raw QUIC exchange success, not full lifecycle success. |
| V14 | Concurrent request bodies | RETAINED actual H1/H2 overlap and exact echoes. |
| V15 | Connection churn/cleanup | RETAINED nine ordinary H1/H2/H3 rounds with unchanged server and publiczero before reopening. |
| V16 | Cgroup limits | RETAINED injected hierarchy/malformed/permission/overflow plus actual Linux metadata; no live matrix mutation claimed. |
| V17 | Multiple instances/ListenerSets | RETAINED shared OWNER/native/Phoenix evidence. |
| V18 | Explicit/backward compatibility | FAIL current unchanged optional consumer4/1; cap/provenance/profile5/0 alone is insufficient. |
| V19 | Crash/cancel/drain | OPEN current optional peer-closure deadline failure; prior HTTP/native terminal proofs remain scoped evidence. |
| V20 | Telemetry/warning/reasons | RETAINED exact numeric/reason/rate-limit cases. |

## Remaining contract

1. Astra retains exclusive lifecycle diagnosis/source/build ownership. Review
   the next frozen minimal delta and root cause. Preserve original4/1 and later4/1.
2. Require unchanged full optional4/0, stable hashes, current inventory900
   (390unit/323component/187protocol), scoped compatibility, formatting and strict
   compile evidence. 900 is current manifest arithmetic, not an executed PASS.
3. Parent runs fresh required final combined/source-package/Phoenix/client/
   standalone checks, verifies source identity and updates current overview.
4. Parent owns commit/push/exact-source guarded coordinated release and fresh
   public Hex/tag/assets/checksum/source/downloaded-runtime verification. None of
   those delivery gates has been executed or accepted by this review.

No production deployment/data/certificates, Vault/public-management, browser,
specialist pressure/slow-peer/load expansion, worktree or branch action is added.
No upstream issue or workaround is proposed without a confirmed dependency cause.

Snapshot boundary: this interim report binds the failed CORE13 consumer's source
hashes. By receipt capture, the next Astra14 `QUICBridge` delta was already under
active exclusive ownership; it is recorded separately as newer source drift.
Its later passing receipts and independent review belong to the next report and
do not rewrite this CORE13 failure disposition.
