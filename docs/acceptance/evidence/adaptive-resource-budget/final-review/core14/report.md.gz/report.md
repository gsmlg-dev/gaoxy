# ARB-FINAL-ACCEPTANCE: frozen CORE14 scoped review

**DONE for the assigned independent implementation/specification/code review.
READY FOR FRESH COMBINED QUALIFICATION.** No unresolved actionable finding was
established in the frozen CORE13/14 delta. The original optional consumer now
passes4/0. Whole-goal acceptance and delivery remain OPEN until the coordinator
finishes the final014 source gates and guarded publication/public read-back.
This is not a claim that canonical900 or publication passed.

Direct Sol read-only assignment. Repository `/home/gao/Workspace/gsmlg-opt/gaoxy`,
existing `main`, HEAD `bc8a5ef5199293ada3b432c2e2741070d3b2d115` plus preserved
integration; original objective baseline
`a6a35438c0a153cd53c87c6a55c19a70a11fb75a`. Reviewer writes only this new audit
directory. No source/tests/docs/manifests/Git/dependencies/build/runtime/network
were changed or executed by the reviewer. Existing test command evidence was
read and authenticated, not rerun. All reviewer commands are terminal.
Reviewer counters Sol0/Astra0; received CORE counters Sol2/Astra14. Historical
counts/failures remain unchanged under the extended deadline
2026-10-31T02:09:44Z. No new permission or product design decision is needed.

## Frozen delta and resolved causes

Worker handoff `core/time-quota/optional-quic13/handoff.json`, completed
2026-10-30T08:19:30.936995Z, releases source/shared-build ownership to parent,
records no active sessions, and binds682 inputs. Its patch and all four owned
file hashes match. All other inputs match the before snapshot:

| File | Narrow change |
| --- | --- |
| `apps/gaoxy/lib/gaoxy/service.ex` | Raw QUIC advertised connection/per-stream receive credit becomes `min(native_capacity,max_packet,16384)`; exact H3 profile unchanged. |
| `apps/gaoxy/lib/gaoxy/quic_bridge.ex` | On exactly `:draining`, request bounded supported public `QUIC.close(connection)` before callback death and before an optional app termination callback. |
| `apps/gaoxy/test/quic_context_test.exs` | Add raw explicit/default/small-cap and H3 explicit/default profile controls; existing3 tests/assertions remain. |
| `scripts/check-repairs.py` | Component expected count3 to5; no other recovery-specific manifest change. |

Original aggregate-cap failure: native ready232566 + durable operation results
26860 + callback3054 + guardian1012 =263492, above explicit262144. Flow-control
credit previously consumed nearly the whole aggregate cap before those valid
owners were included. New raw credit matches the existing facade read quantum;
the pinned engine replenishes connection and stream credit on consumption.
Large transfers can exceed the receive window. Native buffer/writer ceilings,
operation cache256, stream-record/range guards and actual byte accounting remain
unchanged. The fix does not increase the service cap or hide retained results.

Later shutdown failure: Service first commits the Admission drain barrier, then
starts async native-host stop. A queued bridge poll can observe `:draining` and
terminate before the host processes `:service_draining`. Consumer DOWN then
stops the engine without the host's normal close0 request. The added public
close executes while the attached consumer still exists, including handlers
without an optional termination callback. Unchanged peer evidence now observes
close_code0, sibling survival, removal, same-port rebind and a second large echo.

## Deadline and ownership trace

The close call runs inside the existing Abyss.Worker termination watch, in the
isolated callback process. Public facade options bound its timeout to
`min(1000,callback_timeout)`. It does not call Service, rewrite drain state or
reset a Service/guardian timer. Service retains its original absolute
`drain.deadline` and independent `:drain_deadline` timer; `force_drain` kills owned
backend/worker descendants at that boundary. Repeated drain joins retain the
same deadline. Existing optional app cleanup uses its pre-existing local
callback deadline, still enclosed by host watch and Service force; the new close
does not create a new callback/watch or remove those outer bounds.

Guardian cancellation still takes `min(existing,incoming)` deadline. Public
close admission, callback death and the peer's observation do not refund bytes.
Only exact original-handle closed evidence plus authenticated cleanup receipt,
guardian termination and existing terminal reconciliation permit release.
`QUICCleanup`, Admission and Ledger are unchanged by this recovery. No timeout,
guard, proof, cap, cache or test assertion is weakened. A close error/unknown
outcome remains subject to existing terminal-proof cleanup and forced deadline.

## Observed verification

All paths here are relative to `.audit/adaptive-resource-budget/`. Receipt and
raw-log hashes, current682 inputs, `source_changes=[]` and terminal state were
independently verified for every row below. `receipt.json` records them.

| Worker receipt under `core/time-quota/optional-quic13/` | Actual result |
| --- | --- |
| `round14-consumer` | Unchanged original optional suite4/0, exit0. |
| `round14-metrics` | Same original4/0 through separate trace; exit0. Supplemental, not counted twice. |
| `round14-core-h3` | CORE123/0 and H3 network13/0; exit0. Includes all5 profile/native-context cases. |
| `round14-test-compile`, `round14-prod-compile` | Strict compilation exits0. |
| `round14-format` | All three owned Elixir files formatted; exit0. |
| `round14-inventory` | unit390/component323/protocol187;121 active/143 retained files; exit0. Total900 is manifest arithmetic. |
| `round14-diff-check` | Current unstaged diff whitespace exit0; does not relabel historical staged archive whitespace. |

Original consumer: large echo344064bytes, verified TLS/ALPN, five stream
directions/FIN, connection isolation86016bytes, reset/stop, surviving sibling,
negative handshakes, retained highwater101507<=262144, remove9ms<=2000, wire
close_code0, surviving-listener77824bytes, same-port rebind/new generation and
second344064byte echo. Traced repeat removal11ms. All six original consumer
inputs, payloads, caps, assertions and finite deadlines are byte-identical to
ext24h014. Original ext24h0144/1 and CORE13 later4/1 remain immutable failures.

Public guide finding is resolved: `docs/resource-budget.md:75` accurately states
derived raw receive credit/replenishment, separate buffer/writer/cache/H3
controls and unchanged explicit aggregate cap. Parent owns current acceptance,
plan and final evidence refresh. Prior archive verification remains79 matching
gzip entries and535 staged additions matching worktree bytes; `* -text` is
restricted to the adaptive evidence directory to preserve raw bytes.

## Twelve DoD and twenty verification dispositions

The following is implementation/scoped disposition. Prior ext24h014898/0,
package/Phoenix/client/standalone results remain their actual repair12 checkpoint;
all exact final-source combined qualification remains parent-owned and pending.

| DoD | Scoped disposition |
| --- | --- |
| D1 capacity50% | Retained deterministic/Linux evidence; real native macOS/Windows NOT RUN. |
| D2 fallback256MiB | Retained exact fallback assertions. |
| D3 VM sharing | Retained OWNER, ListenerSet and actual Phoenix evidence. |
| D4 exactly100% normal | Retained exact policy/committed boundary evidence. |
| D5 warning100..200% | Retained admission and shared warning-rate evidence. |
| D6 refuse above200% | Retained atomic OWNER and H1/H2/H3 local refusals. |
| D7 strict protocol/OOM safety | Retained ordinary evidence; recovery weakens no guard. No physical pressure claim. |
| D8 dynamic accounting | Retained HTTP evidence plus repaired raw QUIC large-stream cap accounting. |
| D9 terminal ownership | Current optional wire-close/removal/rebind4/0 resolves interim gate; unchanged guardian proof semantics retained. |
| D10 Phoenix concurrency | Retained actual checkpoint; final014 repeat pending. |
| D11 explicit compatibility/migration | Original optional4/0 and accurate raw-profile guide resolve interim finding; exact-source package checks pending. |
| D12 truthful monitoring/docs/release | Code/docs scoped accepted; final integrated status, commit/push/publication/read-back OPEN. |

| Verification | Scoped disposition |
| --- | --- |
| V1 platform detection | Deterministic/Linux retained; native macOS/Windows NOT RUN. |
| V2 fallback | Exact numeric/error cases retained. |
| V3 half calculation | Pure and runtime snapshot evidence retained. |
| V4 soft boundary | Exact100/+1 cases retained. |
| V5 warning admission | Atomic shared projected evidence retained. |
| V6 hard refusal | Exact200+1 and stream-local refusals retained. |
| V7 release/recovery | HTTP/OWNER retained; current optional removal/rebind now4/0. |
| V8 independent H1 | Held-worker/keepalive/publiczero retained. |
| V9 independent H2 | Default and actual TLS-H2 Phoenix retained. |
| V10 H2 streams | Concurrent bodies/siblings/HPACK retained. |
| V11 H3 concurrency | Branch unchanged; scoped H3 network13/0 current; canonical/Phoenix repeat pending. |
| V12 LiveView/WebSocket | Prior actual/component/client evidence retained; final014 repeat pending. |
| V13 SSE/streaming | Prior HTTP/Phoenix retained; unchanged large raw stream now succeeds twice across rebind. |
| V14 concurrent bodies | Prior actual H1/H2 overlap retained. |
| V15 churn/cleanup | Prior nine same-server H1/H2/H3 rounds retained; optional lifecycle adds peer/sibling/rebind4/0. |
| V16 cgroups | Injected hierarchy/safety and actual Linux retained; no live limit matrix mutation claim. |
| V17 instances/ListenerSets | Shared OWNER/native/actual Phoenix retained. |
| V18 compatibility | Current original optional4/0 resolves failure; final source packages/isolation pending. |
| V19 crash/cancel/drain | Current optional wire close/removal bound accepted; original guardian and absolute deadline proofs remain. |
| V20 observability | Existing exact counters/reasons/warning-rate evidence retained. |

## Parent-owned remaining gates

Fresh final014 canonical900/static/package/consumer/Phoenix/client/protocol/
standalone/Linux portable qualification, current overview/archive refresh,
task-owned commit on main, push/remote-SHA confirmation, existing expected-SHA
guarded coordinated release, and public six-Hex/tag/assets/checksum/source/
downloaded-runtime read-back. Source-built checks are separate from public
artifact acceptance; Linux portable smoke is separate from native memory
qualification. No delivery gate is inferred from this scoped review.

No additional code repair, upstream workaround, design decision or permission
is requested. Production deployment/data/certificates, public management, Vault,
browser, pressure/slow-peer/load expansion and branch/worktree actions remain
excluded. Interim report/receipt are preserved beside this final scoped review.
