# Standalone recovery16 frozen specification review

Task `ARB-STANDALONE-RECOVERY16-SPEC-REVIEW`: DONE, direct independent Sol
read-only specification investigation. Source is frozen commit
`e57fb086f5aa2093767832699907f3430f8334a6`; no live worker-owned source was read
or changed. This report identifies a source-permitted timer ordering; it does
not establish a production defect or dismiss one without runtime evidence.

## Original contract

`apps/gaoxy_server/test/standalone_recovery_test.exs:118–178` executes the same
`reject_expired_candidate/3` contract for fixed and grouped upstream routes:

1. Save the coordinator/runtime PIDs, transport/group owner PIDs, generation,
   accepted declaration and baseline. The earlier stale-generation assertion
   has already ensured an obsolete candidate cannot replace accepted routes.
2. Append a gated ExpiredCandidate endpoint to an otherwise resolvable router.
   The original deadline is 1000ms. Initialization sends `activation_compiling`
   from the actual Generation preparation worker, then blocks for at most2000ms.
3. After receiving that acknowledgment (1000ms), assert that the worker differs
   from the coordinator and monitor it. Suspend the actual transport owner so
   release of acquired preparation pins cannot be confirmed.
4. Require the activation caller to return exactly
   `{:error, {:deadline_exceeded, :cleanup_pending}}` within2000ms, exit normally
   within1000ms, and establish original deadline exhaustion. Require the actual
   initialization worker to exit `:killed` within1000ms. Sending its old finish
   message cannot revive or commit a late candidate.
5. The same coordinator must answer a1000ms system-state barrier after expiry.
   Runtime/coordinator and transport/group owner PIDs remain unchanged; baseline
   and accepted generation/declaration remain identical; `pending_pins != []`.
6. Resume the transport owner, request reconciliation, and require pending pins
   empty at the original1000ms state barrier. Existing HTTP behavior remains
   accepted. The rest of each test then proves owner-subtree recovery and a
   subsequent successful reload to final routes without failed resource leaks.

The return tuple is an outer-call deadline outcome with cleanup unconfirmed. It
does not itself prove coordinator cleanup has completed; the later barriers and
pin assertions are essential. Merely accepting either error tuple would weaken
the original tested branch and is not an acceptable repair under this scope.

## Actual preparation and cleanup path

`apps/gaoxy_server/lib/gaoxy/server/route_resources.ex:1–5` is only a wrapper.
It delegates to `Gaoxy.Proxy.Gateway.Coordinator.activate/5`.

- `apps/gaoxy/lib/gaoxy/lifecycle.ex:7–21`: absolute monotonic millisecond D;
  `GenServer.call` waits `remaining(D)`. Only a call timeout exit is translated
  to `{:error, {:deadline_exceeded, :cleanup_pending}}`; a normal reply is passed
  through without a post-receipt deadline check.
- `apps/gaoxy_proxy/lib/gaoxy/proxy/gateway/coordinator.ex:266–305`: reject new
  work if old pins remain; resolve upstream targets and acquire preparation pins;
  verify expected accepted generation; admit the candidate; call
  `Generation.prepare(..., max(1, remaining(D)))`; commit only successful prepared
  results. On any error, reject the admitted operation, then release preparations
  and forward the original error. There is no conversion from `:prepare_timeout`
  to the outer call-timeout tuple.
- `apps/gaoxy_http/lib/gaoxy/http/generation.ex:86–99,731–784`: prepare creates a
  new inner absolute deadline from its relative timeout, allocates a linked and
  monitored worker owned by Generation.Store, sends it compile input, and awaits
  its result with50ms receipt headroom. The inner deadline is usually equal or
  very close to originalD, potentially later if scheduling occurs between taking
  remaining(D) and forming the new deadline. No exact order is guaranteed.
- `generation.ex:810–844,915–935`: late prepared results or the preparation timer
  produce `{:error, :prepare_timeout}`. The store sends an untrappable kill to
  the worker and joins its monitor termination before delivering its result;
  preparation metadata/monitor/timer are released. This worker is not the
  coordinator. A successful worker death does not release coordinator-owned pins.
- `coordinator.ex:320–329`: releases use `min(D, now+100ms)`; failed confirmations
  remain in `pending_pins` and schedule reconciliation after100ms. OnceD expires,
  owner-call wait is zero, so a suspended owner does not force a callback delay.
  Cleanup preserves ownership instead of reporting pins released without proof.
- `coordinator.ex:95–101,239–267`: cleanup status exposes pending preparation
  count, reconciliation retries under a fresh100ms cleanup slice, and any new
  activation/reload remains blocked while pins are outstanding.

## Preserved hosted evidence and remaining question

The authenticated `source-ci-e57fb086-failure/run.json` identifies hosted E2E
run41032538320 at sourcee57fb. Component and isolated-network passed; protocol
failed in this file (2tests/1failure); manual release-clients remained skipped.
`failed.log` matches the failure-summary SHA256
`40ff38a0dca9a08408b3c1d21946e56b2e1e195dfb08236b1ed9c373e74c6c74`.
At the original2000ms assertion the mailbox contained normal caller termination,
worker termination `:killed`, and the actual activation reply
`{:error, :prepare_timeout}`. This log proves the different outcome; it does not
contain enough timestamped events to prove the precise timer/scheduler ordering,
the current pin cleanup state or any unintended accepted-state mutation.

Source permits two near-D outcomes: outer caller timeout first returns the
asserted deadline/cleanup tuple, while inner prepare timeout delivered through a
coordinator reply can return `:prepare_timeout`. In particular a caller scheduled
afterD may find an already queued matching reply; the GenServer call is not a
post-receipt deadline validator. Suspended transport owner ensures cleanup is
unconfirmed but does not order those two messages. Astra has independently
reported the exact unchanged local test2/0; that is contextual worker information,
not a reviewer-executed check or runtime classification.

Required diagnostic evidence before final classification: record originalD,
inner preparationD, initializer acknowledgment, worker timer/kill/DOWN,
coordinator error/release/reply, and outer caller return timing. Also inspect
accepted declaration/baseline/PIDs and retained/reconciled pins. If no late
commit/ownership/cleanup invariant breaks and only error ordering differs, this
supports a deterministic fixture repair. If production requires a canonical
error for every after-D response, or state/ownership changes incorrectly, that
is a separate production finding and must not be hidden by test synchronization.

## Minimal deterministic fixture synchronization, conditional on diagnosis

After the existing initializer acknowledgment and transport-owner suspension,
synchronously suspend only the coordinator using
`:erlang.suspend_process(coordinator)`. Use guaranteed try/after cleanup to
resume it immediately after the unchanged original expired_activation assertion,
before all original DOWN, deadline, state, baseline/declaration and pending-pin
assertions. Register failure cleanup before any fallible wait. Keep the caller
and Generation.Store runnable throughout. This selects the original outer-call
timeout branch: no coordinator reply can win the race, while the store retains
its original preparation timer and independently kills/joins its worker.

Use the process-level suspension because `:sys.suspend(coordinator)` cannot
acknowledge while the coordinator callback blocks inside `Generation.prepare`.
Do not suspend the caller (it must reach originalD), the store (it owns the
original kill deadline), or the worker instead of the coordinator (the worker
is already blocked and its store can still publish a timeout reply). Do not
change1000ms operation/acknowledgment/DOWN/barrier deadlines,2000ms initializer
or result assertion deadlines, route fixtures, error patterns or pin assertions.
No production callback, fake result, sleep, timer extension or assertion union
is required for this conditional fixture design. Coordinator response is still
tested after it resumes through the same original state barrier.

This proposal intentionally controls which existing caller outcome is exercised;
it is insufficient to prove a stronger unsynchronized production canonical-error
contract. The active recovery owner must establish diagnosis and execute any
repair/qualification; this reviewer makes no source recommendation unconditional.

## Scope and handoff

Only `.audit/adaptive-resource-budget/standalone-recovery16-spec-review/` was
written. All code reads used `git show`/`git grep` against the frozen commit.
No tests, builds, network/privileged/runtime commands or Git mutations ran.
Existing failures, deadlines, cumulative counters and other workers' edits are
preserved. Reviewer repair rounds0; no escalation requested. Commands terminal,
reviewer writes stop at handoff. Parent and CORE Astra own runtime diagnosis,
potential test/product changes and all delivery gates.
