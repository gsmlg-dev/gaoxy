# CORE16 independent specification/code/evidence review

Task `ARB-STANDALONE-RECOVERY16-REVIEW`: **DONE**.
Verdict: **TEST_SYNCHRONIZATION_ACCEPTED_READY_FOR_FRESH_QUALIFICATION**.
No actionable finding remains in the frozen, one-file repair. This is a direct
Sol independent read-only review; runtime/build ownership remained with Astra
until its authenticated terminal handoff.

Repository `/home/gao/Workspace/gsmlg-opt/gaoxy`, branch `main`, reviewed baseline
and HEAD `e57fb086f5aa2093767832699907f3430f8334a6`. The sole changed input is
`apps/gaoxy_server/test/standalone_recovery_test.exs`, SHA256
`1737241e5d20b91c04ce796aa31fcb57f4ef7ea8987798a42317247b5fad0e53`.
The parent's separate hosted-e57 evidence archive is outside the source hash
roots and was preserved. A globally clean worktree was not required.

## Diagnosis and contract

The failed hosted E2E run41032538320 at sourcee57 contains a genuine2tests/
1failure receipt: expected outer `deadline_exceeded/cleanup_pending`, received
inner `prepare_timeout`. The caller exited normally and preparation worker was
killed. Its isolated-network and component jobs passed; protocol stopped at the
file, and later protocol checks were not run. The historical failure is retained
and its raw log SHA256 matches the existing failure summary.

Exact unchanged local execution passed2/0; local reproduction of the opposite
hosted result is not claimed. The original unmodified source's timestamp trace
also passed2/0. For both fixed/group cases it records identical outer activation
and inner preparation deadlines. Outer timeout return, Store timeout handler and
inner preparation timeout return all occur atD+1ms. For example both deadlines
are `-576460746400`, and all three events are `-576460746399`.

The frozen source establishes two independent result paths: Lifecycle.call
converts its GenServer.call timeout to the expected tuple; Generation.Store
kills/joins its worker and returns prepare_timeout. The coordinator forwards
that preparation result and attempts release with no remaining caller budget.
Suspending the transport owner preserves unconfirmed pins but cannot order the
two results. Thus the original fixture assumes a deadline ordering it does not
synchronize. No production defect has been demonstrated; universal canonical
error normalization is not asserted or implemented by this test repair.

The original contract remains: bounded initializer cancellation at the original
deadline, unchanged accepted routes/declaration/baseline, no runtime or owner
replacement, retained unconfirmed preparation pins, and successful subsequent
reconciliation, owner recovery, HTTP behavior and reload. The exact expected
outer error is retained to exercise that specific branch, with no alternative
error accepted as a pass.

## Code and preservation review

After the existing initializer acknowledgment and transport-owner suspension,
the test uses `:erlang.suspend_process(coordinator)` to hold only the
coordinator's reply. The activation caller and Generation.Store remain runnable;
the Store retains its own original timer and kills the actual initialization
worker. A try/after resumes the coordinator immediately after the unchanged
expected-error assertion, before every original DOWN, deadline and state/pin
barrier. The after block runs on assertion failure as well. Existing transport
owner on_exit cleanup remains identical. System-process suspension was correctly
avoided here: the coordinator is blocked inside a callback and cannot acknowledge
`:sys.suspend` before the callback finishes.

Fresh source authentication confirms all682 base inputs match committede57 and
the fixture15 publication bridge. The current map differs at this one test only;
the other681 inputs are byte-identical, including all production modules,
dependencies, manifests, workflows, and the four accepted fixture15 inputs.
Before snapshots, frozen task patch and after-owned hash match exactly.

The reviewer independently reversed the exact added wrapper text and recovered
the complete original test file byte-for-byte. The worker's authenticated AST
check additionally proves all37 original assertion nodes and24 Lifecycle/sys
calls are identical and the initializer is unchanged. Numeric deadlines remain:
operation1000ms, initializer2000ms, initializer acknowledgment1000ms, result
assertion2000ms, caller/worker DOWN1000ms, state barriers1000ms. All cleanup,
baseline/declaration, pending-pin, accepted-body and final-reload assertions
remain unchanged. There is no skip, altered assertion, fake output, sleep,
production hook or widened deadline.

## Authenticated verification evidence

All11 worker command receipts are terminal PASS with exit0, matching raw-log
hashes, unchanged source during execution and the appropriate original/repaired
682-input map.

| Worker-executed check | Actual result |
| --- | --- |
| Exact original focused command | 2tests,0failures |
| Exact-source original timestamp trace | 2tests,0failures; sameD verified |
| Repaired focused command, two schedulers | 2tests,0failures |
| Repaired timestamp trace | 2tests,0failures; independent Store timer retained |
| Repaired focused command, one scheduler | 2tests,0failures |
| Neighbor gateway lifecycle | 10tests,0failures |
| Neighbor listener-set and standalone generation | 6tests,0failures |
| AST preservation | 37assertions/24Lifecycle+syscalls/initializer identical |
| Strict compile and scoped format check | PASS,exit0 |
| Inventory and diff check | PASS,exit0;390/323/187,121active,143retained |

The four existing standalone_generation neighbor cases remain unscheduled
ordinary coverage and were not promoted into canonical inventory. Focused2/0
evidence is not a rerun of900 canonical cases or of full hosted protocol gates.

Fresh reviewer command
`python3 .audit/adaptive-resource-budget/standalone-recovery16-review/verify_evidence.py`
returned exit0 at `2026-10-30T09:33:13.481268Z`. It authenticates source, traces,
receipts, logs and terminal handoff; it runs no Elixir/BEAM/test/build/network
runtime. All reads/writes remain inside the assignment's permitted boundaries.

## Terminal handoff and remaining gates

The worker handoff finished at09:32:31Z, reports all commands terminal and no
active sessions, and releases the source/build lane to the parent. Its source
hash, counters and patch match the reviewed artifacts. Reviewer commands are
terminal; only this review directory was written and writes stop at handoff.
Reviewer repair rounds0; no new Astra escalation is requested. Cumulative CORE
Sol2/Astra16 compatibility counters remain historical; production14 is unchanged.

The parent owns fresh focused verification, exact committed-source bridge,
commit/push/read-back, five exact-SHA hosted workflows and guarded publication
plus public runtime/artifact acceptance. Original hostedFAIL and localPASS keep
their actual source and dispositions. This verdict accepts the deterministic
test synchronization; it does not claim full delivery, a product fix, universal
error normalization or a new hosted PASS. No product decision is needed for
this bounded repair. Existing specialist/native-memory/deployment exclusions
and the fixed2026-10-31T02:09:44Z deadline remain unchanged.
