#!/usr/bin/env python3
"""Authenticate frozen test-only synchronization and worker evidence; no runtime."""
from pathlib import Path
import datetime
import hashlib
import json
import re
import subprocess

ROOT = Path('/home/gao/Workspace/gsmlg-opt/gaoxy')
BASE = ROOT / '.audit/adaptive-resource-budget/core/time-quota/standalone-recovery16'
OUT = Path(__file__).resolve().parent
HEAD = 'e57fb086f5aa2093767832699907f3430f8334a6'
OWNED = 'apps/gaoxy_server/test/standalone_recovery_test.exs'
def digest(data): return hashlib.sha256(data).hexdigest()
def load(path): return json.loads(path.read_text())
def git(*args): return subprocess.check_output(['git', *args], cwd=ROOT)
assert git('rev-parse', 'HEAD').decode().strip() == HEAD
assert git('branch', '--show-current').decode().strip() == 'main'
before = load(BASE / 'before-hashes.json')
bridge = load(ROOT / '.audit/adaptive-resource-budget/publication-source-bridge-fixture15.json')
assert before == bridge['source_hashes'] and len(before) == 682
current = {p: digest((ROOT / p).read_bytes()) for p in before}
assert [p for p in before if before[p] != current[p]] == [OWNED]
assert load(BASE / 'after-owned-hashes.json') == {OWNED: current[OWNED]}
for p, sha in before.items():
    assert digest(git('show', f'{HEAD}:{p}')) == sha, p
assert git('diff', '--src-prefix=i/', '--dst-prefix=w/', 'HEAD', '--', OWNED) == (BASE / 'task.patch').read_bytes()
old = (BASE / 'before' / OWNED).read_text()
assert old.encode() == git('show', f'{HEAD}:{OWNED}')
new = (ROOT / OWNED).read_text()
previous = '''    assert_receive {:expired_activation, ^caller,
                    {:error, {:deadline_exceeded, :cleanup_pending}}},
                   2000'''
replacement = '''    # The preparation timer and caller deadline can expire in the same tick.
    # Hold the coordinator's reply until the caller observes its own deadline;
    # the generation store remains runnable and still terminates the worker.
    true = :erlang.suspend_process(coordinator)

    try do
      assert_receive {:expired_activation, ^caller,
                      {:error, {:deadline_exceeded, :cleanup_pending}}},
                     2000
    after
      if Process.alive?(coordinator), do: :erlang.resume_process(coordinator)
    end'''
assert replacement in new and new.replace(replacement, previous) == old
assert new.count(':erlang.suspend_process(coordinator)') == 1
assert new.count(':erlang.resume_process(coordinator)') == 1
assert 'deadline = Lifecycle.deadline(1000)' in new
assert 'assert_receive {:DOWN, ^worker_monitor, :process, ^worker, :killed}, 1000' in new
assert ':sys.get_state(coordinator, 1000)' in new

required = {'original-standalone', 'original-traced', 'round16-focused', 'round16-traced',
            'round16-one-scheduler', 'round16-neighbors', 'round16-assertions',
            'round16-compile', 'round16-format', 'round16-inventory', 'round16-diff-check'}
receipts = {}
for path in sorted(BASE.glob('*.json')):
    r = load(path)
    if 'label' not in r: continue
    assert r['label'] in required, path
    assert r['source'] == HEAD and r['source_changes'] == [] and r['commands_terminal'] is True
    assert r['status'] == 'PASS' and r['exit'] == 0
    assert r['source_hashes'] == (before if r['label'].startswith('original-') else current), path
    log = ROOT / r['log']
    assert digest(log.read_bytes()) == r['log_sha256'], path
    text = log.read_text()
    counts = [(int(n), int(f)) for n, f in re.findall(r'(?m)^\s*(\d+) tests?, (\d+) failures?[^\n]*$', text)]
    if r['label'] in {'original-standalone', 'original-traced', 'round16-focused', 'round16-traced', 'round16-one-scheduler'}:
        assert counts == [(2, 0)], path
    if r['label'] == 'round16-neighbors': assert counts == [(10, 0), (6, 0)]
    if r['label'] == 'round16-one-scheduler': assert r['environment']['ELIXIR_ERL_OPTIONS'] == '+S 1:1'
    receipts[r['label']] = {k: r[k] for k in ('status', 'exit', 'command', 'environment', 'started_at', 'elapsed_seconds', 'log', 'log_sha256')}
    receipts[r['label']]['receipt_sha256'] = digest(path.read_bytes())
    receipts[r['label']]['test_summaries'] = counts
assert set(receipts) == required
assertions = load(BASE / 'assertions-check.json')
assert assertions == {'status': 'PASS', 'identical_assertions': 37, 'identical_lifecycle_and_sys_calls': 24, 'initializer_unchanged': True}
assert 'INVENTORY_PASS unit=390, component=323, protocol=187 active_files=121 retained_files=143' in (BASE / 'round16-inventory.log').read_text()

traces = {}
for name in ('original-traced', 'round16-traced'):
    text = (BASE / f'{name}.log').read_text()
    events = [part.split('\n}', 1)[0] if part.startswith('\n') else part.split('\n', 1)[0]
              for part in text.split('RACE_TRACE: %{')[1:]]
    expiry = []
    for index, event in enumerate(events):
        if 'expiring: true' not in event: continue
        deadline = int(re.search(r'deadline: (-?\d+)', event).group(1))
        next_expiring = next((i for i in range(index+1, len(events)) if 'expiring:' in events[i]), len(events))
        tail = events[index+1:next_expiring]
        prepare = next(x for x in tail if 'event: :prepare_begin' in x)
        assert int(re.search(r'deadline: (-?\d+)', prepare).group(1)) == deadline
        outer = next(x for x in tail if '{Gaoxy.Proxy.Gateway.Coordinator, :activate, 5}' in x)
        inner = next(x for x in tail if '{Gaoxy.HTTP.Generation, :prepare, 3}' in x)
        timer = next(x for x in tail if 'event: :prepare_timer' in x)
        assert '{:error, {:deadline_exceeded, :cleanup_pending}}' in outer
        assert '{:error, :prepare_timeout}' in inner
        at = lambda x: int(re.search(r'at: (-?\d+)', x).group(1))
        assert at(outer) >= deadline and at(inner) >= deadline and at(timer) >= deadline
        expiry.append({'deadline': deadline, 'outer_return': at(outer), 'prepare_timer': at(timer), 'inner_return': at(inner)})
    assert len(expiry) == 2, name
    traces[name] = expiry

failure = ROOT / '.audit/adaptive-resource-budget/delivery/source-ci-e57fb086-failure'
hosted = load(failure / 'run.json')
summary = load(failure / 'failure-summary.json')
assert hosted['headSha'] == HEAD and hosted['conclusion'] == 'failure'
assert summary['failed_file_counts'] == {'tests': 2, 'failures': 1}
assert digest((failure / 'failed.log').read_bytes()) == summary['log_sha256']
assert 'value:   {:expired_activation,' in (failure / 'failed.log').read_text()
assert '{:error, :prepare_timeout}' in (failure / 'failed.log').read_text()

handoff_path = BASE / 'handoff.json'
handoff = load(handoff_path)
assert handoff['commands_terminal'] is True
assert handoff['active_sessions'] == []
assert handoff['cumulative_astra_repair_attempts'] == 16
assert handoff['production_repair_counter_unchanged'] == 14
assert handoff['received_sol_repairs'] == 2
assert handoff['owned_hashes'] == {OWNED: current[OWNED]}
result = {'status': 'PASS', 'verified_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'baseline': HEAD, 'source_inputs': 682, 'source_hashes': current,
          'changed_inputs': [OWNED], 'unchanged_inputs': 681,
          'exact_one_block_wrapper_delta': True, 'assertion_preservation': assertions,
          'all_original_deadlines_cleanup_recovery_unchanged': True,
          'receipts': receipts, 'traces': traces,
          'preserved_hosted_failure': {'run': hosted['databaseId'], 'source': HEAD, 'counts': summary['failed_file_counts'], 'log_sha256': summary['log_sha256']},
          'handoff_sha256': digest(handoff_path.read_bytes()), 'worker_commands_terminal': True,
          'reviewer_tests_build_runtime_privilege_network_run': False, 'reviewer_commands_terminal': True,
          'untracked_parent_archives_not_required_clean': True}
(OUT / 'validation.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('source_hashes', 'receipts')}, indent=2))
