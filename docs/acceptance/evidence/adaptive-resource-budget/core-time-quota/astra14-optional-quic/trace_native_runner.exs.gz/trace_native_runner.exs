tracer = spawn(fn ->
  loop = fn loop, last ->
    receive do
      {:trace, _pid, :call, {Gaoxy.QUICBridge, :native_bytes, [{:ok, %{resources: resources}}]}} ->
        total = Enum.reduce([:queued_bytes, :ready_bytes, :receive_buffered_bytes, :io_queue_bytes, :operation_result_bytes], 0, fn key, sum -> sum + Map.get(resources, key, 0) end)
        if total > 250_000, do: IO.inspect(resources, label: "QUIC_NATIVE_COMPONENTS", limit: :infinity)
        loop.(loop, last)
      {:trace, pid, :call, {Gaoxy.Admission, :handle_call, [request, _from, state]}} ->
        loop.(loop, Map.put(last, pid, {request, state}))
      {:trace, pid, :return_from, {Gaoxy.Admission, :handle_call, 3}, {:reply, {:error, :byte_limit}, _}} ->
        {request, before} = Map.fetch!(last, pid)
        summary = %{request: request, mode: before.mode, limits: before.limits,
          bytes: before.bytes,
          leases: Map.new(before.leases, fn {ref, lease} -> {ref, Map.take(lease, [:pid, :bytes, :accounting, :deadline, :request_active])} end),
          cleanups: Map.new(before.cleanups, fn {ref, cleanup} -> {ref, Map.take(cleanup, [:bytes, :native_bytes, :overhead, :accounting, :native_phase])} end)}
        IO.inspect(summary, label: "QUIC_BYTE_LIMIT_TRACE", limit: :infinity, printable_limit: :infinity)
        loop.(loop, last)
      _ -> loop.(loop, last)
    end
  end
  loop.(loop, %{})
end)
Code.ensure_loaded!(Gaoxy.Admission)
Code.ensure_loaded!(Gaoxy.QUICBridge)
:erlang.trace_pattern({Gaoxy.QUICBridge, :native_bytes, 1}, true, [:local])
:erlang.trace_pattern({Gaoxy.Admission, :handle_call, 3}, [{:_, [], [{:return_trace}]}], [:local])
:erlang.trace(:new_processes, true, [:call, {:tracer, tracer}])
Mix.Task.run("test", ["--seed", "0", "--max-cases", "1"])
