tracer = spawn(fn ->
  loop = fn loop, peaks, events ->
    receive do
      {:trace, _pid, :call, {Gaoxy.QUICBridge, :native_bytes, [{:ok, %{resources: resources}}]}} ->
        metrics = Map.take(resources, [:queued_bytes, :ready_bytes, :receive_buffered_bytes, :io_queue_bytes, :operation_result_bytes, :operations])
        total = Enum.reduce([:queued_bytes, :ready_bytes, :receive_buffered_bytes, :io_queue_bytes, :operation_result_bytes], 0, fn key, sum -> sum + Map.get(resources, key, 0) end)
        peaks = Map.merge(peaks, Map.put(metrics, :native_total, total), fn _key, old, new -> max(old, new) end)
        loop.(loop, peaks, events)
      {:trace, _pid, :call, {Gaoxy.Admission, :handle_call, [_request, _from, state]}} ->
        peaks = Map.update(peaks, :admission_bytes, state.bytes, &max(&1, state.bytes))
        loop.(loop, peaks, events)
      {:trace, _pid, :call, {Gaoxy.QUICBridge, :terminate, [reason, _state]}} ->
        loop.(loop, peaks, Enum.take([{:callback_terminate, reason} | events], 40))
      {:trace, _pid, :call, {Abyss.QUIC, :close, [_connection, code, reason, options]}} ->
        loop.(loop, peaks, Enum.take([{:public_close, code, byte_size(reason), options} | events], 40))
      {:snapshot, caller, ref} ->
        send(caller, {ref, %{peaks: peaks, termination_events: Enum.reverse(events)}})
        loop.(loop, peaks, events)
      _ -> loop.(loop, peaks, events)
    end
  end
  loop.(loop, %{}, [])
end)
for module <- [Gaoxy.Admission, Gaoxy.QUICBridge, Abyss.QUIC], do: Code.ensure_loaded!(module)
for {module, function, arity} <- [{Gaoxy.QUICBridge, :native_bytes, 1}, {Gaoxy.Admission, :handle_call, 3}, {Gaoxy.QUICBridge, :terminate, 2}, {Abyss.QUIC, :close, 4}] do
  :erlang.trace_pattern({module, function, arity}, true, [:local])
end
:erlang.trace(:new_processes, true, [:call, {:tracer, tracer}])
ExUnit.start(autorun: false)
ExUnit.after_suite(fn summary ->
  delivered = :erlang.trace_delivered(:all)
  receive do
    {:trace_delivered, :all, ^delivered} -> :ok
  after
    2_000 -> raise "trace delivery deadline"
  end
  ref = make_ref()
  send(tracer, {:snapshot, self(), ref})
  receive do
    {^ref, observations} -> IO.inspect(Map.put(observations, :suite, summary), label: "QUIC_FULL_EXCHANGE_METRICS", limit: :infinity)
  after
    2_000 -> raise "trace snapshot deadline"
  end
end)
Mix.Task.run("test", ["--seed", "0", "--max-cases", "1"])
