import os
from pathlib import Path
os.environ['LD_LIBRARY_PATH'] = Path('.audit/release-0.9.0/public-runtime-library-path.txt').read_text()
os.execvp('python3', ['python3', '.audit/release-0.9.0-public-runtime-verifier.py'])
