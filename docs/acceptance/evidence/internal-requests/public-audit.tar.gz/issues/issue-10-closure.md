Released in [Gaoxy v0.9.0](https://github.com/gsmlg-dev/gaoxy/releases/tag/v0.9.0), source `ed3fbbfbe4016906b10a97711193d341f3d9ed4f`.

HTTP and H3 child specs now share the pure validated core shutdown-budget calculation, including finite cleanup headroom. User Plug initialization remains deferred until startup. Actual supervised active H1 uploads drain under default 5000 ms and configured 5500 ms limits, with runtime/socket cleanup and port reuse. H3 evidence covers budget and initialization contracts.

The coordinated public Hex packages, clean public-package consumers, Phoenix integration tests and downloaded standalone artifact were independently verified. See [release acceptance](https://github.com/gsmlg-dev/gaoxy/blob/main/docs/acceptance/release-0.9.0.md) for exact counts, source identity and scope. Downstream application migration and production acceptance remain with the requesting application.
