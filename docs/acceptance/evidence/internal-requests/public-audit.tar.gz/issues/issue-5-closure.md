Released in [Gaoxy v0.9.0](https://github.com/gsmlg-dev/gaoxy/releases/tag/v0.9.0), source `ed3fbbfbe4016906b10a97711193d341f3d9ed4f`.

Forwarded and validated client-verification TLS settings through the core and Phoenix/listener adapters. Actual TLS 1.2/1.3 HTTP and WebSocket tests cover verified DER peer identity, optional enrollment, untrusted CA rejection, required certificates and forged-header isolation.

The coordinated public Hex packages, clean public-package consumers, Phoenix integration tests and downloaded standalone artifact were independently verified. See [release acceptance](https://github.com/gsmlg-dev/gaoxy/blob/main/docs/acceptance/release-0.9.0.md) for exact counts, source identity and scope. Downstream application migration and production acceptance remain with the requesting application.
