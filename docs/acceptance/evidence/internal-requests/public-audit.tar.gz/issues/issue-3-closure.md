Released in [Gaoxy v0.9.0](https://github.com/gsmlg-dev/gaoxy/releases/tag/v0.9.0), source `ed3fbbfbe4016906b10a97711193d341f3d9ed4f`.

Added opt-in `:request`, finite, and `:infinity` response-stream lifetimes on native H1/H2, with public route-level controls. Request acquisition, individual I/O and shutdown remain finite; H3 rejects custom lifetimes explicitly.

The coordinated public Hex packages, clean public-package consumers, Phoenix integration tests and downloaded standalone artifact were independently verified. See [release acceptance](https://github.com/gsmlg-dev/gaoxy/blob/main/docs/acceptance/release-0.9.0.md) for exact counts, source identity and scope. Downstream application migration and production acceptance remain with the requesting application.
