set -euo pipefail
export ELIXIR_ERL_OPTIONS='+S 2:2'
export GAOXY_QUIC_PYTHON="$PWD/.audit/h2peer/bin/python"
export MIX_ENV=test
python3 scripts/check-tests.py apps/gaoxy/test/client_certificate_config_test.exs apps/gaoxy_http/test/phoenix_client_certificate_config_test.exs apps/gaoxy_http/test/websocket_configured_limits_test.exs apps/gaoxy_http/test/websocket_application_options_test.exs apps/gaoxy_http/test/stream_lifetime_test.exs apps/gaoxy_http/test/stream_lifetime_h2_test.exs apps/gaoxy_http/test/stream_lifetime_contract_test.exs apps/gaoxy_http/test/stream_lifetime_generation_test.exs apps/gaoxy_http3/test/stream_lifetime_boundary_test.exs apps/gaoxy_http/test/supervised_shutdown_budget_test.exs apps/gaoxy_http3/test/supervised_shutdown_budget_test.exs --seed 0 --max-cases 1 > .audit/release-0.9.0/internal-final-root.log 2>&1
python3 scripts/check-repairs.py all > .audit/release-0.9.0/ordinary-final.log 2>&1
mix format --check-formatted > .audit/release-0.9.0/format-final.log 2>&1
MIX_ENV=prod mix compile --warnings-as-errors > .audit/release-0.9.0/compile-final.log 2>&1
MIX_ENV=prod mix release gaoxy --overwrite > .audit/release-0.9.0/release-build.log 2>&1
