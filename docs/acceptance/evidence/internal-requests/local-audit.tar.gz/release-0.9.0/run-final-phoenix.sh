set -euo pipefail
export ELIXIR_ERL_OPTIONS='+S 2:2'
export PHOENIX_NATIVE_H3=1
export MIX_ENV=test
cd examples/phoenix_native
mix deps.get --check-locked > ../../.audit/release-0.9.0/phoenix-dependencies.log 2>&1
python3 ../../scripts/check-tests.py test/client_certificate_test.exs test/websocket_configured_limits_test.exs test/stream_lifetime_test.exs test/websocket_phoenix_compatibility_test.exs --seed 0 --max-cases 1 > ../../.audit/release-0.9.0/internal-final-phoenix.log 2>&1
MIX_ENV=dev PHOENIX_NATIVE_H2=1 PHOENIX_NATIVE_RELOAD=1 mix compile --warnings-as-errors > ../../.audit/release-0.9.0/phoenix-dev-compile.log 2>&1
cd ../..
GAOXY_PHOENIX_EVIDENCE=.audit/release-0.9.0/unified-phoenix .audit/h2peer/bin/python integration/phoenix_native/unified.py > .audit/release-0.9.0/unified-phoenix.log 2>&1
