import concurrent.futures,json,os,re,subprocess
from pathlib import Path
root=Path.cwd()
base=root/'.audit/release-0.9.0'
names=['external','http','h3','gateway','h3-gateway']
env=dict(os.environ,ELIXIR_ERL_OPTIONS='+S 2:2',GAOXY_CONSUMER_DEPS=str(root/'deps'),GAOXY_QUIC_PYTHON=str(root/'.audit/h2peer/bin/python'))
def run(name):
    log=base/f'{name}-consumer.log'
    command=['bash',f'scripts/{name}-consumer.sh']
    with log.open('w') as output:
        result=subprocess.run(command,env=env,stdout=output,stderr=subprocess.STDOUT,timeout=600)
    text=log.read_text()
    counts=re.findall(r'(\d+) tests?, (\d+) failures?',text)
    success=result.returncode==0 and bool(counts) and all(int(n)>0 and int(f)==0 for n,f in counts)
    return {'name':name,'command':command,'exit':result.returncode,'status':'PASS' if success else 'FAIL','tests':sum(int(n) for n,_ in counts),'summaries':counts,'log':str(log)}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    results=list(pool.map(run,names))
report={'status':'PASS' if all(r['status']=='PASS' for r in results) else 'FAIL','tests':sum(r['tests'] for r in results),'consumers':results}
(base/'local-consumers.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
raise SystemExit(0 if report['status']=='PASS' else 1)
