set -euo pipefail
export ELIXIR_ERL_OPTIONS='+S 2:2'
python3 scripts/release-smoke.py > .audit/release-0.9.0/core-release-smoke.log 2>&1
.audit/h2peer/bin/python scripts/gateway-release-smoke.py > .audit/release-0.9.0/gateway-release-smoke.log 2>&1
.audit/h2peer/bin/python scripts/h3-release-smoke.py --evidence .audit/release-0.9.0/h3-release-smoke > .audit/release-0.9.0/h3-release-smoke.log 2>&1
