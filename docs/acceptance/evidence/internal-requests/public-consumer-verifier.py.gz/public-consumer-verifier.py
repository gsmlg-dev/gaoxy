#!/usr/bin/env python3
"""Prepare/run isolated public Hex consumers; run only after publication signal."""
import argparse
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import time
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / '.audit/release-0.9.0-public-consumers'
VERSION = '0.9.0'
PROJECTS = {
    'core_consumer': (['gaoxy'], 2),
    'http_consumer': (['gaoxy', 'gaoxy_http'], 10),
    'gateway_consumer': (['gaoxy', 'gaoxy_http', 'gaoxy_proxy'], 2),
    'h3_gateway_consumer': (['gaoxy', 'gaoxy_http', 'gaoxy_proxy', 'gaoxy_http3'], 4),
}
PACKAGES = ['gaoxy_websock_adapter', 'gaoxy', 'gaoxy_http', 'gaoxy_http3', 'gaoxy_proxy']


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def receipt(value):
    (EVIDENCE / 'receipt.json').write_text(json.dumps(value, indent=2) + '\n')


def prepare():
    if EVIDENCE.exists():
        raise SystemExit(f'evidence directory already exists: {EVIDENCE}')
    EVIDENCE.mkdir(parents=True)
    source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    locks = [line for line in (ROOT / 'mix.lock').read_text().splitlines() if '{:hex,' in line]
    (EVIDENCE / 'upstream-cohort.lock').write_text('%{\n' + '\n'.join(locks) + '\n}\n')
    files = {}
    for name, (apps, expected) in PROJECTS.items():
        isolated = EVIDENCE / name
        project = isolated / 'integration' / name
        project.mkdir(parents=True)
        shutil.copytree(ROOT / 'integration' / name / 'test', project / 'test')
        if name == 'http_consumer':
            shutil.copy2(ROOT / 'apps/gaoxy_http/test/supervised_shutdown_budget_test.exs', project / 'test/supervised_shutdown_budget_test.exs')
        if name == 'h3_gateway_consumer':
            shutil.copy2(ROOT / 'apps/gaoxy_http3/test/supervised_shutdown_budget_test.exs', project / 'test/supervised_shutdown_budget_test.exs')
        files[name] = {str(path.relative_to(project)): digest(path)
                       for path in sorted((project / 'test').glob('*.exs'))}
        deps = [f'{{:{app}, "== {VERSION}", override: true}}' for app in apps]
        if name != 'core_consumer':
            deps.append(f'{{:websock_adapter, "== {VERSION}", hex: :gaoxy_websock_adapter, override: true}}')
        manifest = f'''defmodule Public{name.title().replace('_', '')}.MixProject do
  use Mix.Project
  def project, do: [app: :{name}, version: "0.1.0", elixir: "~> 1.18", deps: [{', '.join(deps)}]]
  def application, do: [extra_applications: [:logger]]
end
'''
        (project / 'mix.exs').write_text(manifest)
        shutil.copy2(EVIDENCE / 'upstream-cohort.lock', project / 'mix.lock')
        expected_apps = '[' + ', '.join(':' + app for app in apps) + ']'
        absent = [':gaoxy_server'] + ([] if 'gaoxy_http3' in apps else [':gaoxy_http3'])
        isolation = f'''defmodule PublicHexIsolationTest do
  use ExUnit.Case, async: true
  test "published applications retain exact versions and optional boundaries" do
    resolved = Mix.Dep.load_and_cache()
    for dependency <- resolved, do: assert(dependency.scm == Hex.SCM)
    for app <- {expected_apps}, do: assert(to_string(Application.spec(app, :vsn)) == "{VERSION}")
    for app <- [{', '.join(absent)}] do
      refute Enum.any?(resolved, &(&1.app == app))
      assert {{:error, :bad_name}} = :code.lib_dir(app)
    end
    refute Code.ensure_loaded?(Gaoxy.Server.Application)
  end
end
'''
        (project / 'test/public_hex_isolation_test.exs').write_text(isolation)
        if name == 'h3_gateway_consumer':
            for relative in ['integration/gateway/peer.py', 'integration/http3/peer.py',
                             'apps/gaoxy_http/test/support/listener_set_peer.py',
                             'scripts/generate-fixtures.sh']:
                target = isolated / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(ROOT / relative, target)
    receipt({'status': 'PREPARED_NOT_RUN', 'version': VERSION, 'source_sha': source,
             'source_test_hashes': files, 'expected_tests': {name: spec[1] for name, spec in PROJECTS.items()},
             'upstream_cohort_sha256': digest(EVIDENCE / 'upstream-cohort.lock'),
             'note': 'Awaiting explicit parent publication signal; no dependencies resolved, built or tested.'})
    print(f'PREPARED {EVIDENCE}; expected 18 tests across four isolated Hex consumers')


def metadata():
    result = {}
    for package in PACKAGES:
        url = f'https://hex.pm/api/packages/{package}/releases/{VERSION}'
        request = urllib.request.Request(url, headers={'User-Agent': 'Gaoxy-public-consumer-validation'})
        with urllib.request.urlopen(request, timeout=30) as response:
            value = json.load(response)
        assert value['version'] == VERSION, value
        assert re.fullmatch('[0-9a-f]{64}', value['checksum']), value
        (EVIDENCE / f'{package}-metadata.json').write_text(json.dumps(value, indent=2) + '\n')
        result[package] = {'url': url, 'version': value['version'], 'checksum': value['checksum']}
    return result


def validate(name, public):
    apps, expected = PROJECTS[name]
    isolated = EVIDENCE / name
    project = isolated / 'integration' / name
    environment = dict(os.environ, MIX_ENV='test', ELIXIR_ERL_OPTIONS='+S 4:4',
                       HEX_HOME=str(isolated / 'hex-cache'),
                       MIX_DEPS_PATH=str(project / 'deps'), MIX_BUILD_PATH=str(project / '_build'),
                       GAOXY_QUIC_PYTHON=str(ROOT / '.audit/h2peer/bin/python'))
    commands = [['mix', 'deps.get'], ['mix', 'deps.get', '--check-locked'],
                ['mix', 'compile', '--warnings-as-errors'],
                ['mix', 'test', '--warnings-as-errors', '--seed', '0', '--max-cases', '1']]
    status = {'status': 'RUNNING', 'project': str(project), 'commands': commands, 'expected_tests': expected}
    log_path = EVIDENCE / f'{name}.log'
    with log_path.open('w') as log:
        try:
            for command in commands:
                log.write('PUBLIC_CONSUMER_COMMAND ' + json.dumps(command) + '\n')
                log.flush()
                outcome = subprocess.run(command, cwd=project, env=environment, text=True,
                                         stdout=log, stderr=subprocess.STDOUT, timeout=600)
                assert outcome.returncode == 0, f'{command}: exit {outcome.returncode}'
            output = log_path.read_text()
            counts = re.findall(r'(\d+) tests?, (\d+) failures?', output)
            assert counts == [(str(expected), '0')], counts
            lock = (project / 'mix.lock').read_text()
            assert '{:git,' not in lock and 'path:' not in lock
            before = dict(re.findall(r'^  "([^"]+)": (.*)$', (EVIDENCE / 'upstream-cohort.lock').read_text(), re.M))
            after = dict(re.findall(r'^  "([^"]+)": (.*)$', lock, re.M))
            for package, value in before.items():
                if package in after:
                    assert after[package] == value, f'upstream cohort changed: {package}'
            artifacts = {}
            for package in apps + ([] if name == 'core_consumer' else ['gaoxy_websock_adapter']):
                cached = list((isolated / 'hex-cache').rglob(f'{package}-{VERSION}.tar'))
                assert len(cached) == 1, (package, cached)
                checksum = digest(cached[0])
                assert checksum == public[package]['checksum'], (package, checksum)
                artifacts[package] = {'path': str(cached[0]), 'sha256': checksum}
            for path, checksum in json.loads((EVIDENCE / 'receipt.json').read_text())['source_test_hashes'][name].items():
                assert digest(project / path) == checksum, f'original test changed: {path}'
            status.update(status='PASS', tests=expected, failures=0, artifacts=artifacts,
                          lock_sha256=digest(project / 'mix.lock'), log=str(log_path))
        except Exception as error:
            status.update(status='FAIL', error=repr(error), log=str(log_path))
    (EVIDENCE / f'{name}-receipt.json').write_text(json.dumps(status, indent=2) + '\n')
    return name, status


def run(signal):
    report = json.loads((EVIDENCE / 'receipt.json').read_text())
    assert report['status'] == 'PREPARED_NOT_RUN', report['status']
    report.update(status='RUNNING', publication_signal=signal, started_at=time.time())
    receipt(report)
    try:
        public = metadata()
        report['public_metadata'] = public
        receipt(report)
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            results = dict(pool.map(lambda name: validate(name, public), PROJECTS))
        report.update(consumers=results,
                      status='PASS' if all(value['status'] == 'PASS' for value in results.values()) else 'FAIL',
                      tests=sum(value.get('tests', 0) for value in results.values()))
    except Exception as error:
        report.update(status='BLOCKED_ENV', error=repr(error))
    report['finished_at'] = time.time()
    receipt(report)
    print(json.dumps(report, indent=2))
    return 0 if report['status'] == 'PASS' else 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=['prepare', 'run'])
    parser.add_argument('--publication-signal')
    arguments = parser.parse_args()
    if arguments.mode == 'prepare':
        prepare()
    else:
        if not arguments.publication_signal:
            parser.error('run requires the explicit parent publication signal')
        raise SystemExit(run(arguments.publication_signal))
