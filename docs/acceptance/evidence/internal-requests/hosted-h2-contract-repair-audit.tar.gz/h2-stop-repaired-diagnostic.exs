ExUnit.start(seed: 323678, max_cases: 4)
defmodule Gaoxy.HTTP.StreamLifetimeH2RepairedDiagnosticTest do
  use ExUnit.Case, async: true

  defmodule StreamPlug do
    def init(owner), do: owner

    def call(conn, owner) do
      if conn.request_path == "/ok" do
        Plug.Conn.send_resp(conn, 200, "sibling-ok")
      else
        conn =
          if conn.request_path == "/finite",
            do: conn,
            else: Gaoxy.HTTP.put_stream_timeout(conn, :infinity)

        conn = Plug.Conn.send_chunked(conn, 200)
        send(owner, {:h2_stream, self(), conn.request_path})
        if conn.request_path == "/cancel", do: Process.send_after(self(), :cancel, 100)
        loop(conn, owner)
      end
    end

    defp loop(conn, owner) do
      receive do
        :cancel ->
          Gaoxy.HTTP.abort(conn, :cancelled)
          conn
      after
        25 ->
          case Plug.Conn.chunk(conn, ": keepalive\n\n") do
            {:ok, next} ->
              loop(next, owner)

            {:error, reason} ->
              send(owner, {:h2_stream_error, self(), reason})
              conn
          end
      end
    end
  end

  test "Probe 0: H2 server drain stays bounded with an infinite stream and joins its worker" do
    {:ok, server} =
      Gaoxy.HTTP.start_link(
        plug: {StreamPlug, self()},
        protocols: [:http2],
        h2c: :prior_knowledge,
        http_limits: %{request_timeout: 200}
      )

    on_exit(fn -> if Process.alive?(server), do: Gaoxy.stop(server, 1_000) end)
    {:ok, {_, port}} = Gaoxy.info(server, :http).local
    {:ok, socket} = :gen_tcp.connect({127, 0, 0, 1}, port, [:binary, active: false], 1_000)
    on_exit(fn -> :gen_tcp.close(socket) end)

    {block, _} =
      HPAX.encode(
        [
          {:no_store, ":method", "GET"},
          {:no_store, ":scheme", "http"},
          {:no_store, ":authority", "localhost"},
          {:no_store, ":path", "/infinite"}
        ],
        HPAX.new(4096)
      )

    :ok =
      :gen_tcp.send(socket, [
        "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n",
        Gaoxy.HTTP.HTTP2.Frame.encode(4, 0, 0, ""),
        Gaoxy.HTTP.HTTP2.Frame.encode(1, 5, 1, block)
      ])

    assert_receive {:h2_stream, worker, "/infinite"}, 1_000
    monitor = Process.monitor(worker)
    server_monitor = Process.monitor(server)
    started = System.monotonic_time(:millisecond)
    result = Gaoxy.stop(server, 500)
    IO.inspect(result, label: "observed public H2 stop")

    # ADR 004 preserves the service aggregate when it wins the caller-deadline race.
    assert result in [
             :ok,
             {:error, {:deadline_exceeded, :cleanup_pending}},
             {:error, {:services, [http: {:error, {:deadline_exceeded, :cleanup_pending}}]}}
           ]

    assert System.monotonic_time(:millisecond) - started < 1_500
    assert_receive {:DOWN, ^monitor, :process, ^worker, _}, 1_000
    assert_receive {:DOWN, ^server_monitor, :process, ^server, :normal}, 1_000
  end

  test "Probe 1: H2 server drain stays bounded with an infinite stream and joins its worker" do
    {:ok, server} =
      Gaoxy.HTTP.start_link(
        plug: {StreamPlug, self()},
        protocols: [:http2],
        h2c: :prior_knowledge,
        http_limits: %{request_timeout: 200}
      )

    on_exit(fn -> if Process.alive?(server), do: Gaoxy.stop(server, 1_000) end)
    {:ok, {_, port}} = Gaoxy.info(server, :http).local
    {:ok, socket} = :gen_tcp.connect({127, 0, 0, 1}, port, [:binary, active: false], 1_000)
    on_exit(fn -> :gen_tcp.close(socket) end)

    {block, _} =
      HPAX.encode(
        [
          {:no_store, ":method", "GET"},
          {:no_store, ":scheme", "http"},
          {:no_store, ":authority", "localhost"},
          {:no_store, ":path", "/infinite"}
        ],
        HPAX.new(4096)
      )

    :ok =
      :gen_tcp.send(socket, [
        "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n",
        Gaoxy.HTTP.HTTP2.Frame.encode(4, 0, 0, ""),
        Gaoxy.HTTP.HTTP2.Frame.encode(1, 5, 1, block)
      ])

    assert_receive {:h2_stream, worker, "/infinite"}, 1_000
    monitor = Process.monitor(worker)
    server_monitor = Process.monitor(server)
    started = System.monotonic_time(:millisecond)
    result = Gaoxy.stop(server, 500)
    IO.inspect(result, label: "observed public H2 stop")

    # ADR 004 preserves the service aggregate when it wins the caller-deadline race.
    assert result in [
             :ok,
             {:error, {:deadline_exceeded, :cleanup_pending}},
             {:error, {:services, [http: {:error, {:deadline_exceeded, :cleanup_pending}}]}}
           ]

    assert System.monotonic_time(:millisecond) - started < 1_500
    assert_receive {:DOWN, ^monitor, :process, ^worker, _}, 1_000
    assert_receive {:DOWN, ^server_monitor, :process, ^server, :normal}, 1_000
  end

  test "Probe 2: H2 server drain stays bounded with an infinite stream and joins its worker" do
    {:ok, server} =
      Gaoxy.HTTP.start_link(
        plug: {StreamPlug, self()},
        protocols: [:http2],
        h2c: :prior_knowledge,
        http_limits: %{request_timeout: 200}
      )

    on_exit(fn -> if Process.alive?(server), do: Gaoxy.stop(server, 1_000) end)
    {:ok, {_, port}} = Gaoxy.info(server, :http).local
    {:ok, socket} = :gen_tcp.connect({127, 0, 0, 1}, port, [:binary, active: false], 1_000)
    on_exit(fn -> :gen_tcp.close(socket) end)

    {block, _} =
      HPAX.encode(
        [
          {:no_store, ":method", "GET"},
          {:no_store, ":scheme", "http"},
          {:no_store, ":authority", "localhost"},
          {:no_store, ":path", "/infinite"}
        ],
        HPAX.new(4096)
      )

    :ok =
      :gen_tcp.send(socket, [
        "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n",
        Gaoxy.HTTP.HTTP2.Frame.encode(4, 0, 0, ""),
        Gaoxy.HTTP.HTTP2.Frame.encode(1, 5, 1, block)
      ])

    assert_receive {:h2_stream, worker, "/infinite"}, 1_000
    monitor = Process.monitor(worker)
    server_monitor = Process.monitor(server)
    started = System.monotonic_time(:millisecond)
    result = Gaoxy.stop(server, 500)
    IO.inspect(result, label: "observed public H2 stop")

    # ADR 004 preserves the service aggregate when it wins the caller-deadline race.
    assert result in [
             :ok,
             {:error, {:deadline_exceeded, :cleanup_pending}},
             {:error, {:services, [http: {:error, {:deadline_exceeded, :cleanup_pending}}]}}
           ]

    assert System.monotonic_time(:millisecond) - started < 1_500
    assert_receive {:DOWN, ^monitor, :process, ^worker, _}, 1_000
    assert_receive {:DOWN, ^server_monitor, :process, ^server, :normal}, 1_000
  end

  test "Probe 3: H2 server drain stays bounded with an infinite stream and joins its worker" do
    {:ok, server} =
      Gaoxy.HTTP.start_link(
        plug: {StreamPlug, self()},
        protocols: [:http2],
        h2c: :prior_knowledge,
        http_limits: %{request_timeout: 200}
      )

    on_exit(fn -> if Process.alive?(server), do: Gaoxy.stop(server, 1_000) end)
    {:ok, {_, port}} = Gaoxy.info(server, :http).local
    {:ok, socket} = :gen_tcp.connect({127, 0, 0, 1}, port, [:binary, active: false], 1_000)
    on_exit(fn -> :gen_tcp.close(socket) end)

    {block, _} =
      HPAX.encode(
        [
          {:no_store, ":method", "GET"},
          {:no_store, ":scheme", "http"},
          {:no_store, ":authority", "localhost"},
          {:no_store, ":path", "/infinite"}
        ],
        HPAX.new(4096)
      )

    :ok =
      :gen_tcp.send(socket, [
        "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n",
        Gaoxy.HTTP.HTTP2.Frame.encode(4, 0, 0, ""),
        Gaoxy.HTTP.HTTP2.Frame.encode(1, 5, 1, block)
      ])

    assert_receive {:h2_stream, worker, "/infinite"}, 1_000
    monitor = Process.monitor(worker)
    server_monitor = Process.monitor(server)
    started = System.monotonic_time(:millisecond)
    result = Gaoxy.stop(server, 500)
    IO.inspect(result, label: "observed public H2 stop")

    # ADR 004 preserves the service aggregate when it wins the caller-deadline race.
    assert result in [
             :ok,
             {:error, {:deadline_exceeded, :cleanup_pending}},
             {:error, {:services, [http: {:error, {:deadline_exceeded, :cleanup_pending}}]}}
           ]

    assert System.monotonic_time(:millisecond) - started < 1_500
    assert_receive {:DOWN, ^monitor, :process, ^worker, _}, 1_000
    assert_receive {:DOWN, ^server_monitor, :process, ^server, :normal}, 1_000
  end

  test "Probe 4: H2 server drain stays bounded with an infinite stream and joins its worker" do
    {:ok, server} =
      Gaoxy.HTTP.start_link(
        plug: {StreamPlug, self()},
        protocols: [:http2],
        h2c: :prior_knowledge,
        http_limits: %{request_timeout: 200}
      )

    on_exit(fn -> if Process.alive?(server), do: Gaoxy.stop(server, 1_000) end)
    {:ok, {_, port}} = Gaoxy.info(server, :http).local
    {:ok, socket} = :gen_tcp.connect({127, 0, 0, 1}, port, [:binary, active: false], 1_000)
    on_exit(fn -> :gen_tcp.close(socket) end)

    {block, _} =
      HPAX.encode(
        [
          {:no_store, ":method", "GET"},
          {:no_store, ":scheme", "http"},
          {:no_store, ":authority", "localhost"},
          {:no_store, ":path", "/infinite"}
        ],
        HPAX.new(4096)
      )

    :ok =
      :gen_tcp.send(socket, [
        "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n",
        Gaoxy.HTTP.HTTP2.Frame.encode(4, 0, 0, ""),
        Gaoxy.HTTP.HTTP2.Frame.encode(1, 5, 1, block)
      ])

    assert_receive {:h2_stream, worker, "/infinite"}, 1_000
    monitor = Process.monitor(worker)
    server_monitor = Process.monitor(server)
    started = System.monotonic_time(:millisecond)
    result = Gaoxy.stop(server, 500)
    IO.inspect(result, label: "observed public H2 stop")

    # ADR 004 preserves the service aggregate when it wins the caller-deadline race.
    assert result in [
             :ok,
             {:error, {:deadline_exceeded, :cleanup_pending}},
             {:error, {:services, [http: {:error, {:deadline_exceeded, :cleanup_pending}}]}}
           ]

    assert System.monotonic_time(:millisecond) - started < 1_500
    assert_receive {:DOWN, ^monitor, :process, ^worker, _}, 1_000
    assert_receive {:DOWN, ^server_monitor, :process, ^server, :normal}, 1_000
  end

  test "Probe 5: H2 server drain stays bounded with an infinite stream and joins its worker" do
    {:ok, server} =
      Gaoxy.HTTP.start_link(
        plug: {StreamPlug, self()},
        protocols: [:http2],
        h2c: :prior_knowledge,
        http_limits: %{request_timeout: 200}
      )

    on_exit(fn -> if Process.alive?(server), do: Gaoxy.stop(server, 1_000) end)
    {:ok, {_, port}} = Gaoxy.info(server, :http).local
    {:ok, socket} = :gen_tcp.connect({127, 0, 0, 1}, port, [:binary, active: false], 1_000)
    on_exit(fn -> :gen_tcp.close(socket) end)

    {block, _} =
      HPAX.encode(
        [
          {:no_store, ":method", "GET"},
          {:no_store, ":scheme", "http"},
          {:no_store, ":authority", "localhost"},
          {:no_store, ":path", "/infinite"}
        ],
        HPAX.new(4096)
      )

    :ok =
      :gen_tcp.send(socket, [
        "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n",
        Gaoxy.HTTP.HTTP2.Frame.encode(4, 0, 0, ""),
        Gaoxy.HTTP.HTTP2.Frame.encode(1, 5, 1, block)
      ])

    assert_receive {:h2_stream, worker, "/infinite"}, 1_000
    monitor = Process.monitor(worker)
    server_monitor = Process.monitor(server)
    started = System.monotonic_time(:millisecond)
    result = Gaoxy.stop(server, 500)
    IO.inspect(result, label: "observed public H2 stop")

    # ADR 004 preserves the service aggregate when it wins the caller-deadline race.
    assert result in [
             :ok,
             {:error, {:deadline_exceeded, :cleanup_pending}},
             {:error, {:services, [http: {:error, {:deadline_exceeded, :cleanup_pending}}]}}
           ]

    assert System.monotonic_time(:millisecond) - started < 1_500
    assert_receive {:DOWN, ^monitor, :process, ^worker, _}, 1_000
    assert_receive {:DOWN, ^server_monitor, :process, ^server, :normal}, 1_000
  end

  test "Probe 6: H2 server drain stays bounded with an infinite stream and joins its worker" do
    {:ok, server} =
      Gaoxy.HTTP.start_link(
        plug: {StreamPlug, self()},
        protocols: [:http2],
        h2c: :prior_knowledge,
        http_limits: %{request_timeout: 200}
      )

    on_exit(fn -> if Process.alive?(server), do: Gaoxy.stop(server, 1_000) end)
    {:ok, {_, port}} = Gaoxy.info(server, :http).local
    {:ok, socket} = :gen_tcp.connect({127, 0, 0, 1}, port, [:binary, active: false], 1_000)
    on_exit(fn -> :gen_tcp.close(socket) end)

    {block, _} =
      HPAX.encode(
        [
          {:no_store, ":method", "GET"},
          {:no_store, ":scheme", "http"},
          {:no_store, ":authority", "localhost"},
          {:no_store, ":path", "/infinite"}
        ],
        HPAX.new(4096)
      )

    :ok =
      :gen_tcp.send(socket, [
        "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n",
        Gaoxy.HTTP.HTTP2.Frame.encode(4, 0, 0, ""),
        Gaoxy.HTTP.HTTP2.Frame.encode(1, 5, 1, block)
      ])

    assert_receive {:h2_stream, worker, "/infinite"}, 1_000
    monitor = Process.monitor(worker)
    server_monitor = Process.monitor(server)
    started = System.monotonic_time(:millisecond)
    result = Gaoxy.stop(server, 500)
    IO.inspect(result, label: "observed public H2 stop")

    # ADR 004 preserves the service aggregate when it wins the caller-deadline race.
    assert result in [
             :ok,
             {:error, {:deadline_exceeded, :cleanup_pending}},
             {:error, {:services, [http: {:error, {:deadline_exceeded, :cleanup_pending}}]}}
           ]

    assert System.monotonic_time(:millisecond) - started < 1_500
    assert_receive {:DOWN, ^monitor, :process, ^worker, _}, 1_000
    assert_receive {:DOWN, ^server_monitor, :process, ^server, :normal}, 1_000
  end

  test "Probe 7: H2 server drain stays bounded with an infinite stream and joins its worker" do
    {:ok, server} =
      Gaoxy.HTTP.start_link(
        plug: {StreamPlug, self()},
        protocols: [:http2],
        h2c: :prior_knowledge,
        http_limits: %{request_timeout: 200}
      )

    on_exit(fn -> if Process.alive?(server), do: Gaoxy.stop(server, 1_000) end)
    {:ok, {_, port}} = Gaoxy.info(server, :http).local
    {:ok, socket} = :gen_tcp.connect({127, 0, 0, 1}, port, [:binary, active: false], 1_000)
    on_exit(fn -> :gen_tcp.close(socket) end)

    {block, _} =
      HPAX.encode(
        [
          {:no_store, ":method", "GET"},
          {:no_store, ":scheme", "http"},
          {:no_store, ":authority", "localhost"},
          {:no_store, ":path", "/infinite"}
        ],
        HPAX.new(4096)
      )

    :ok =
      :gen_tcp.send(socket, [
        "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n",
        Gaoxy.HTTP.HTTP2.Frame.encode(4, 0, 0, ""),
        Gaoxy.HTTP.HTTP2.Frame.encode(1, 5, 1, block)
      ])

    assert_receive {:h2_stream, worker, "/infinite"}, 1_000
    monitor = Process.monitor(worker)
    server_monitor = Process.monitor(server)
    started = System.monotonic_time(:millisecond)
    result = Gaoxy.stop(server, 500)
    IO.inspect(result, label: "observed public H2 stop")

    # ADR 004 preserves the service aggregate when it wins the caller-deadline race.
    assert result in [
             :ok,
             {:error, {:deadline_exceeded, :cleanup_pending}},
             {:error, {:services, [http: {:error, {:deadline_exceeded, :cleanup_pending}}]}}
           ]

    assert System.monotonic_time(:millisecond) - started < 1_500
    assert_receive {:DOWN, ^monitor, :process, ^worker, _}, 1_000
    assert_receive {:DOWN, ^server_monitor, :process, ^server, :normal}, 1_000
  end

  test "Probe 8: H2 server drain stays bounded with an infinite stream and joins its worker" do
    {:ok, server} =
      Gaoxy.HTTP.start_link(
        plug: {StreamPlug, self()},
        protocols: [:http2],
        h2c: :prior_knowledge,
        http_limits: %{request_timeout: 200}
      )

    on_exit(fn -> if Process.alive?(server), do: Gaoxy.stop(server, 1_000) end)
    {:ok, {_, port}} = Gaoxy.info(server, :http).local
    {:ok, socket} = :gen_tcp.connect({127, 0, 0, 1}, port, [:binary, active: false], 1_000)
    on_exit(fn -> :gen_tcp.close(socket) end)

    {block, _} =
      HPAX.encode(
        [
          {:no_store, ":method", "GET"},
          {:no_store, ":scheme", "http"},
          {:no_store, ":authority", "localhost"},
          {:no_store, ":path", "/infinite"}
        ],
        HPAX.new(4096)
      )

    :ok =
      :gen_tcp.send(socket, [
        "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n",
        Gaoxy.HTTP.HTTP2.Frame.encode(4, 0, 0, ""),
        Gaoxy.HTTP.HTTP2.Frame.encode(1, 5, 1, block)
      ])

    assert_receive {:h2_stream, worker, "/infinite"}, 1_000
    monitor = Process.monitor(worker)
    server_monitor = Process.monitor(server)
    started = System.monotonic_time(:millisecond)
    result = Gaoxy.stop(server, 500)
    IO.inspect(result, label: "observed public H2 stop")

    # ADR 004 preserves the service aggregate when it wins the caller-deadline race.
    assert result in [
             :ok,
             {:error, {:deadline_exceeded, :cleanup_pending}},
             {:error, {:services, [http: {:error, {:deadline_exceeded, :cleanup_pending}}]}}
           ]

    assert System.monotonic_time(:millisecond) - started < 1_500
    assert_receive {:DOWN, ^monitor, :process, ^worker, _}, 1_000
    assert_receive {:DOWN, ^server_monitor, :process, ^server, :normal}, 1_000
  end

  test "Probe 9: H2 server drain stays bounded with an infinite stream and joins its worker" do
    {:ok, server} =
      Gaoxy.HTTP.start_link(
        plug: {StreamPlug, self()},
        protocols: [:http2],
        h2c: :prior_knowledge,
        http_limits: %{request_timeout: 200}
      )

    on_exit(fn -> if Process.alive?(server), do: Gaoxy.stop(server, 1_000) end)
    {:ok, {_, port}} = Gaoxy.info(server, :http).local
    {:ok, socket} = :gen_tcp.connect({127, 0, 0, 1}, port, [:binary, active: false], 1_000)
    on_exit(fn -> :gen_tcp.close(socket) end)

    {block, _} =
      HPAX.encode(
        [
          {:no_store, ":method", "GET"},
          {:no_store, ":scheme", "http"},
          {:no_store, ":authority", "localhost"},
          {:no_store, ":path", "/infinite"}
        ],
        HPAX.new(4096)
      )

    :ok =
      :gen_tcp.send(socket, [
        "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n",
        Gaoxy.HTTP.HTTP2.Frame.encode(4, 0, 0, ""),
        Gaoxy.HTTP.HTTP2.Frame.encode(1, 5, 1, block)
      ])

    assert_receive {:h2_stream, worker, "/infinite"}, 1_000
    monitor = Process.monitor(worker)
    server_monitor = Process.monitor(server)
    started = System.monotonic_time(:millisecond)
    result = Gaoxy.stop(server, 500)
    IO.inspect(result, label: "observed public H2 stop")

    # ADR 004 preserves the service aggregate when it wins the caller-deadline race.
    assert result in [
             :ok,
             {:error, {:deadline_exceeded, :cleanup_pending}},
             {:error, {:services, [http: {:error, {:deadline_exceeded, :cleanup_pending}}]}}
           ]

    assert System.monotonic_time(:millisecond) - started < 1_500
    assert_receive {:DOWN, ^monitor, :process, ^worker, _}, 1_000
    assert_receive {:DOWN, ^server_monitor, :process, ^server, :normal}, 1_000
  end

  test "Probe 10: H2 server drain stays bounded with an infinite stream and joins its worker" do
    {:ok, server} =
      Gaoxy.HTTP.start_link(
        plug: {StreamPlug, self()},
        protocols: [:http2],
        h2c: :prior_knowledge,
        http_limits: %{request_timeout: 200}
      )

    on_exit(fn -> if Process.alive?(server), do: Gaoxy.stop(server, 1_000) end)
    {:ok, {_, port}} = Gaoxy.info(server, :http).local
    {:ok, socket} = :gen_tcp.connect({127, 0, 0, 1}, port, [:binary, active: false], 1_000)
    on_exit(fn -> :gen_tcp.close(socket) end)

    {block, _} =
      HPAX.encode(
        [
          {:no_store, ":method", "GET"},
          {:no_store, ":scheme", "http"},
          {:no_store, ":authority", "localhost"},
          {:no_store, ":path", "/infinite"}
        ],
        HPAX.new(4096)
      )

    :ok =
      :gen_tcp.send(socket, [
        "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n",
        Gaoxy.HTTP.HTTP2.Frame.encode(4, 0, 0, ""),
        Gaoxy.HTTP.HTTP2.Frame.encode(1, 5, 1, block)
      ])

    assert_receive {:h2_stream, worker, "/infinite"}, 1_000
    monitor = Process.monitor(worker)
    server_monitor = Process.monitor(server)
    started = System.monotonic_time(:millisecond)
    result = Gaoxy.stop(server, 500)
    IO.inspect(result, label: "observed public H2 stop")

    # ADR 004 preserves the service aggregate when it wins the caller-deadline race.
    assert result in [
             :ok,
             {:error, {:deadline_exceeded, :cleanup_pending}},
             {:error, {:services, [http: {:error, {:deadline_exceeded, :cleanup_pending}}]}}
           ]

    assert System.monotonic_time(:millisecond) - started < 1_500
    assert_receive {:DOWN, ^monitor, :process, ^worker, _}, 1_000
    assert_receive {:DOWN, ^server_monitor, :process, ^server, :normal}, 1_000
  end

  test "Probe 11: H2 server drain stays bounded with an infinite stream and joins its worker" do
    {:ok, server} =
      Gaoxy.HTTP.start_link(
        plug: {StreamPlug, self()},
        protocols: [:http2],
        h2c: :prior_knowledge,
        http_limits: %{request_timeout: 200}
      )

    on_exit(fn -> if Process.alive?(server), do: Gaoxy.stop(server, 1_000) end)
    {:ok, {_, port}} = Gaoxy.info(server, :http).local
    {:ok, socket} = :gen_tcp.connect({127, 0, 0, 1}, port, [:binary, active: false], 1_000)
    on_exit(fn -> :gen_tcp.close(socket) end)

    {block, _} =
      HPAX.encode(
        [
          {:no_store, ":method", "GET"},
          {:no_store, ":scheme", "http"},
          {:no_store, ":authority", "localhost"},
          {:no_store, ":path", "/infinite"}
        ],
        HPAX.new(4096)
      )

    :ok =
      :gen_tcp.send(socket, [
        "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n",
        Gaoxy.HTTP.HTTP2.Frame.encode(4, 0, 0, ""),
        Gaoxy.HTTP.HTTP2.Frame.encode(1, 5, 1, block)
      ])

    assert_receive {:h2_stream, worker, "/infinite"}, 1_000
    monitor = Process.monitor(worker)
    server_monitor = Process.monitor(server)
    started = System.monotonic_time(:millisecond)
    result = Gaoxy.stop(server, 500)
    IO.inspect(result, label: "observed public H2 stop")

    # ADR 004 preserves the service aggregate when it wins the caller-deadline race.
    assert result in [
             :ok,
             {:error, {:deadline_exceeded, :cleanup_pending}},
             {:error, {:services, [http: {:error, {:deadline_exceeded, :cleanup_pending}}]}}
           ]

    assert System.monotonic_time(:millisecond) - started < 1_500
    assert_receive {:DOWN, ^monitor, :process, ^worker, _}, 1_000
    assert_receive {:DOWN, ^server_monitor, :process, ^server, :normal}, 1_000
  end

  test "Probe 12: H2 server drain stays bounded with an infinite stream and joins its worker" do
    {:ok, server} =
      Gaoxy.HTTP.start_link(
        plug: {StreamPlug, self()},
        protocols: [:http2],
        h2c: :prior_knowledge,
        http_limits: %{request_timeout: 200}
      )

    on_exit(fn -> if Process.alive?(server), do: Gaoxy.stop(server, 1_000) end)
    {:ok, {_, port}} = Gaoxy.info(server, :http).local
    {:ok, socket} = :gen_tcp.connect({127, 0, 0, 1}, port, [:binary, active: false], 1_000)
    on_exit(fn -> :gen_tcp.close(socket) end)

    {block, _} =
      HPAX.encode(
        [
          {:no_store, ":method", "GET"},
          {:no_store, ":scheme", "http"},
          {:no_store, ":authority", "localhost"},
          {:no_store, ":path", "/infinite"}
        ],
        HPAX.new(4096)
      )

    :ok =
      :gen_tcp.send(socket, [
        "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n",
        Gaoxy.HTTP.HTTP2.Frame.encode(4, 0, 0, ""),
        Gaoxy.HTTP.HTTP2.Frame.encode(1, 5, 1, block)
      ])

    assert_receive {:h2_stream, worker, "/infinite"}, 1_000
    monitor = Process.monitor(worker)
    server_monitor = Process.monitor(server)
    started = System.monotonic_time(:millisecond)
    result = Gaoxy.stop(server, 500)
    IO.inspect(result, label: "observed public H2 stop")

    # ADR 004 preserves the service aggregate when it wins the caller-deadline race.
    assert result in [
             :ok,
             {:error, {:deadline_exceeded, :cleanup_pending}},
             {:error, {:services, [http: {:error, {:deadline_exceeded, :cleanup_pending}}]}}
           ]

    assert System.monotonic_time(:millisecond) - started < 1_500
    assert_receive {:DOWN, ^monitor, :process, ^worker, _}, 1_000
    assert_receive {:DOWN, ^server_monitor, :process, ^server, :normal}, 1_000
  end

  test "Probe 13: H2 server drain stays bounded with an infinite stream and joins its worker" do
    {:ok, server} =
      Gaoxy.HTTP.start_link(
        plug: {StreamPlug, self()},
        protocols: [:http2],
        h2c: :prior_knowledge,
        http_limits: %{request_timeout: 200}
      )

    on_exit(fn -> if Process.alive?(server), do: Gaoxy.stop(server, 1_000) end)
    {:ok, {_, port}} = Gaoxy.info(server, :http).local
    {:ok, socket} = :gen_tcp.connect({127, 0, 0, 1}, port, [:binary, active: false], 1_000)
    on_exit(fn -> :gen_tcp.close(socket) end)

    {block, _} =
      HPAX.encode(
        [
          {:no_store, ":method", "GET"},
          {:no_store, ":scheme", "http"},
          {:no_store, ":authority", "localhost"},
          {:no_store, ":path", "/infinite"}
        ],
        HPAX.new(4096)
      )

    :ok =
      :gen_tcp.send(socket, [
        "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n",
        Gaoxy.HTTP.HTTP2.Frame.encode(4, 0, 0, ""),
        Gaoxy.HTTP.HTTP2.Frame.encode(1, 5, 1, block)
      ])

    assert_receive {:h2_stream, worker, "/infinite"}, 1_000
    monitor = Process.monitor(worker)
    server_monitor = Process.monitor(server)
    started = System.monotonic_time(:millisecond)
    result = Gaoxy.stop(server, 500)
    IO.inspect(result, label: "observed public H2 stop")

    # ADR 004 preserves the service aggregate when it wins the caller-deadline race.
    assert result in [
             :ok,
             {:error, {:deadline_exceeded, :cleanup_pending}},
             {:error, {:services, [http: {:error, {:deadline_exceeded, :cleanup_pending}}]}}
           ]

    assert System.monotonic_time(:millisecond) - started < 1_500
    assert_receive {:DOWN, ^monitor, :process, ^worker, _}, 1_000
    assert_receive {:DOWN, ^server_monitor, :process, ^server, :normal}, 1_000
  end

  test "Probe 14: H2 server drain stays bounded with an infinite stream and joins its worker" do
    {:ok, server} =
      Gaoxy.HTTP.start_link(
        plug: {StreamPlug, self()},
        protocols: [:http2],
        h2c: :prior_knowledge,
        http_limits: %{request_timeout: 200}
      )

    on_exit(fn -> if Process.alive?(server), do: Gaoxy.stop(server, 1_000) end)
    {:ok, {_, port}} = Gaoxy.info(server, :http).local
    {:ok, socket} = :gen_tcp.connect({127, 0, 0, 1}, port, [:binary, active: false], 1_000)
    on_exit(fn -> :gen_tcp.close(socket) end)

    {block, _} =
      HPAX.encode(
        [
          {:no_store, ":method", "GET"},
          {:no_store, ":scheme", "http"},
          {:no_store, ":authority", "localhost"},
          {:no_store, ":path", "/infinite"}
        ],
        HPAX.new(4096)
      )

    :ok =
      :gen_tcp.send(socket, [
        "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n",
        Gaoxy.HTTP.HTTP2.Frame.encode(4, 0, 0, ""),
        Gaoxy.HTTP.HTTP2.Frame.encode(1, 5, 1, block)
      ])

    assert_receive {:h2_stream, worker, "/infinite"}, 1_000
    monitor = Process.monitor(worker)
    server_monitor = Process.monitor(server)
    started = System.monotonic_time(:millisecond)
    result = Gaoxy.stop(server, 500)
    IO.inspect(result, label: "observed public H2 stop")

    # ADR 004 preserves the service aggregate when it wins the caller-deadline race.
    assert result in [
             :ok,
             {:error, {:deadline_exceeded, :cleanup_pending}},
             {:error, {:services, [http: {:error, {:deadline_exceeded, :cleanup_pending}}]}}
           ]

    assert System.monotonic_time(:millisecond) - started < 1_500
    assert_receive {:DOWN, ^monitor, :process, ^worker, _}, 1_000
    assert_receive {:DOWN, ^server_monitor, :process, ^server, :normal}, 1_000
  end

  test "Probe 15: H2 server drain stays bounded with an infinite stream and joins its worker" do
    {:ok, server} =
      Gaoxy.HTTP.start_link(
        plug: {StreamPlug, self()},
        protocols: [:http2],
        h2c: :prior_knowledge,
        http_limits: %{request_timeout: 200}
      )

    on_exit(fn -> if Process.alive?(server), do: Gaoxy.stop(server, 1_000) end)
    {:ok, {_, port}} = Gaoxy.info(server, :http).local
    {:ok, socket} = :gen_tcp.connect({127, 0, 0, 1}, port, [:binary, active: false], 1_000)
    on_exit(fn -> :gen_tcp.close(socket) end)

    {block, _} =
      HPAX.encode(
        [
          {:no_store, ":method", "GET"},
          {:no_store, ":scheme", "http"},
          {:no_store, ":authority", "localhost"},
          {:no_store, ":path", "/infinite"}
        ],
        HPAX.new(4096)
      )

    :ok =
      :gen_tcp.send(socket, [
        "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n",
        Gaoxy.HTTP.HTTP2.Frame.encode(4, 0, 0, ""),
        Gaoxy.HTTP.HTTP2.Frame.encode(1, 5, 1, block)
      ])

    assert_receive {:h2_stream, worker, "/infinite"}, 1_000
    monitor = Process.monitor(worker)
    server_monitor = Process.monitor(server)
    started = System.monotonic_time(:millisecond)
    result = Gaoxy.stop(server, 500)
    IO.inspect(result, label: "observed public H2 stop")

    # ADR 004 preserves the service aggregate when it wins the caller-deadline race.
    assert result in [
             :ok,
             {:error, {:deadline_exceeded, :cleanup_pending}},
             {:error, {:services, [http: {:error, {:deadline_exceeded, :cleanup_pending}}]}}
           ]

    assert System.monotonic_time(:millisecond) - started < 1_500
    assert_receive {:DOWN, ^monitor, :process, ^worker, _}, 1_000
    assert_receive {:DOWN, ^server_monitor, :process, ^server, :normal}, 1_000
  end

  test "Probe 16: H2 server drain stays bounded with an infinite stream and joins its worker" do
    {:ok, server} =
      Gaoxy.HTTP.start_link(
        plug: {StreamPlug, self()},
        protocols: [:http2],
        h2c: :prior_knowledge,
        http_limits: %{request_timeout: 200}
      )

    on_exit(fn -> if Process.alive?(server), do: Gaoxy.stop(server, 1_000) end)
    {:ok, {_, port}} = Gaoxy.info(server, :http).local
    {:ok, socket} = :gen_tcp.connect({127, 0, 0, 1}, port, [:binary, active: false], 1_000)
    on_exit(fn -> :gen_tcp.close(socket) end)

    {block, _} =
      HPAX.encode(
        [
          {:no_store, ":method", "GET"},
          {:no_store, ":scheme", "http"},
          {:no_store, ":authority", "localhost"},
          {:no_store, ":path", "/infinite"}
        ],
        HPAX.new(4096)
      )

    :ok =
      :gen_tcp.send(socket, [
        "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n",
        Gaoxy.HTTP.HTTP2.Frame.encode(4, 0, 0, ""),
        Gaoxy.HTTP.HTTP2.Frame.encode(1, 5, 1, block)
      ])

    assert_receive {:h2_stream, worker, "/infinite"}, 1_000
    monitor = Process.monitor(worker)
    server_monitor = Process.monitor(server)
    started = System.monotonic_time(:millisecond)
    result = Gaoxy.stop(server, 500)
    IO.inspect(result, label: "observed public H2 stop")

    # ADR 004 preserves the service aggregate when it wins the caller-deadline race.
    assert result in [
             :ok,
             {:error, {:deadline_exceeded, :cleanup_pending}},
             {:error, {:services, [http: {:error, {:deadline_exceeded, :cleanup_pending}}]}}
           ]

    assert System.monotonic_time(:millisecond) - started < 1_500
    assert_receive {:DOWN, ^monitor, :process, ^worker, _}, 1_000
    assert_receive {:DOWN, ^server_monitor, :process, ^server, :normal}, 1_000
  end

  test "Probe 17: H2 server drain stays bounded with an infinite stream and joins its worker" do
    {:ok, server} =
      Gaoxy.HTTP.start_link(
        plug: {StreamPlug, self()},
        protocols: [:http2],
        h2c: :prior_knowledge,
        http_limits: %{request_timeout: 200}
      )

    on_exit(fn -> if Process.alive?(server), do: Gaoxy.stop(server, 1_000) end)
    {:ok, {_, port}} = Gaoxy.info(server, :http).local
    {:ok, socket} = :gen_tcp.connect({127, 0, 0, 1}, port, [:binary, active: false], 1_000)
    on_exit(fn -> :gen_tcp.close(socket) end)

    {block, _} =
      HPAX.encode(
        [
          {:no_store, ":method", "GET"},
          {:no_store, ":scheme", "http"},
          {:no_store, ":authority", "localhost"},
          {:no_store, ":path", "/infinite"}
        ],
        HPAX.new(4096)
      )

    :ok =
      :gen_tcp.send(socket, [
        "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n",
        Gaoxy.HTTP.HTTP2.Frame.encode(4, 0, 0, ""),
        Gaoxy.HTTP.HTTP2.Frame.encode(1, 5, 1, block)
      ])

    assert_receive {:h2_stream, worker, "/infinite"}, 1_000
    monitor = Process.monitor(worker)
    server_monitor = Process.monitor(server)
    started = System.monotonic_time(:millisecond)
    result = Gaoxy.stop(server, 500)
    IO.inspect(result, label: "observed public H2 stop")

    # ADR 004 preserves the service aggregate when it wins the caller-deadline race.
    assert result in [
             :ok,
             {:error, {:deadline_exceeded, :cleanup_pending}},
             {:error, {:services, [http: {:error, {:deadline_exceeded, :cleanup_pending}}]}}
           ]

    assert System.monotonic_time(:millisecond) - started < 1_500
    assert_receive {:DOWN, ^monitor, :process, ^worker, _}, 1_000
    assert_receive {:DOWN, ^server_monitor, :process, ^server, :normal}, 1_000
  end

  test "Probe 18: H2 server drain stays bounded with an infinite stream and joins its worker" do
    {:ok, server} =
      Gaoxy.HTTP.start_link(
        plug: {StreamPlug, self()},
        protocols: [:http2],
        h2c: :prior_knowledge,
        http_limits: %{request_timeout: 200}
      )

    on_exit(fn -> if Process.alive?(server), do: Gaoxy.stop(server, 1_000) end)
    {:ok, {_, port}} = Gaoxy.info(server, :http).local
    {:ok, socket} = :gen_tcp.connect({127, 0, 0, 1}, port, [:binary, active: false], 1_000)
    on_exit(fn -> :gen_tcp.close(socket) end)

    {block, _} =
      HPAX.encode(
        [
          {:no_store, ":method", "GET"},
          {:no_store, ":scheme", "http"},
          {:no_store, ":authority", "localhost"},
          {:no_store, ":path", "/infinite"}
        ],
        HPAX.new(4096)
      )

    :ok =
      :gen_tcp.send(socket, [
        "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n",
        Gaoxy.HTTP.HTTP2.Frame.encode(4, 0, 0, ""),
        Gaoxy.HTTP.HTTP2.Frame.encode(1, 5, 1, block)
      ])

    assert_receive {:h2_stream, worker, "/infinite"}, 1_000
    monitor = Process.monitor(worker)
    server_monitor = Process.monitor(server)
    started = System.monotonic_time(:millisecond)
    result = Gaoxy.stop(server, 500)
    IO.inspect(result, label: "observed public H2 stop")

    # ADR 004 preserves the service aggregate when it wins the caller-deadline race.
    assert result in [
             :ok,
             {:error, {:deadline_exceeded, :cleanup_pending}},
             {:error, {:services, [http: {:error, {:deadline_exceeded, :cleanup_pending}}]}}
           ]

    assert System.monotonic_time(:millisecond) - started < 1_500
    assert_receive {:DOWN, ^monitor, :process, ^worker, _}, 1_000
    assert_receive {:DOWN, ^server_monitor, :process, ^server, :normal}, 1_000
  end

  test "Probe 19: H2 server drain stays bounded with an infinite stream and joins its worker" do
    {:ok, server} =
      Gaoxy.HTTP.start_link(
        plug: {StreamPlug, self()},
        protocols: [:http2],
        h2c: :prior_knowledge,
        http_limits: %{request_timeout: 200}
      )

    on_exit(fn -> if Process.alive?(server), do: Gaoxy.stop(server, 1_000) end)
    {:ok, {_, port}} = Gaoxy.info(server, :http).local
    {:ok, socket} = :gen_tcp.connect({127, 0, 0, 1}, port, [:binary, active: false], 1_000)
    on_exit(fn -> :gen_tcp.close(socket) end)

    {block, _} =
      HPAX.encode(
        [
          {:no_store, ":method", "GET"},
          {:no_store, ":scheme", "http"},
          {:no_store, ":authority", "localhost"},
          {:no_store, ":path", "/infinite"}
        ],
        HPAX.new(4096)
      )

    :ok =
      :gen_tcp.send(socket, [
        "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n",
        Gaoxy.HTTP.HTTP2.Frame.encode(4, 0, 0, ""),
        Gaoxy.HTTP.HTTP2.Frame.encode(1, 5, 1, block)
      ])

    assert_receive {:h2_stream, worker, "/infinite"}, 1_000
    monitor = Process.monitor(worker)
    server_monitor = Process.monitor(server)
    started = System.monotonic_time(:millisecond)
    result = Gaoxy.stop(server, 500)
    IO.inspect(result, label: "observed public H2 stop")

    # ADR 004 preserves the service aggregate when it wins the caller-deadline race.
    assert result in [
             :ok,
             {:error, {:deadline_exceeded, :cleanup_pending}},
             {:error, {:services, [http: {:error, {:deadline_exceeded, :cleanup_pending}}]}}
           ]

    assert System.monotonic_time(:millisecond) - started < 1_500
    assert_receive {:DOWN, ^monitor, :process, ^worker, _}, 1_000
    assert_receive {:DOWN, ^server_monitor, :process, ^server, :normal}, 1_000
  end

  test "Probe 20: H2 server drain stays bounded with an infinite stream and joins its worker" do
    {:ok, server} =
      Gaoxy.HTTP.start_link(
        plug: {StreamPlug, self()},
        protocols: [:http2],
        h2c: :prior_knowledge,
        http_limits: %{request_timeout: 200}
      )

    on_exit(fn -> if Process.alive?(server), do: Gaoxy.stop(server, 1_000) end)
    {:ok, {_, port}} = Gaoxy.info(server, :http).local
    {:ok, socket} = :gen_tcp.connect({127, 0, 0, 1}, port, [:binary, active: false], 1_000)
    on_exit(fn -> :gen_tcp.close(socket) end)

    {block, _} =
      HPAX.encode(
        [
          {:no_store, ":method", "GET"},
          {:no_store, ":scheme", "http"},
          {:no_store, ":authority", "localhost"},
          {:no_store, ":path", "/infinite"}
        ],
        HPAX.new(4096)
      )

    :ok =
      :gen_tcp.send(socket, [
        "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n",
        Gaoxy.HTTP.HTTP2.Frame.encode(4, 0, 0, ""),
        Gaoxy.HTTP.HTTP2.Frame.encode(1, 5, 1, block)
      ])

    assert_receive {:h2_stream, worker, "/infinite"}, 1_000
    monitor = Process.monitor(worker)
    server_monitor = Process.monitor(server)
    started = System.monotonic_time(:millisecond)
    result = Gaoxy.stop(server, 500)
    IO.inspect(result, label: "observed public H2 stop")

    # ADR 004 preserves the service aggregate when it wins the caller-deadline race.
    assert result in [
             :ok,
             {:error, {:deadline_exceeded, :cleanup_pending}},
             {:error, {:services, [http: {:error, {:deadline_exceeded, :cleanup_pending}}]}}
           ]

    assert System.monotonic_time(:millisecond) - started < 1_500
    assert_receive {:DOWN, ^monitor, :process, ^worker, _}, 1_000
    assert_receive {:DOWN, ^server_monitor, :process, ^server, :normal}, 1_000
  end

  test "Probe 21: H2 server drain stays bounded with an infinite stream and joins its worker" do
    {:ok, server} =
      Gaoxy.HTTP.start_link(
        plug: {StreamPlug, self()},
        protocols: [:http2],
        h2c: :prior_knowledge,
        http_limits: %{request_timeout: 200}
      )

    on_exit(fn -> if Process.alive?(server), do: Gaoxy.stop(server, 1_000) end)
    {:ok, {_, port}} = Gaoxy.info(server, :http).local
    {:ok, socket} = :gen_tcp.connect({127, 0, 0, 1}, port, [:binary, active: false], 1_000)
    on_exit(fn -> :gen_tcp.close(socket) end)

    {block, _} =
      HPAX.encode(
        [
          {:no_store, ":method", "GET"},
          {:no_store, ":scheme", "http"},
          {:no_store, ":authority", "localhost"},
          {:no_store, ":path", "/infinite"}
        ],
        HPAX.new(4096)
      )

    :ok =
      :gen_tcp.send(socket, [
        "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n",
        Gaoxy.HTTP.HTTP2.Frame.encode(4, 0, 0, ""),
        Gaoxy.HTTP.HTTP2.Frame.encode(1, 5, 1, block)
      ])

    assert_receive {:h2_stream, worker, "/infinite"}, 1_000
    monitor = Process.monitor(worker)
    server_monitor = Process.monitor(server)
    started = System.monotonic_time(:millisecond)
    result = Gaoxy.stop(server, 500)
    IO.inspect(result, label: "observed public H2 stop")

    # ADR 004 preserves the service aggregate when it wins the caller-deadline race.
    assert result in [
             :ok,
             {:error, {:deadline_exceeded, :cleanup_pending}},
             {:error, {:services, [http: {:error, {:deadline_exceeded, :cleanup_pending}}]}}
           ]

    assert System.monotonic_time(:millisecond) - started < 1_500
    assert_receive {:DOWN, ^monitor, :process, ^worker, _}, 1_000
    assert_receive {:DOWN, ^server_monitor, :process, ^server, :normal}, 1_000
  end

  test "Probe 22: H2 server drain stays bounded with an infinite stream and joins its worker" do
    {:ok, server} =
      Gaoxy.HTTP.start_link(
        plug: {StreamPlug, self()},
        protocols: [:http2],
        h2c: :prior_knowledge,
        http_limits: %{request_timeout: 200}
      )

    on_exit(fn -> if Process.alive?(server), do: Gaoxy.stop(server, 1_000) end)
    {:ok, {_, port}} = Gaoxy.info(server, :http).local
    {:ok, socket} = :gen_tcp.connect({127, 0, 0, 1}, port, [:binary, active: false], 1_000)
    on_exit(fn -> :gen_tcp.close(socket) end)

    {block, _} =
      HPAX.encode(
        [
          {:no_store, ":method", "GET"},
          {:no_store, ":scheme", "http"},
          {:no_store, ":authority", "localhost"},
          {:no_store, ":path", "/infinite"}
        ],
        HPAX.new(4096)
      )

    :ok =
      :gen_tcp.send(socket, [
        "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n",
        Gaoxy.HTTP.HTTP2.Frame.encode(4, 0, 0, ""),
        Gaoxy.HTTP.HTTP2.Frame.encode(1, 5, 1, block)
      ])

    assert_receive {:h2_stream, worker, "/infinite"}, 1_000
    monitor = Process.monitor(worker)
    server_monitor = Process.monitor(server)
    started = System.monotonic_time(:millisecond)
    result = Gaoxy.stop(server, 500)
    IO.inspect(result, label: "observed public H2 stop")

    # ADR 004 preserves the service aggregate when it wins the caller-deadline race.
    assert result in [
             :ok,
             {:error, {:deadline_exceeded, :cleanup_pending}},
             {:error, {:services, [http: {:error, {:deadline_exceeded, :cleanup_pending}}]}}
           ]

    assert System.monotonic_time(:millisecond) - started < 1_500
    assert_receive {:DOWN, ^monitor, :process, ^worker, _}, 1_000
    assert_receive {:DOWN, ^server_monitor, :process, ^server, :normal}, 1_000
  end

  test "Probe 23: H2 server drain stays bounded with an infinite stream and joins its worker" do
    {:ok, server} =
      Gaoxy.HTTP.start_link(
        plug: {StreamPlug, self()},
        protocols: [:http2],
        h2c: :prior_knowledge,
        http_limits: %{request_timeout: 200}
      )

    on_exit(fn -> if Process.alive?(server), do: Gaoxy.stop(server, 1_000) end)
    {:ok, {_, port}} = Gaoxy.info(server, :http).local
    {:ok, socket} = :gen_tcp.connect({127, 0, 0, 1}, port, [:binary, active: false], 1_000)
    on_exit(fn -> :gen_tcp.close(socket) end)

    {block, _} =
      HPAX.encode(
        [
          {:no_store, ":method", "GET"},
          {:no_store, ":scheme", "http"},
          {:no_store, ":authority", "localhost"},
          {:no_store, ":path", "/infinite"}
        ],
        HPAX.new(4096)
      )

    :ok =
      :gen_tcp.send(socket, [
        "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n",
        Gaoxy.HTTP.HTTP2.Frame.encode(4, 0, 0, ""),
        Gaoxy.HTTP.HTTP2.Frame.encode(1, 5, 1, block)
      ])

    assert_receive {:h2_stream, worker, "/infinite"}, 1_000
    monitor = Process.monitor(worker)
    server_monitor = Process.monitor(server)
    started = System.monotonic_time(:millisecond)
    result = Gaoxy.stop(server, 500)
    IO.inspect(result, label: "observed public H2 stop")

    # ADR 004 preserves the service aggregate when it wins the caller-deadline race.
    assert result in [
             :ok,
             {:error, {:deadline_exceeded, :cleanup_pending}},
             {:error, {:services, [http: {:error, {:deadline_exceeded, :cleanup_pending}}]}}
           ]

    assert System.monotonic_time(:millisecond) - started < 1_500
    assert_receive {:DOWN, ^monitor, :process, ^worker, _}, 1_000
    assert_receive {:DOWN, ^server_monitor, :process, ^server, :normal}, 1_000
  end

end
