"""Run unchanged issue regressions in a fresh public-Hex Phoenix consumer."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import urllib.request

root=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--expected-tests',type=int,required=True)
parser.add_argument('files',nargs='+')
args=parser.parse_args()
base=root/'.audit/release-0.9.0-public-phoenix'
project=base/'integration/phoenix_native'
project.mkdir(parents=True,exist_ok=False)
fixture=root/'examples/phoenix_native'
for folder in ['lib','config']:
    shutil.copytree(fixture/folder,project/folder)
(project/'test').mkdir()
for name in ['test_helper.exs',*args.files]:
    shutil.copy2(fixture/'test'/name,project/'test'/name)
(base/'scripts').mkdir()
for name in ['generate-fixtures.sh','generate-client-cert-fixtures.sh']:
    shutil.copy2(root/'scripts'/name,base/'scripts'/name)
locklines=[line for line in (fixture/'mix.lock').read_text().splitlines() if '{:hex,' in line]
cohort='%{\n'+'\n'.join(locklines)+'\n}\n'
(project/'mix.lock').write_text(cohort)
manifest='''defmodule PublicPhoenixIssueConsumer.MixProject do
  use Mix.Project
  def project, do: [app: :phoenix_native, version: "0.1.0", elixir: "~> 1.18", deps: [
    {:gaoxy, "== 0.9.0", override: true},
    {:gaoxy_http, "== 0.9.0"},
    {:websock_adapter, "== 0.9.0", hex: :gaoxy_websock_adapter, override: true},
    {:phoenix, "== 1.8.16"}, {:phoenix_live_view, "~> 1.1"},
    {:phoenix_html, "~> 4.0"}, {:phoenix_pubsub, "~> 2.1"}, {:jason, "~> 1.4"}]]
  def application, do: [mod: {PhoenixNative.Application, []}, extra_applications: [:logger, :ssl]]
end
'''
(project/'mix.exs').write_text(manifest)
isolation='''defmodule PublicHexPhoenixIsolationTest do
  use ExUnit.Case, async: true
  test "the runtime uses only published Gaoxy Hex packages and preserves optional boundaries" do
    for dep <- Mix.Dep.load_and_cache(), do: assert(dep.scm == Hex.SCM)
    for app <- [:gaoxy, :gaoxy_http, :websock_adapter],
      do: assert(to_string(Application.spec(app, :vsn)) == "0.9.0")
    for app <- [:gaoxy_server, :gaoxy_http3, :gaoxy_proxy, :bandit, :plug_cowboy],
      do: assert({:error, :bad_name} == :code.lib_dir(app))
  end
end
'''
(project/'test/public_hex_isolation_test.exs').write_text(isolation)
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
source_hashes={str(path.relative_to(project)):sha(path) for folder in ['lib','config','test'] for path in (project/folder).rglob('*') if path.is_file()}
env=dict(os.environ,MIX_ENV='test',ELIXIR_ERL_OPTIONS='+S 2:2',
    HEX_HOME=str(base/'hex-cache'),MIX_DEPS_PATH=str(project/'deps'),MIX_BUILD_PATH=str(project/'_build'))
report={'status':'FAIL','version':'0.9.0','release_source':os.environ['GAOXY_EXPECTED_RELEASE_SHA'],'source_hashes':source_hashes,'expected_tests':args.expected_tests+1,'commands':[]}
logfile=base/'consumer.log'
try:
    with logfile.open('w') as log:
        for command in [['mix','deps.get'],['mix','deps.get','--check-locked'],['mix','compile','--warnings-as-errors'],['mix','test','--warnings-as-errors','--seed','0','--max-cases','1']]:
            log.write('PUBLIC_PHOENIX_COMMAND '+json.dumps(command)+'\n');log.flush()
            result=subprocess.run(command,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
            report['commands'].append({'command':command,'exit':result.returncode})
            assert result.returncode==0,(command,result.returncode)
    output=logfile.read_text()
    expected=args.expected_tests+1
    assert re.findall(r'(\d+) tests?, (\d+) failures?',output)==[(str(expected),'0')],output[-5000:]
    assert not re.search(r'[1-9]\d* (?:excluded|skipped)',output)
    after=dict(re.findall(r'^  "([^"]+)": (.*)$',(project/'mix.lock').read_text(),re.M))
    before=dict(re.findall(r'^  "([^"]+)": (.*)$',cohort,re.M))
    for name,value in before.items():
        if name in after: assert after[name]==value,('upstream cohort drift',name)
    for name,digest in source_hashes.items(): assert sha(project/name)==digest,name
    report['packages']={}
    for name in ['gaoxy','gaoxy_http','gaoxy_websock_adapter']:
        with urllib.request.urlopen(f'https://hex.pm/api/packages/{name}/releases/0.9.0',timeout=30) as response:
            api=json.load(response)
        cached=list((base/'hex-cache').rglob(f'{name}-0.9.0.tar'))
        assert len(cached)==1 and sha(cached[0])==api['checksum'],name
        report['packages'][name]={'sha256':api['checksum'],'cache':str(cached[0])}
    report.update(status='PASS',tests=expected,failures=0,lock_sha256=sha(project/'mix.lock'))
finally:
    (base/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
