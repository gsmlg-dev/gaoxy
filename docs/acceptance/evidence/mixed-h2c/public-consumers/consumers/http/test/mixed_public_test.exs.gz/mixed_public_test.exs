defmodule PublicHexMixedHTTPTest do
  use ExUnit.Case, async: false
  @moduletag timeout: 30_000

  defmodule Endpoint do
    def init(owner), do: {:ok, owner}

    def call(exchange, owner) do
      {:ok, body, exchange} = read(exchange, "")
      request = exchange.request
      send(owner, {:public_mixed, request.version, request.path, body})

      Gaoxy.HTTP.Response.send_resp(
        exchange,
        200,
        [{"x-native-version", Atom.to_string(request.version)}],
        request.path <> ":" <> body
      )
    end

    defp read(exchange, body) do
      case Gaoxy.HTTP.Exchange.read_body(exchange, 16_384, 1_000) do
        {:ok, more, next} -> {:ok, body <> more, next}
        {:more, more, next} -> read(next, body <> more)
      end
    end
  end

  test "public Hex H1 and independent H2 share one port while both sockets remain open" do
    {:ok, server} =
      Gaoxy.HTTP.start_link(
        ip: {127, 0, 0, 1},
        port: 0,
        endpoint: {Endpoint, self()},
        protocols: [:http2, :http1],
        h2c: :prior_knowledge
      )

    on_exit(fn -> if Process.alive?(server), do: Gaoxy.stop(server, 2_000) end)
    assert [:http] == Gaoxy.services(server)
    assert {:ok, {{127, 0, 0, 1}, port}} = Gaoxy.info(server, :http).local
    peer = Path.join(__DIR__, "support/mixed_http_peer.py")

    {output, exit} =
      System.cmd(System.fetch_env!("GAOXY_MIXED_PYTHON"), [peer, to_string(port)],
        stderr_to_stdout: true
      )

    assert exit == 0, output

    assert %{
             "status" => "PASS",
             "port" => ^port,
             "h1_requests" => 3,
             "h2_streams" => 2,
             "protocols" => ["HTTP/1.1", "HTTP/2"],
             "simultaneous" => true
           } = JSON.decode!(output)

    for {version, path, body} <- [
          {:"HTTP/1.1", "/h1-first", "h1-body"},
          {:"HTTP/1.1", "/h1-pipeline", ""},
          {:"HTTP/1.1", "/h1-second", ""},
          {:"HTTP/2", "/h2-first", "h2-body"},
          {:"HTTP/2", "/h2-second", ""}
        ] do
      assert_receive {:public_mixed, ^version, ^path, ^body}, 2_000
    end

    refute_receive {:public_mixed, _, _, _}, 20
    await_empty(server, Gaoxy.Lifecycle.deadline(2_000))
    assert :ok = Gaoxy.stop(server, 2_000)
  end

  defp await_empty(server, deadline) do
    case Gaoxy.status(server, :http) do
      %{active: 0, retained_bytes: 0, cleanup_pending: 0} ->
        :ok

      _ ->
        assert Gaoxy.Lifecycle.remaining(deadline) > 0

        receive do
        after
          1 -> await_empty(server, deadline)
        end
    end
  end
end
