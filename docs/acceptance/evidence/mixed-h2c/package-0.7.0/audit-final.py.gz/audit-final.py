import datetime, hashlib, importlib.util, io, json, os, pathlib, subprocess, sys, tarfile, urllib.error, urllib.request
sys.dont_write_bytecode=True
ROOT=pathlib.Path.cwd(); OUT=ROOT/'.audit/mixed-h2c/package-0.7.0/final'; OUT.mkdir(); VERSION='0.7.0'
ENV={**os.environ,'ELIXIR_ERL_OPTIONS':'+S 4:4','MIX_ENV':'prod'}
spec=importlib.util.spec_from_file_location('regressions',ROOT/'scripts/test-stage-hex-packages.py'); regressions=importlib.util.module_from_spec(spec);spec.loader.exec_module(regressions)
PACKAGES=regressions.PACKAGES
commands=[]
def run(args,cwd=ROOT,log=None):
    result=subprocess.run(args,cwd=cwd,env=ENV,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=90)
    commands.append({'command':args,'cwd':str(cwd),'exit':result.returncode,'log':log})
    if log:(OUT/log).write_text(result.stdout)
    assert result.returncode==0,(args,result.stdout)
    return result.stdout

def sha(bytes):return hashlib.sha256(bytes).hexdigest()
def snapshot():
    files={ROOT/'mix.exs',ROOT/'LICENSE',ROOT/'mix.lock',ROOT/'scripts/stage-hex-packages.exs'}
    for rel in PACKAGES.values():
        p=ROOT/rel
        files.update(x for x in p.iterdir() if x.is_file())
        for folder in ['lib','priv']:
            if (p/folder).exists():files.update(x for x in (p/folder).rglob('*') if x.is_file())
    return {str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in sorted(files)}
receipt={'status':'RUNNING','version':VERSION,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'worktree':str(ROOT),'source_commit':run(['git','rev-parse','HEAD']).strip(),'git_status_before':run(['git','status','--short']),'commands':commands}
(OUT/'source.diff').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=ROOT))
receipt['source_diff_sha256']=sha((OUT/'source.diff').read_bytes());before=snapshot();(OUT/'source-hashes-before.json').write_text(json.dumps(before,indent=2)+'\n')
try:
    run(['elixir','scripts/stage-hex-packages.exs',str(ROOT),str(OUT/'staged')],log='stage.log')
    metadata_code='''{:ok, terms} = :file.consult(String.to_charlist(hd(System.argv())))
convert = fn
  values, recur when is_list(values) ->
    if values != [] and Enum.all?(values, &match?({_, _}, &1)) do
      Map.new(values, fn {key, value} -> {key, recur.(value, recur)} end)
    else
      Enum.map(values, &recur.(&1, recur))
    end
  value, _recur -> value
end
IO.puts(JSON.encode!(convert.(terms, convert)))
'''
    rows=[]
    for name,relative in PACKAGES.items():
        package=OUT/'staged'/name; source=ROOT/relative
        run(['mix','hex.build'],cwd=package,log=name+'-build.log')
        archive=package/f'{name}-{VERSION}.tar'
        with tarfile.open(archive) as outer:
            metadata_path=OUT/(name+'-metadata.config');metadata_path.write_bytes(outer.extractfile('metadata.config').read())
            metadata=json.loads(run(['elixir','-e',metadata_code,str(metadata_path)],log=name+'-metadata.json'))
            with tarfile.open(fileobj=io.BytesIO(outer.extractfile('contents.tar.gz').read()),mode='r:gz') as contents:
                runtime={m.name:sha(contents.extractfile(m).read()) for m in contents.getmembers() if m.isfile() and m.name.startswith(('lib/','priv/'))}
                expected={str(p.relative_to(source)):sha(p.read_bytes()) for folder in ['lib','priv'] for p in (source/folder).rglob('*') if p.is_file()}
                assert runtime==expected,(name,'runtime differs')
                for m in contents.getmembers():
                    if m.isfile():assert contents.extractfile(m).read()==(package/m.name).read_bytes(),(name,m.name)
                readme='README.gaoxy.md' if name=='gaoxy_websock_adapter' else 'README.md'
                assert contents.extractfile('README.md').read()==(source/readme).read_bytes()
                lic='LICENSE.gaoxy' if name=='gaoxy_websock_adapter' else 'LICENSE'
                assert contents.extractfile(lic).read()==(ROOT/'LICENSE').read_bytes()
                if name=='gaoxy_websock_adapter':
                    assert contents.extractfile('LICENSE').read()==(source/'LICENSE').read_bytes()
        assert metadata['name']==name and metadata['version']==VERSION
        assert metadata['app']==('websock_adapter' if name=='gaoxy_websock_adapter' else name)
        expected_reqs={key:(app,req.replace('9.8.7',VERSION),optional) for key,(app,req,optional) in regressions.REQUIREMENTS[name].items()}
        actual={r['name']:(r['app'],r['requirement'],r['optional']) for r in metadata['requirements']}
        assert actual==expected_reqs,(name,actual,expected_reqs)
        assert all(r['repository']=='hexpm' for r in metadata['requirements'])
        assert metadata['licenses']==['MIT']
        manifest=(package/'mix.exs').read_text()
        for forbidden in ['in_umbrella:','override:','path:','git:','config_path:','build_path:','deps_path:','lockfile:']:
            assert forbidden not in manifest,(name,forbidden)
        if name=='gaoxy_http':assert 'lib/gaoxy/http/protocol_detector.ex' in runtime
        rows.append({'package':name,'app':metadata['app'],'version':VERSION,'archive':str(archive.relative_to(ROOT)),'archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,'runtime_file_count':len(runtime),'runtime_hashes':runtime,'metadata':metadata})
    receipt['packages']=rows
    api=[]
    for name in PACKAGES:
        url=f'https://hex.pm/api/packages/{name}/releases/{VERSION}'
        try:
            response=urllib.request.urlopen(url,timeout=20)
        except urllib.error.HTTPError as error:response=error
        body=response.read();status=response.status
        (OUT/(name+'-hex-release-response.json')).write_bytes(body)
        (OUT/(name+'-hex-release-headers.txt')).write_text(str(response.headers))
        api.append({'package':name,'url':url,'http_status':status,'body_sha256':sha(body)})
        assert status==404,(name,status,body)
    receipt['hex_version_checks']=api
    local=run(['git','tag','--list','v0.7.0'],log='tag-local.log');remote=run(['git','ls-remote','--tags','origin','refs/tags/v0.7.0','refs/tags/v0.7.0^{}'],log='tag-remote.log')
    assert not local.strip() and not remote.strip()
    receipt['tag_checks']={'local_v0.7.0_absent':True,'remote_v0.7.0_absent':True}
    after=snapshot();(OUT/'source-hashes-after.json').write_text(json.dumps(after,indent=2)+'\n');assert before==after,'packaging input changed during run'
    receipt['source_files_unchanged']=True;receipt['source_file_count']=len(before);receipt['status']='PASS'
except Exception as error:
    receipt['status']='FAIL';receipt['error']=repr(error);raise
finally:
    receipt['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
