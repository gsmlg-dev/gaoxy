# Public Hex issue acceptance — prepared, not executed

`prepare.py` copied the nine selected source suites unchanged into `consumer`,
plus their peers, certificate helper and required original directory layout.
It copied `examples/phoenix_native` without dependency/build caches or its lock;
only the copied `mix.exs` changed, replacing own-package dependencies with exact
public Hex 0.12.0 requirements. Both projects declare all six packages, with
`:websock_adapter` mapped to `hex: :gaoxy_websock_adapter, override: true`.
There are no own runtime source files or path/git dependencies in either project.
`source-manifest.json` records source identity, fixture SHA256s and the one
allowed copied-manifest change. Preparation performs no dependency resolution,
compilation or test execution.

Wait until all six 0.12.0 releases are publicly available on Hex, then run from
the repository root with the already qualified Python 3.12 peer environment:

```sh
python3 -B .audit/release-0.12.0/public-issues/run.py --published \
  --python "$PWD/.audit/h2peer/bin/python"
```

Requirements: Elixir 1.18.5 / OTP 28, Mix/Hex/Rebar already installed, native
QUIC dependency build tools, OpenSSL 3, and a Python environment with the pinned
requirements copied to `consumer/integration/http3/requirements.txt` and
`consumer/apps/gaoxy_http/test/support/h2-requirements.txt`. The runner does not
install or mutate that Python environment. It checks public Hex release metadata
for all six packages before resolving anything and never falls back to source,
local tarballs or alternative versions.

The runner creates dependencies and builds only inside these two consumers.
It compiles strictly, checks every lock entry and resolved dependency source is
Hex, verifies all six locked/loaded application versions are exactly 0.12.0,
and saves source provenance, locks and full command output under `logs/`.
It requires exact positive counts without exclusions or skips:

| Suite | Cases |
| --- | ---: |
| HEAD unit + H1/H2 + H3 | 4 + 2 + 1 |
| Request-lifetime real-network acceptance | 10 |
| Lifetime configuration boundaries | 3 |
| WebSocket stream semantics | 14 |
| H2 worker accounting | 8 |
| H3 lifetime boundaries | 2 |
| Managed gateway boundaries | 3 |
| Unchanged actual Phoenix WebSocket compatibility fixture | 6 |
| Total | 53 |

HEAD protocol tests additionally require all 48 independent peer rows. Phoenix
runs only its unchanged six-case compatibility file, including actual disconnect
broadcast, wire close 1000 and transport/channel cleanup. No unrelated app tests
run. Every child command has a finite timeout and its own process group; timeout
cleanup targets only processes launched by this runner.

The runner refuses cached consumers or an existing `logs/` directory. Preserve
failed evidence; investigate before creating a fresh sibling acceptance directory
or changing the runner. Do not alter fixture bytes to make published packages
pass. Re-run preparation only in a fresh directory; its default refuses to
replace these prepared consumers.
