#!/usr/bin/env python3
"""Run only after all six 0.12.0 packages exist on public Hex."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import urllib.request

BASE = Path(__file__).resolve().parent
PACKAGES = ["gaoxy", "gaoxy_http", "gaoxy_http3", "gaoxy_proxy", "gaoxy_test", "gaoxy_websock_adapter"]
VERSION = "0.12.0"


def unchanged(manifest):
    for row in manifest["fixtures"]:
        path = BASE / row["copy"]
        expected = row.get("copy_sha256", row["sha256"])
        assert hashlib.sha256(path.read_bytes()).hexdigest() == expected, f"fixture bytes changed: {path}"
    for project in (BASE / "consumer", BASE / "phoenix_native"):
        content = (project / "mix.exs").read_text()
        assert not re.search(r"\b(?:path|git|github):", content), f"non-Hex manifest: {project}"
        assert content.count('"== 0.12.0"') == 6, f"six exact public own-package requirements missing: {project}"


def execute(command, directory, env, log, timeout=600):
    print("PUBLIC_ISSUE_COMMAND", directory.name, " ".join(map(str, command)), flush=True)
    process = subprocess.Popen(command, cwd=directory, env=env, stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT, text=True, start_new_session=True)
    try:
        output, _ = process.communicate(timeout=timeout)
    except BaseException:
        os.killpg(process.pid, signal.SIGTERM)
        try:
            output, _ = process.communicate(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            output, _ = process.communicate(timeout=5)
        log.write_text(output)
        raise
    log.write_text(output)
    print(output, end="", flush=True)
    assert process.returncode == 0, f"exit {process.returncode}: {command}; log={log}"
    return output


def exact_count(output, expected):
    assert not re.search(r"[1-9]\d* (?:excluded|skipped)", output), "required cases excluded/skipped"
    classic = re.findall(r"(\d+) tests?, (\d+) failures?", output)
    modern = re.findall(r"Result:\s+(\d+)(?:/(\d+))? passed", output)
    if classic:
        assert all(int(failures) == 0 for _, failures in classic), classic
        count = sum(int(total) for total, _ in classic)
    else:
        assert modern and all(not total or passed == total for passed, total in modern), modern
        count = sum(int(passed) for passed, _ in modern)
    assert count == expected and count > 0, f"executed {count}, expected {expected}"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--published", action="store_true", required=True)
    parser.add_argument("--python", required=True, help="Python environment containing pinned h2/aioquic peer requirements")
    args = parser.parse_args()
    manifest = json.loads((BASE / "source-manifest.json").read_text())
    unchanged(manifest)
    python = str(Path(args.python).resolve())
    assert Path(python).is_file(), python
    env = dict(os.environ)
    for key in ["MIX_DEPS_PATH", "MIX_BUILD_PATH", "MIX_BUILD_ROOT", "MIX_EXS", "MIX_TARGET",
                "ERL_LIBS", "ELIXIR_ERL_COMPILER_OPTIONS", "GAOXY_TEST_PACKAGES",
                "PHOENIX_NATIVE_HTTPS_PORT", "PHOENIX_NATIVE_HTTP3_PORT", "PHOENIX_NATIVE_RELOAD"]:
        env.pop(key, None)
    env.update(MIX_ENV="test", ELIXIR_ERL_OPTIONS="+S 2:2", GAOXY_H2_PYTHON=python,
               GAOXY_QUIC_PYTHON=python, PHOENIX_NATIVE_H3="1", PHOENIX_NATIVE_PORT="0")
    # This guard runs before deps.get or compilation, without local fallback.
    releases = {}
    for package in PACKAGES:
        request = urllib.request.Request(f"https://hex.pm/api/packages/{package}/releases/{VERSION}",
                                         headers={"Cache-Control": "no-cache"})
        with urllib.request.urlopen(request, timeout=30) as response:
            releases[package] = json.load(response)
        assert releases[package]["version"] == VERSION, package
    logs = BASE / "logs"
    logs.mkdir(exist_ok=False)
    (logs / "hex-release-metadata.json").write_text(json.dumps(releases, indent=2) + "\n")
    execute([python, "-B", "-c", "import h2, aioquic, pylsqpack; print('PUBLIC_PEERS_READY')"], BASE,
            env, logs / "peer-environment.log", timeout=30)
    results = []
    for project_name, suites in [
        ("consumer", manifest["tests"]),
        ("phoenix_native", manifest["phoenix_tests"]),
    ]:
        project = BASE / project_name
        assert not (project / "mix.lock").exists(), "fresh public resolution requires an unlocked consumer"
        assert not (project / "deps").exists() and not (project / "_build").exists(), "consumer must be clean"
        execute(["mix", "deps.get"], project, env, logs / f"{project_name}-deps-get.log")
        execute(["mix", "compile", "--warnings-as-errors"], project, env, logs / f"{project_name}-compile.log")
        provenance = execute(["mix", "run", "--no-start", str(BASE / "verify-deps.exs")], project,
                             env, logs / f"{project_name}-provenance.log")
        assert "PUBLIC_HEX_ONLY_PASS packages=6 version=0.12.0" in provenance
        shutil.copy2(project / "mix.lock", logs / f"{project_name}-mix.lock")
        for index, suite in enumerate(suites, 1):
            name = f"{project_name}-{index:02d}-{Path(suite['path']).stem}.log"
            output = execute(["mix", "test", suite["path"], "--warnings-as-errors", "--seed", "0", "--max-cases", "1"],
                             project, env, logs / name)
            exact_count(output, suite["expected"])
            if "head_content_length_network" in suite["path"]:
                expected_rows = 16 if "gaoxy_http3" in suite["path"] else 32
                assert len(re.findall(r"PASS H[123] ", output)) == expected_rows, "missing independent HEAD/GET peer rows"
            results.append({"project": project_name, **suite, "result": "PASS", "log": name})
            (logs / "results.json").write_text(json.dumps(results, indent=2) + "\n")
    unchanged(manifest)
    assert sum(row["expected"] for row in results) == 53
    print("PUBLIC_ISSUES_PASS executed=53 failures=0 own_packages=6 version=0.12.0 phoenix=6 independent_HEAD_GET_rows=48")


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        sys.exit(f"PUBLIC_ISSUES_FAIL: {type(error).__name__}: {error}")
