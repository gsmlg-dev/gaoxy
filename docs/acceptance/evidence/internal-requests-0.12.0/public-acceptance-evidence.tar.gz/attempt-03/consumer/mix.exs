defmodule GaoxyPublicIssues.MixProject do
  use Mix.Project
  def project do
    [app: :gaoxy_public_issues, version: "0.0.0", elixir: "~> 1.18", deps: deps()]
  end
  def application, do: [extra_applications: [:logger, :ssl]]
  defp deps do
    [
      {:gaoxy, "== 0.12.0"},
      {:gaoxy_http, "== 0.12.0"},
      {:gaoxy_http3, "== 0.12.0"},
      {:gaoxy_proxy, "== 0.12.0"},
      {:gaoxy_test, "== 0.12.0"},
      {:websock_adapter, "== 0.12.0", hex: :gaoxy_websock_adapter, override: true}
    ]
  end
end
