expected = %{
  gaoxy: :gaoxy,
  gaoxy_http: :gaoxy_http,
  gaoxy_http3: :gaoxy_http3,
  gaoxy_proxy: :gaoxy_proxy,
  gaoxy_test: :gaoxy_test,
  websock_adapter: :gaoxy_websock_adapter
}
lock = Mix.Dep.Lock.read()
for {application, entry} <- lock do
  unless is_tuple(entry) and elem(entry, 0) == :hex,
    do: raise("non-Hex dependency in lock: #{application}")
end
for {application, package} <- expected do
  entry = Map.fetch!(lock, application)
  unless elem(entry, 1) == package and elem(entry, 2) == "0.12.0" and elem(entry, 6) == "hexpm",
    do: raise("unexpected published package identity: #{inspect({application, entry})}")
end
for dependency <- Mix.Dep.load_and_cache() do
  unless dependency.scm == Hex.SCM,
    do: raise("non-Hex dependency source: #{dependency.app}")
end
for {application, package} <- expected do
  case Application.load(application) do
    :ok -> :ok
    {:error, {:already_loaded, ^application}} -> :ok
  end
  unless to_string(Application.spec(application, :vsn)) == "0.12.0",
    do: raise("loaded application version mismatch: #{application}")
  IO.puts("PUBLIC_HEX_APPLICATION #{application} package=#{package} version=0.12.0 lib=#{:code.lib_dir(application)}")
end
IO.puts("PUBLIC_HEX_ONLY_PASS packages=6 version=0.12.0")
