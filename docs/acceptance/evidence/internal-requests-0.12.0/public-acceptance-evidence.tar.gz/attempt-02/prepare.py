#!/usr/bin/env python3
"""Prepare byte-preserved issue regressions; never fetch or compile dependencies."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

BASE = Path(__file__).resolve().parent
SOURCE = BASE.parents[2]
VERSION = "0.12.0"
TARGET = BASE / "consumer"
PHOENIX = BASE / "phoenix_native"
TESTS = [
    ("apps/gaoxy_http/test/head_content_length_test.exs", 4),
    ("apps/gaoxy_http/test/head_content_length_network_test.exs", 2),
    ("apps/gaoxy_http3/test/head_content_length_network_test.exs", 1),
    ("apps/gaoxy_http/test/request_lifetime_network_test.exs", 10),
    ("apps/gaoxy_http/test/stream_lifetime_config_test.exs", 3),
    ("apps/gaoxy_http/test/websocket_stream_test.exs", 14),
    ("apps/gaoxy_http/test/http2_worker_accounting_test.exs", 8),
    ("apps/gaoxy_http3/test/stream_lifetime_boundary_test.exs", 2),
    ("apps/gaoxy_proxy/test/gateway_plan_test.exs", 3),
]
SUPPORT = [
    "apps/gaoxy_http/test/support/head_content_length_fixture.exs",
    "apps/gaoxy_http/test/support/head_content_length_peer.py",
    "apps/gaoxy_http/test/support/request_lifetime_h2_peer.py",
    "apps/gaoxy_http/test/support/h2-requirements.txt",
    "integration/http3/peer.py",
    "integration/http3/requirements.txt",
    "scripts/generate-fixtures.sh",
]
DEPS = '''      {:gaoxy, "== 0.12.0"},
      {:gaoxy_http, "== 0.12.0"},
      {:gaoxy_http3, "== 0.12.0"},
      {:gaoxy_proxy, "== 0.12.0"},
      {:gaoxy_test, "== 0.12.0"},
      {:websock_adapter, "== 0.12.0", hex: :gaoxy_websock_adapter, override: true}'''
if TARGET.exists() or PHOENIX.exists():
    raise SystemExit("Refusing to overwrite prepared consumers or their later evidence")

manifest = {"version": VERSION, "mode": "prepared-only-no-dependency-resolution",
            "source_root": str(SOURCE), "source_head": subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=SOURCE, text=True).strip(),
            "source_status": subprocess.check_output(
                ["git", "status", "--short"], cwd=SOURCE, text=True),
            "tests": [{"path": name, "expected": count} for name, count in TESTS],
            "fixtures": []}

def copy(source, target, original=None):
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    digest = hashlib.sha256(source.read_bytes()).hexdigest()
    assert digest == hashlib.sha256(target.read_bytes()).hexdigest()
    manifest["fixtures"].append({"source": str(source.relative_to(SOURCE)),
                                "copy": str(target.relative_to(BASE)), "sha256": digest})

for name in [*(name for name, _ in TESTS), *SUPPORT]:
    copy(SOURCE / name, TARGET / name)
(TARGET / "test").mkdir()
(TARGET / "test/test_helper.exs").write_text("ExUnit.start()\n")
(TARGET / "mix.exs").write_text('''defmodule GaoxyPublicIssues.MixProject do
  use Mix.Project
  def project do
    [app: :gaoxy_public_issues, version: "0.0.0", elixir: "~> 1.18", deps: deps()]
  end
  def application, do: [extra_applications: [:logger, :ssl]]
  defp deps do
    [
''' + DEPS + '''
    ]
  end
end
''')

fixture_source = SOURCE / "examples/phoenix_native"
for source in sorted(fixture_source.rglob("*")):
    relative = source.relative_to(fixture_source)
    if not source.is_file() or any(part in {"deps", "_build", ".git", ".audit", ".elixir_ls"}
                                   for part in relative.parts) or relative.name == "mix.lock":
        continue
    copy(source, PHOENIX / relative)
original = (PHOENIX / "mix.exs").read_text()
start = original.index("  defp deps do\n")
(PHOENIX / "mix.exs").write_text(original[:start] + '''  defp deps do
    [
''' + DEPS + ''',
      {:phoenix, "== 1.8.16"},
      {:phoenix_live_view, "~> 1.1"},
      {:phoenix_html, "~> 4.0"},
      {:phoenix_pubsub, "~> 2.1"},
      {:jason, "~> 1.4"}
    ]
  end
end
''')
for row in manifest["fixtures"]:
    if row["copy"] == "phoenix_native/mix.exs":
        row["allowed_change"] = "Only dependency declarations replaced with public Hex requirements"
        row["copy_sha256"] = hashlib.sha256((PHOENIX / "mix.exs").read_bytes()).hexdigest()
manifest["phoenix_tests"] = [{"path": "test/websocket_phoenix_compatibility_test.exs", "expected": 6}]
(BASE / "source-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(f"PREPARED {len(TESTS)} source suites / {sum(count for _, count in TESTS)} cases plus Phoenix6; no dependencies resolved")
